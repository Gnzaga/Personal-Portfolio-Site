import { createContext, useContext } from 'react';
import type { ShipPilotConfig } from '@shippilot/core/browser';

export interface RouterAdapter {
  /** Returns the current pathname string, e.g. "/projects/homelab" */
  getCurrentPath(): string;
  /** Programmatically navigate to a route */
  navigate(to: string): void;
}

export interface ShipPilotContextValue {
  config: ShipPilotConfig;
  router: RouterAdapter;
  isAgentMode: boolean;
  setAgentMode: (active: boolean) => void;
}

export const ShipPilotContext = createContext<ShipPilotContextValue | null>(null);

export function useShipPilot(): ShipPilotContextValue {
  const context = useContext(ShipPilotContext);
  if (!context) {
    throw new Error('useShipPilot must be used inside a <ShipPilotProvider>');
  }
  return context;
}
