import { useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type { ShipPilotConfig } from '@shippilot/core/browser';
import { ShipPilotContext } from './ShipPilotContext.js';
import type { RouterAdapter } from './ShipPilotContext.js';

export interface ShipPilotProviderProps {
  config: ShipPilotConfig;
  router: RouterAdapter;
  children: ReactNode;
}

const STYLE_ID = 'shippilot-styles';

const STYLE_CSS = `
.shippilot-highlight { outline: 2px solid var(--shippilot-accent, #22c55e); outline-offset: 4px; border-radius: 8px; }
.shippilot-nav-highlight { box-shadow: 0 0 0 3px var(--shippilot-accent, #22c55e); }
.shippilot-nav-click { transform: scale(0.96); }
.shippilot-agent-border { position: fixed; inset: 0; z-index: 9999; pointer-events: none; border: 4px solid color-mix(in srgb, var(--shippilot-accent, #22c55e) 40%, transparent); animation: shippilot-border-pulse 1.5s ease-in-out infinite; }
@keyframes shippilot-border-pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }
`.trim();

let styleRefCount = 0;

export function ShipPilotProvider({ config, router, children }: ShipPilotProviderProps) {
  const [isAgentMode, setIsAgentMode] = useState(false);

  useEffect(() => {
    styleRefCount++;
    if (styleRefCount === 1 && !document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = STYLE_CSS;
      document.head.appendChild(style);
    }
    return () => {
      styleRefCount--;
      if (styleRefCount === 0) {
        document.getElementById(STYLE_ID)?.remove();
      }
    };
  }, []);

  const contextValue = {
    config,
    router,
    isAgentMode,
    setAgentMode: setIsAgentMode,
  };

  return (
    <ShipPilotContext.Provider value={contextValue}>
      <div
        style={
          config.accentColor
            ? ({ '--shippilot-accent': config.accentColor } as React.CSSProperties)
            : undefined
        }
      >
        {children}
      </div>
    </ShipPilotContext.Provider>
  );
}
