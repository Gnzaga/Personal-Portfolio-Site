// @shippilot/react — React component library for ShipPilot

export { ShipPilotProvider } from './provider/ShipPilotProvider.js';
export type { ShipPilotProviderProps } from './provider/ShipPilotProvider.js';
export { useShipPilot, ShipPilotContext } from './provider/ShipPilotContext.js';
export type { RouterAdapter, ShipPilotContextValue } from './provider/ShipPilotContext.js';

export { useShipPilotChat } from './widget/useShipPilotChat.js';
export type {
  UseShipPilotChatOptions,
  UseShipPilotChatReturn,
  ChatWidgetMessage,
} from './widget/useShipPilotChat.js';

export { ChatWidget } from './widget/ChatWidget.js';
export type { ChatWidgetProps } from './widget/ChatWidget.js';

export { executeNavigationSequence } from './navigator/NavigationEngine.js';
export type {
  ExecuteNavigationOptions,
  ExecuteNavigationResult,
  StepFailure,
} from './navigator/NavigationEngine.js';
