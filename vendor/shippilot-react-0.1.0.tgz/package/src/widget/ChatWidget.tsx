import { useState } from 'react';
import { useShipPilot } from '../provider/ShipPilotContext.js';
import { useShipPilotChat } from './useShipPilotChat.js';

export interface ChatWidgetProps {
  position?: 'bottom-right' | 'bottom-left';
  welcomeMessage?: string;
  agentModeLabel?: string;
  placeholder?: string;
  /** Injectable for testing. Uses the default executeNavigationSequence otherwise. */
  fetch?: typeof globalThis.fetch;
}

export function ChatWidget({
  position,
  welcomeMessage,
  agentModeLabel,
  placeholder = 'Type a message...',
  fetch: customFetch,
}: ChatWidgetProps) {
  const { config, router, setAgentMode } = useShipPilot();
  const [isOpen, setIsOpen] = useState(false);
  const resolvedPosition = position ?? config.position ?? 'bottom-right';
  const resolvedWelcomeMessage = welcomeMessage ?? config.welcomeMessage ?? 'Hi! Ask me anything.';
  const resolvedAgentModeLabel = agentModeLabel ?? config.agentModeLabel ?? 'Piloting...';

  const chat = useShipPilotChat({
    chatEndpoint: config.chatEndpoint,
    siteGraph: config.siteGraph,
    router,
    welcomeMessage: resolvedWelcomeMessage,
    fetch: customFetch,
    setAgentMode,
  });

  // When in agent mode, show collapsed pill + the full-viewport agent-border
  // overlay (CSS already defined in ShipPilotProvider — it was never applied
  // anywhere until now).
  if (chat.isAgentMode) {
    return (
      <>
        <div className="shippilot-agent-border" aria-hidden="true" />
        <div
          role="status"
          aria-label={resolvedAgentModeLabel}
          style={{ ...pillStyles, ...positionStyles(resolvedPosition) }}
        >
          {resolvedAgentModeLabel}
        </div>
      </>
    );
  }

  // When closed, show FAB
  if (!isOpen) {
    return (
      <button
        aria-label="Open chat"
        onClick={() => setIsOpen(true)}
        style={{ ...fabStyles, ...positionStyles(resolvedPosition) }}
      >
        💬
      </button>
    );
  }

  // Open panel
  return (
    <div role="dialog" aria-label="Chat" style={{ ...panelStyles, ...positionStyles(resolvedPosition) }}>
      <header style={headerStyles}>
        <span>ShipPilot</span>
        <button aria-label="Close chat" onClick={() => setIsOpen(false)} style={closeButtonStyles}>
          ×
        </button>
      </header>
      <div role="log" style={logStyles}>
        {chat.messages.map((m, i) => (
          <div key={i} data-sender={m.sender} style={messageStyle(m.sender)}>
            {m.text}
          </div>
        ))}
        {chat.currentStreamedText && (
          <div data-sender="bot" data-streaming style={messageStyle('bot')}>
            {chat.currentStreamedText}
          </div>
        )}
        {chat.isLoading && !chat.currentStreamedText && (
          <div role="status" style={messageStyle('bot')}>
            Loading...
          </div>
        )}
      </div>
      {chat.pendingAgentAction && (
        <div style={agentActionStyles}>
          <button
            aria-label="Yes, show me!"
            onClick={() => void chat.confirmNavigation()}
            style={yesButtonStyles}
          >
            Yes, show me!
          </button>
          <button
            aria-label="No thanks"
            onClick={() => chat.declineNavigation()}
            style={noButtonStyles}
          >
            No thanks
          </button>
        </div>
      )}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void chat.sendMessage();
        }}
        style={formStyles}
      >
        <input
          value={chat.input}
          onChange={(e) => chat.setInput(e.target.value)}
          placeholder={placeholder}
          aria-label="Chat input"
          style={inputStyles}
        />
        <button
          type="submit"
          aria-label="Send message"
          disabled={chat.isLoading}
          style={sendButtonStyles}
        >
          Send
        </button>
      </form>
    </div>
  );
}

const positionStyles = (pos: 'bottom-right' | 'bottom-left') => ({
  position: 'fixed' as const,
  bottom: '1.5rem',
  ...(pos === 'bottom-left' ? { left: '1.5rem' } : { right: '1.5rem' }),
});

const fabStyles = {
  width: '56px',
  height: '56px',
  borderRadius: '50%',
  backgroundColor: 'var(--shippilot-accent, #22c55e)',
  border: 'none',
  cursor: 'pointer',
  color: 'white',
  fontSize: '24px',
  boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
  zIndex: 50,
};

const panelStyles = {
  width: '360px',
  height: '500px',
  backgroundColor: '#1a1a1a',
  borderRadius: '16px',
  display: 'flex',
  flexDirection: 'column' as const,
  boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
  zIndex: 50,
  overflow: 'hidden',
};

const pillStyles = {
  padding: '8px 16px',
  borderRadius: '9999px',
  backgroundColor: 'rgba(0,0,0,0.8)',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  zIndex: 50,
};

const headerStyles = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '12px 16px',
  borderBottom: '1px solid rgba(255,255,255,0.1)',
  color: 'white',
};

const closeButtonStyles = {
  background: 'none',
  border: 'none',
  color: 'white',
  cursor: 'pointer',
  fontSize: '20px',
  lineHeight: 1,
  padding: '0 4px',
};

const logStyles = {
  flex: 1,
  overflowY: 'auto' as const,
  padding: '12px 16px',
  display: 'flex',
  flexDirection: 'column' as const,
  gap: '8px',
};

const messageStyle = (sender: 'user' | 'bot') => ({
  alignSelf: sender === 'user' ? 'flex-end' : ('flex-start' as const),
  backgroundColor: sender === 'user' ? 'var(--shippilot-accent, #22c55e)' : 'rgba(255,255,255,0.1)',
  color: 'white',
  borderRadius: '12px',
  padding: '8px 12px',
  maxWidth: '80%',
  fontSize: '14px',
});

const agentActionStyles = {
  display: 'flex',
  gap: '8px',
  padding: '8px 16px',
  borderTop: '1px solid rgba(255,255,255,0.1)',
};

const yesButtonStyles = {
  flex: 1,
  padding: '8px 12px',
  borderRadius: '8px',
  border: 'none',
  backgroundColor: 'var(--shippilot-accent, #22c55e)',
  color: 'white',
  cursor: 'pointer',
  fontSize: '14px',
};

const noButtonStyles = {
  flex: 1,
  padding: '8px 12px',
  borderRadius: '8px',
  border: '1px solid rgba(255,255,255,0.2)',
  backgroundColor: 'transparent',
  color: 'white',
  cursor: 'pointer',
  fontSize: '14px',
};

const formStyles = {
  display: 'flex',
  gap: '8px',
  padding: '12px 16px',
  borderTop: '1px solid rgba(255,255,255,0.1)',
};

const inputStyles = {
  flex: 1,
  padding: '8px 12px',
  borderRadius: '8px',
  border: '1px solid rgba(255,255,255,0.2)',
  backgroundColor: 'rgba(255,255,255,0.05)',
  color: 'white',
  fontSize: '14px',
  outline: 'none',
};

const sendButtonStyles = {
  padding: '8px 16px',
  borderRadius: '8px',
  border: 'none',
  backgroundColor: 'var(--shippilot-accent, #22c55e)',
  color: 'white',
  cursor: 'pointer',
  fontSize: '14px',
};
