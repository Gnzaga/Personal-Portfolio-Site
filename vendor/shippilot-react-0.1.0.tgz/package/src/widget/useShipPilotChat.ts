import { useState, useCallback, useRef, useEffect } from 'react';
import type { SiteGraph, AgentAction, NavigationStep } from '@shippilot/core/browser';
import { extractAgentAction, stripAgentTags, computeNavigationSteps } from '@shippilot/core/browser';
import type { RouterAdapter } from '../provider/ShipPilotContext.js';
import { executeNavigationSequence } from '../navigator/NavigationEngine.js';
import type { ExecuteNavigationResult } from '../navigator/NavigationEngine.js';

export type ChatWidgetMessage = { sender: 'user' | 'bot'; text: string };

export interface UseShipPilotChatOptions {
  chatEndpoint: string;
  siteGraph: SiteGraph;
  router: RouterAdapter;
  welcomeMessage?: string;
  maxHistoryMessages?: number;
  fetch?: typeof globalThis.fetch;
  executeNavigation?: (
    steps: NavigationStep[],
    adapter: RouterAdapter,
    options?: { signal?: AbortSignal }
  ) => Promise<ExecuteNavigationResult>;
  setAgentMode?: (active: boolean) => void;
}

export interface UseShipPilotChatReturn {
  messages: ChatWidgetMessage[];
  input: string;
  setInput: (v: string) => void;
  sendMessage: () => Promise<void>;
  isLoading: boolean;
  currentStreamedText: string;
  pendingAgentAction: AgentAction | null;
  confirmNavigation: () => Promise<void>;
  declineNavigation: () => void;
  isAgentMode: boolean;
}

export function useShipPilotChat(options: UseShipPilotChatOptions): UseShipPilotChatReturn {
  const {
    chatEndpoint,
    siteGraph,
    router,
    welcomeMessage,
    maxHistoryMessages = 10,
    fetch: fetchFn = globalThis.fetch,
    executeNavigation = executeNavigationSequence,
    setAgentMode,
  } = options;

  const [messages, setMessages] = useState<ChatWidgetMessage[]>(() =>
    welcomeMessage ? [{ sender: 'bot', text: welcomeMessage }] : []
  );
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentStreamedText, setCurrentStreamedText] = useState('');
  const [pendingAgentAction, setPendingAgentAction] = useState<AgentAction | null>(null);
  const [isAgentMode, setIsAgentMode] = useState(false);

  const updateAgentMode = useCallback(
    (active: boolean) => {
      setIsAgentMode(active);
      setAgentMode?.(active);
    },
    [setAgentMode]
  );

  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const sendMessage = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;

    const userMsg: ChatWidgetMessage = { sender: 'user', text: trimmed };

    // Build history BEFORE the state update so we have the current messages
    const allMessages = [...messages, userMsg];
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setCurrentStreamedText('');

    // Build history from existing messages + new user message
    const history = allMessages
      .slice(-maxHistoryMessages)
      .map((m) => ({
        role: m.sender === 'user' ? 'user' : 'assistant',
        content: m.text,
      }));

    try {
      const response = await fetchFn(chatEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          currentPage: router.getCurrentPath(),
          history,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body!.getReader();
      const decoder = new TextDecoder('utf-8');
      let buf = '';
      let full = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const parts = buf.split(/\r?\n/);
        buf = parts.pop() ?? '';
        for (let line of parts) {
          line = line.trim();
          if (!line.startsWith('data:')) continue;
          const content = line.slice(5).trim();
          if (content === '[DONE]') break;
          try {
            const json = JSON.parse(content) as Record<string, unknown>;
            const choices = json['choices'] as Array<{ delta?: { content?: string } }> | undefined;
            const token =
              (json['delta'] as string | undefined) ??
              (choices?.[0]?.delta?.content) ??
              undefined;
            if (token !== undefined) {
              full += token;
              setCurrentStreamedText(stripAgentTags(full));
            }
          } catch {
            // ignore malformed lines
          }
        }
      }

      if (full) {
        const { cleanedText, agentAction } = extractAgentAction(full);
        setMessages((prev) => [...prev, { sender: 'bot', text: cleanedText }]);
        if (agentAction) {
          setPendingAgentAction(agentAction);
        }
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { sender: 'bot', text: 'Oops! Something went wrong.' },
      ]);
    } finally {
      setIsLoading(false);
      setCurrentStreamedText('');
    }
  }, [input, isLoading, messages, chatEndpoint, router, maxHistoryMessages, fetchFn]);

  const NAVIGATION_FAILURE_MESSAGE =
    "I couldn't complete the navigation — I've taken you as far as I could.";

  const confirmNavigation = useCallback(async () => {
    const action = pendingAgentAction;
    if (!action) return;

    setPendingAgentAction(null);
    setMessages((prev) => [...prev, { sender: 'user', text: 'Yes, show me!' }]);

    const currentPath = router.getCurrentPath();
    const destination = action.nav ?? currentPath;

    let steps: NavigationStep[] = [];
    let planFailed = false;
    try {
      steps = computeNavigationSteps(siteGraph, currentPath, destination, action.target ?? null);
    } catch {
      planFailed = true;
    }

    // Dynamic destinations (and any other case pathfinder refuses to plan)
    // produce an empty step list even though we're not already there —
    // that's a real "can't get you there," not a no-op.
    const nothingToPlan = destination !== currentPath && steps.length === 0;

    if (planFailed || nothingToPlan) {
      setMessages((prev) => [...prev, { sender: 'bot', text: NAVIGATION_FAILURE_MESSAGE }]);
      return;
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    // If the user manually navigates somewhere the plan never anticipated
    // while the sequence is running, stop piloting rather than fight them.
    const plannedRoutes = new Set<string>([currentPath]);
    for (const step of steps) {
      if ('route' in step) plannedRoutes.add(step.route);
    }
    const watchdogId = setInterval(() => {
      if (!plannedRoutes.has(router.getCurrentPath())) {
        controller.abort();
      }
    }, 250);

    updateAgentMode(true);
    let result: ExecuteNavigationResult | null = null;
    try {
      result = await executeNavigation(steps, router, { signal: controller.signal });
    } catch {
      result = null;
    } finally {
      clearInterval(watchdogId);
      abortControllerRef.current = null;
      updateAgentMode(false);
    }

    if (!result || !result.completed) {
      setMessages((prev) => [...prev, { sender: 'bot', text: NAVIGATION_FAILURE_MESSAGE }]);
    }
  }, [pendingAgentAction, router, siteGraph, executeNavigation, updateAgentMode]);

  const declineNavigation = useCallback(() => {
    setPendingAgentAction(null);
    setMessages((prev) => [...prev, { sender: 'user', text: 'No thanks.' }]);
  }, []);

  return {
    messages,
    input,
    setInput,
    sendMessage,
    isLoading,
    currentStreamedText,
    pendingAgentAction,
    confirmNavigation,
    declineNavigation,
    isAgentMode,
  };
}
