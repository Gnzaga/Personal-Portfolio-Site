import type { NavigationStep } from '@shippilot/core/browser';
import type { RouterAdapter } from '../provider/ShipPilotContext.js';

export interface ExecuteNavigationOptions {
  /** Injectable wait function for testing. Default: setTimeout-based */
  waitFn?: (ms: number) => Promise<void>;
  /** Aborts the sequence between steps when triggered. */
  signal?: AbortSignal;
}

export interface StepFailure {
  step: NavigationStep;
  reason: string;
}

export interface ExecuteNavigationResult {
  completed: boolean;
  failedSteps: StepFailure[];
}

const POLL_INTERVAL_MS = 100;
const POLL_TIMEOUT_MS = 3000;

const defaultWait = (ms: number): Promise<void> =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

function queryTarget(target: string): HTMLElement | null {
  return document.querySelector<HTMLElement>(`[data-agent-target="${target}"]`);
}

/**
 * Polls `check` every POLL_INTERVAL_MS until it returns true, or gives up
 * after POLL_TIMEOUT_MS. Checks immediately before the first wait so a
 * router that updates synchronously never pays a polling penalty.
 */
async function pollUntil(
  check: () => boolean,
  wait: (ms: number) => Promise<void>,
): Promise<boolean> {
  if (check()) return true;
  let elapsed = 0;
  while (elapsed < POLL_TIMEOUT_MS) {
    await wait(POLL_INTERVAL_MS);
    elapsed += POLL_INTERVAL_MS;
    if (check()) return true;
  }
  return false;
}

function waitForRoute(
  adapter: RouterAdapter,
  expectedRoute: string,
  wait: (ms: number) => Promise<void>,
): Promise<boolean> {
  return pollUntil(() => adapter.getCurrentPath() === expectedRoute, wait);
}

interface StepOutcome {
  failure?: StepFailure;
}

async function executeStep(
  step: NavigationStep,
  adapter: RouterAdapter,
  wait: (ms: number) => Promise<void>
): Promise<StepOutcome> {
  switch (step.action) {
    case 'navClick': {
      const el = queryTarget(step.navTarget);
      if (el) {
        el.classList.add('shippilot-nav-highlight');
        await wait(900);
        el.classList.add('shippilot-nav-click');
        await wait(400);
      }
      adapter.navigate(step.route);
      const arrived = await waitForRoute(adapter, step.route, wait);
      if (el) {
        el.classList.remove('shippilot-nav-highlight', 'shippilot-nav-click');
      }
      return arrived
        ? {}
        : { failure: { step, reason: `Timed out waiting for navigation to ${step.route}` } };
    }

    case 'scroll': {
      await wait(500);
      const el = queryTarget(step.target);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await wait(800);
      }
      return {};
    }

    case 'highlight': {
      const el = queryTarget(step.target);
      if (el) {
        el.classList.add('shippilot-highlight');
        await wait(step.duration);
        el.classList.remove('shippilot-highlight');
      }
      return {};
    }

    case 'clickDetail': {
      const el = queryTarget(step.target);

      if (!el) {
        // No DOM element to click (stale/synthesized target ID) — fall
        // back to a direct route change so the sequence still reaches
        // the page instead of silently doing nothing.
        adapter.navigate(step.route);
        const arrived = await waitForRoute(adapter, step.route, wait);
        return arrived
          ? {}
          : { failure: { step, reason: `Timed out waiting for navigation to ${step.route}` } };
      }

      await wait(300);
      el.classList.add('shippilot-nav-highlight');
      await wait(700);
      el.classList.add('shippilot-nav-click');
      await wait(400);
      el.click();
      const arrived = await waitForRoute(adapter, step.route, wait);
      el.classList.remove('shippilot-nav-highlight', 'shippilot-nav-click');
      return arrived
        ? {}
        : { failure: { step, reason: `Timed out waiting for navigation to ${step.route}` } };
    }

    case 'directNav': {
      adapter.navigate(step.route);
      const arrived = await waitForRoute(adapter, step.route, wait);
      return arrived
        ? {}
        : { failure: { step, reason: `Timed out waiting for navigation to ${step.route}` } };
    }

    default:
      return {};
  }
}

export async function executeNavigationSequence(
  steps: NavigationStep[],
  adapter: RouterAdapter,
  options?: ExecuteNavigationOptions
): Promise<ExecuteNavigationResult> {
  const wait = options?.waitFn ?? defaultWait;
  const signal = options?.signal;
  const failedSteps: StepFailure[] = [];

  for (const step of steps) {
    if (signal?.aborted) {
      return { completed: false, failedSteps };
    }

    try {
      const { failure } = await executeStep(step, adapter, wait);
      if (failure) failedSteps.push(failure);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      console.warn('[ShipPilot] NavigationEngine step failed:', err);
      failedSteps.push({ step, reason });
    }
  }

  return { completed: failedSteps.length === 0, failedSteps };
}
