import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { executeNavigationSequence } from '../src/navigator/NavigationEngine.js';
import type { RouterAdapter } from '../src/provider/ShipPilotContext.js';
import type { NavigationStep } from '@shippilot/core';

/** A router that behaves like a real one: navigate() synchronously updates what getCurrentPath() reports. */
function createMockRouter(initialPath = '/'): RouterAdapter {
  let currentPath = initialPath;
  return {
    getCurrentPath: vi.fn(() => currentPath),
    navigate: vi.fn((to: string) => { currentPath = to; }),
  };
}

/** A router whose navigate() never actually changes the reported path — forces the bounded-polling timeout path. */
function createStuckRouter(initialPath = '/'): RouterAdapter {
  return {
    getCurrentPath: vi.fn(() => initialPath),
    navigate: vi.fn(),
  };
}

function createTarget(id: string): HTMLElement {
  const el = document.createElement('div');
  el.setAttribute('data-agent-target', id);
  document.body.appendChild(el);
  return el;
}

describe('executeNavigationSequence', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    document.body.innerHTML = '';
  });

  afterEach(() => {
    vi.useRealTimers();
    document.body.innerHTML = '';
  });

  // ─── navClick ────────────────────────────────────────────────────────────────

  it('navClick: adds shippilot-nav-highlight class to target element', async () => {
    const el = createTarget('nav-about');
    const router = createMockRouter();
    const step: NavigationStep = { action: 'navClick', navTarget: 'nav-about', route: '/about' };

    const promise = executeNavigationSequence([step], router);
    await vi.advanceTimersByTimeAsync(900);
    expect(el.classList.contains('shippilot-nav-highlight')).toBe(true);
    await vi.runAllTimersAsync();
    await promise;
  });

  it('navClick: adds shippilot-nav-click class after 900+400ms', async () => {
    const el = createTarget('nav-about');
    const router = createMockRouter();
    const step: NavigationStep = { action: 'navClick', navTarget: 'nav-about', route: '/about' };

    const promise = executeNavigationSequence([step], router);
    // The nav-click glow is added right after the 900ms highlight phase.
    // Sample inside the glow window (before the 1300ms mark, where the
    // synchronous mock router's instant route-match removes both classes).
    await vi.advanceTimersByTimeAsync(1200);
    expect(el.classList.contains('shippilot-nav-click')).toBe(true);
    await vi.runAllTimersAsync();
    await promise;
  });

  it('navClick: calls adapter.navigate with correct route', async () => {
    createTarget('nav-about');
    const router = createMockRouter();
    const step: NavigationStep = { action: 'navClick', navTarget: 'nav-about', route: '/about' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    await promise;

    expect(router.navigate).toHaveBeenCalledWith('/about');
  });

  it('navClick: removes both classes after full sequence', async () => {
    const el = createTarget('nav-about');
    const router = createMockRouter();
    const step: NavigationStep = { action: 'navClick', navTarget: 'nav-about', route: '/about' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    await promise;

    expect(el.classList.contains('shippilot-nav-highlight')).toBe(false);
    expect(el.classList.contains('shippilot-nav-click')).toBe(false);
  });

  it('navClick: skips gracefully when element is not found, still navigates and completes', async () => {
    const router = createMockRouter();
    const step: NavigationStep = { action: 'navClick', navTarget: 'nav-missing', route: '/missing' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    const result = await promise;

    expect(result).toEqual({ completed: true, failedSteps: [] });
    expect(router.navigate).toHaveBeenCalledWith('/missing');
  });

  it('navClick: reports a failed step when the route never changes (bounded timeout)', async () => {
    const router = createStuckRouter('/');
    const step: NavigationStep = { action: 'navClick', navTarget: 'nav-stuck', route: '/stuck' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    const result = await promise;

    expect(result.completed).toBe(false);
    expect(result.failedSteps).toEqual([
      { step, reason: 'Timed out waiting for navigation to /stuck' },
    ]);
  });

  // ─── scroll ──────────────────────────────────────────────────────────────────

  it('scroll: calls scrollIntoView on target element with correct options', async () => {
    const el = createTarget('section-work');
    el.scrollIntoView = vi.fn();
    const router = createMockRouter();
    const step: NavigationStep = { action: 'scroll', target: 'section-work' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    await promise;

    expect(el.scrollIntoView).toHaveBeenCalledWith({ behavior: 'smooth', block: 'center' });
  });

  it('scroll: skips gracefully when element is missing', async () => {
    const router = createMockRouter();
    const step: NavigationStep = { action: 'scroll', target: 'section-missing' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    const result = await promise;
    expect(result).toEqual({ completed: true, failedSteps: [] });
  });

  // ─── highlight ───────────────────────────────────────────────────────────────

  it('highlight: adds shippilot-highlight class then removes after duration', async () => {
    const el = createTarget('card-homelab');
    const router = createMockRouter();
    const step: NavigationStep = { action: 'highlight', target: 'card-homelab', duration: 1000 };

    const promise = executeNavigationSequence([step], router);
    await vi.advanceTimersByTimeAsync(500);
    expect(el.classList.contains('shippilot-highlight')).toBe(true);
    await vi.runAllTimersAsync();
    await promise;
    expect(el.classList.contains('shippilot-highlight')).toBe(false);
  });

  it('highlight: respects step.duration timing precisely', async () => {
    const el = createTarget('card-homelab');
    const router = createMockRouter();
    const step: NavigationStep = { action: 'highlight', target: 'card-homelab', duration: 2000 };

    const promise = executeNavigationSequence([step], router, {
      waitFn: (ms) => new Promise((r) => setTimeout(r, ms)),
    });
    await vi.advanceTimersByTimeAsync(1999);
    expect(el.classList.contains('shippilot-highlight')).toBe(true);
    await vi.advanceTimersByTimeAsync(100);
    expect(el.classList.contains('shippilot-highlight')).toBe(false);
    await promise;
  });

  // ─── clickDetail ─────────────────────────────────────────────────────────────

  it('clickDetail: calls .click() on target element', async () => {
    const el = createTarget('card-homelab-link');
    el.click = vi.fn();
    const router = createMockRouter();
    const step: NavigationStep = { action: 'clickDetail', target: 'card-homelab-link', route: '/projects/homelab' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    await promise;

    expect(el.click).toHaveBeenCalled();
  });

  it('clickDetail: adds and removes animation classes in correct order', async () => {
    const el = createTarget('card-homelab-link');
    el.click = vi.fn();
    const router = createMockRouter();
    const step: NavigationStep = { action: 'clickDetail', target: 'card-homelab-link', route: '/projects/homelab' };

    const promise = executeNavigationSequence([step], router);

    await vi.advanceTimersByTimeAsync(300);
    expect(el.classList.contains('shippilot-nav-highlight')).toBe(true);

    await vi.advanceTimersByTimeAsync(700);
    expect(el.classList.contains('shippilot-nav-click')).toBe(true);

    await vi.runAllTimersAsync();
    await promise;

    expect(el.classList.contains('shippilot-nav-highlight')).toBe(false);
    expect(el.classList.contains('shippilot-nav-click')).toBe(false);
  });

  it('clickDetail: falls back to adapter.navigate(route) when the element is not found', async () => {
    const router = createMockRouter();
    const step: NavigationStep = { action: 'clickDetail', target: 'card-missing-link', route: '/projects/missing' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    const result = await promise;

    expect(router.navigate).toHaveBeenCalledWith('/projects/missing');
    expect(result).toEqual({ completed: true, failedSteps: [] });
  });

  it('clickDetail: reports a failed step when the fallback route never changes', async () => {
    const router = createStuckRouter('/projects');
    const step: NavigationStep = { action: 'clickDetail', target: 'card-missing-link', route: '/projects/stuck' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    const result = await promise;

    expect(result.completed).toBe(false);
    expect(result.failedSteps).toEqual([
      { step, reason: 'Timed out waiting for navigation to /projects/stuck' },
    ]);
  });

  // ─── directNav ───────────────────────────────────────────────────────────────

  it('directNav: calls adapter.navigate with route', async () => {
    const router = createMockRouter();
    const step: NavigationStep = { action: 'directNav', route: '/projects' };

    const promise = executeNavigationSequence([step], router);
    await vi.runAllTimersAsync();
    await promise;

    expect(router.navigate).toHaveBeenCalledWith('/projects');
  });

  // ─── Sequence ────────────────────────────────────────────────────────────────

  it('sequence: executes multiple steps in order (navClick then scroll)', async () => {
    const callOrder: string[] = [];

    createTarget('nav-projects');
    const scrollEl = createTarget('section-projects');
    scrollEl.scrollIntoView = vi.fn(() => callOrder.push('scrollIntoView'));

    const router = createMockRouter();
    (router.navigate as ReturnType<typeof vi.fn>).mockImplementation(() => callOrder.push('navigate'));

    const steps: NavigationStep[] = [
      { action: 'navClick', navTarget: 'nav-projects', route: '/projects' },
      { action: 'scroll', target: 'section-projects' },
    ];

    const promise = executeNavigationSequence(steps, router);
    await vi.runAllTimersAsync();
    await promise;

    const navigateIdx = callOrder.indexOf('navigate');
    const scrollIdx = callOrder.indexOf('scrollIntoView');
    expect(navigateIdx).toBeGreaterThanOrEqual(0);
    expect(scrollIdx).toBeGreaterThanOrEqual(0);
    expect(navigateIdx).toBeLessThan(scrollIdx);
  });

  // ─── Error handling ───────────────────────────────────────────────────────────

  it('error handling: continues sequence when middle step has missing element, reports success, keeps going', async () => {
    createTarget('nav-about');
    const scrollEl = createTarget('section-about');
    scrollEl.scrollIntoView = vi.fn();
    const router = createMockRouter();

    const steps: NavigationStep[] = [
      { action: 'navClick', navTarget: 'nav-about', route: '/about' },
      { action: 'scroll', target: 'section-MISSING' },
      { action: 'scroll', target: 'section-about' },
    ];

    const promise = executeNavigationSequence(steps, router);
    await vi.runAllTimersAsync();
    const result = await promise;

    expect(result).toEqual({ completed: true, failedSteps: [] });
    expect(scrollEl.scrollIntoView).toHaveBeenCalledWith({ behavior: 'smooth', block: 'center' });
  });

  // ─── Abort ────────────────────────────────────────────────────────────────────

  describe('abort handling', () => {
    it('stops the sequence before any step when the signal is already aborted', async () => {
      createTarget('nav-about');
      const scrollEl = createTarget('section-about');
      scrollEl.scrollIntoView = vi.fn();
      const router = createMockRouter();
      const controller = new AbortController();
      controller.abort();

      const steps: NavigationStep[] = [
        { action: 'navClick', navTarget: 'nav-about', route: '/about' },
        { action: 'scroll', target: 'section-about' },
      ];

      const promise = executeNavigationSequence(steps, router, { signal: controller.signal });
      await vi.runAllTimersAsync();
      const result = await promise;

      expect(result).toEqual({ completed: false, failedSteps: [] });
      expect(router.navigate).not.toHaveBeenCalled();
      expect(scrollEl.scrollIntoView).not.toHaveBeenCalled();
    });

    it('stops before executing the second step when aborted mid-sequence', async () => {
      const scrollEl = createTarget('section-about');
      scrollEl.scrollIntoView = vi.fn();
      const router = createMockRouter();
      const controller = new AbortController();

      const steps: NavigationStep[] = [
        { action: 'directNav', route: '/about' },
        { action: 'scroll', target: 'section-about' },
      ];

      const promise = executeNavigationSequence(steps, router, { signal: controller.signal });
      controller.abort();
      await vi.runAllTimersAsync();
      const result = await promise;

      expect(result.completed).toBe(false);
      expect(router.navigate).toHaveBeenCalledWith('/about');
      expect(scrollEl.scrollIntoView).not.toHaveBeenCalled();
    });
  });
});
