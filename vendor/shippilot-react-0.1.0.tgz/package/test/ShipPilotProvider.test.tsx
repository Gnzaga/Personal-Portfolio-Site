import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, renderHook, act } from '@testing-library/react';
import type { ReactNode } from 'react';
import type { ShipPilotConfig, SiteGraph } from '@shippilot/core';
import { ShipPilotProvider } from '../src/provider/ShipPilotProvider.js';
import { useShipPilot } from '../src/provider/ShipPilotContext.js';
import type { RouterAdapter } from '../src/provider/ShipPilotContext.js';

const testGraph: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  generatedAt: '2026-01-01T00:00:00.000Z',
  pageCount: 1,
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Home',
      contentChunks: [],
    },
  },
  edges: [],
};

const testConfig: ShipPilotConfig = {
  chatEndpoint: '/chat',
  siteGraph: testGraph,
  accentColor: '#22c55e',
};

const testRouter: RouterAdapter = {
  getCurrentPath: () => '/',
  navigate: () => {},
};

function wrapper({ children }: { children: ReactNode }) {
  return (
    <ShipPilotProvider config={testConfig} router={testRouter}>
      {children}
    </ShipPilotProvider>
  );
}

beforeEach(() => {
  document.querySelector('#shippilot-styles')?.remove();
});

afterEach(() => {
  document.querySelector('#shippilot-styles')?.remove();
});

describe('ShipPilotProvider', () => {
  it('useShipPilot throws outside provider', () => {
    expect(() => {
      renderHook(() => useShipPilot());
    }).toThrow();
  });

  it('useShipPilot returns config from provider', () => {
    const { result } = renderHook(() => useShipPilot(), { wrapper });
    expect(result.current.config).toBe(testConfig);
  });

  it('useShipPilot returns router from provider', () => {
    const { result } = renderHook(() => useShipPilot(), { wrapper });
    expect(result.current.router).toBe(testRouter);
  });

  it('isAgentMode defaults to false', () => {
    const { result } = renderHook(() => useShipPilot(), { wrapper });
    expect(result.current.isAgentMode).toBe(false);
  });

  it('setAgentMode(true) updates isAgentMode', () => {
    const { result } = renderHook(() => useShipPilot(), { wrapper });
    act(() => {
      result.current.setAgentMode(true);
    });
    expect(result.current.isAgentMode).toBe(true);
  });

  it('injects <style id="shippilot-styles"> on mount', () => {
    render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <div />
      </ShipPilotProvider>,
    );
    expect(document.querySelector('#shippilot-styles')).not.toBeNull();
  });

  it('removes style tag on unmount', () => {
    const { unmount } = render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <div />
      </ShipPilotProvider>,
    );
    unmount();
    expect(document.querySelector('#shippilot-styles')).toBeNull();
  });

  it('idempotent — two providers create only one style tag', () => {
    render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <ShipPilotProvider config={testConfig} router={testRouter}>
          <div />
        </ShipPilotProvider>
      </ShipPilotProvider>,
    );
    expect(document.querySelectorAll('#shippilot-styles').length).toBe(1);
  });

  it('style tag includes shippilot-highlight and shippilot-nav-highlight classes', () => {
    render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <div />
      </ShipPilotProvider>,
    );
    const styleEl = document.querySelector('#shippilot-styles');
    expect(styleEl?.textContent).toContain('shippilot-highlight');
    expect(styleEl?.textContent).toContain('shippilot-nav-highlight');
  });
});
