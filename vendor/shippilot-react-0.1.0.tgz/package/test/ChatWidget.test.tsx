import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import type { ReactNode } from 'react';
import type { ShipPilotConfig, SiteGraph } from '@shippilot/core';
import { ChatWidget } from '../src/widget/ChatWidget.js';
import { ShipPilotProvider } from '../src/provider/ShipPilotProvider.js';
import { useShipPilot } from '../src/provider/ShipPilotContext.js';
import type { RouterAdapter } from '../src/provider/ShipPilotContext.js';

const testGraph: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  generatedAt: '2026-01-01T00:00:00.000Z',
  pageCount: 2,
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Home',
      contentChunks: [],
    },
    '/about': {
      path: '/about',
      type: 'top-level',
      navbar: 'nav-about',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'About',
      contentChunks: [],
    },
  },
  edges: [],
};

const testConfig: ShipPilotConfig = {
  chatEndpoint: '/chat',
  siteGraph: testGraph,
  position: 'bottom-left',
  welcomeMessage: 'Configured welcome message.',
  agentModeLabel: 'Configured agent mode.',
};

let testRouter: RouterAdapter;

function createStatefulTestRouter(initialPath = '/'): RouterAdapter {
  let currentPath = initialPath;
  return {
    getCurrentPath: () => currentPath,
    // Real routers don't update synchronously within the same tick — model
    // that here so NavigationEngine's bounded polling has something
    // realistic to poll, instead of resolving in 0ms every time.
    navigate: vi.fn((to: string) => {
      setTimeout(() => { currentPath = to; }, 50);
    }),
  };
}

beforeEach(() => {
  testRouter = createStatefulTestRouter();
});

function mockStreamingFetch(chunks: string[]): typeof globalThis.fetch {
  return vi.fn(async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        for (const chunk of chunks) controller.enqueue(encoder.encode(chunk));
        controller.close();
      },
    });
    return new Response(stream, { status: 200 });
  }) as typeof globalThis.fetch;
}

function renderWithProvider(ui: ReactNode) {
  return render(
    <ShipPilotProvider config={testConfig} router={testRouter}>
      {ui}
    </ShipPilotProvider>
  );
}

function AgentModeProbe() {
  const { isAgentMode } = useShipPilot();
  return <div data-testid="agent-mode">{String(isAgentMode)}</div>;
}

afterEach(() => {
  document.querySelector('#shippilot-styles')?.remove();
});

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('ChatWidget', () => {
  it('renders toggle button (FAB) when closed', () => {
    renderWithProvider(<ChatWidget />);
    expect(screen.getByRole('button', { name: 'Open chat' })).toBeInTheDocument();
  });

  it('opens panel when toggle clicked', () => {
    renderWithProvider(<ChatWidget />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    expect(screen.getByRole('dialog', { name: 'Chat' })).toBeInTheDocument();
  });

  it('shows welcome message in panel when opened', () => {
    renderWithProvider(<ChatWidget welcomeMessage="Hi there!" />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    expect(screen.getByText('Hi there!')).toBeInTheDocument();
  });

  it('uses provider config defaults for position, welcome message, and agent mode label', async () => {
    const fetchWithAgent = mockStreamingFetch([
      `data: ${JSON.stringify({ delta: 'Go to about [[AGENT:{"nav":"/about"}]]' })}\n\n`,
      'data: [DONE]\n\n',
    ]);

    render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <ChatWidget fetch={fetchWithAgent} />
      </ShipPilotProvider>
    );

    expect(screen.getByRole('button', { name: 'Open chat' })).toHaveStyle({ left: '1.5rem' });

    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    expect(screen.getByText('Configured welcome message.')).toBeInTheDocument();

    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'take me to about' } });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Send message' }));
    });

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /yes, show me/i })).toBeInTheDocument();
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /yes, show me/i }));
    });

    await waitFor(() => {
      expect(screen.getByRole('status', { name: 'Configured agent mode.' })).toBeInTheDocument();
    });
  });

  it('mirrors the active agent-mode transition into provider context', async () => {
    const fetchWithAgent = mockStreamingFetch([
      `data: ${JSON.stringify({ delta: 'Go to about [[AGENT:{"nav":"/about"}]]' })}\n\n`,
      'data: [DONE]\n\n',
    ]);

    render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <AgentModeProbe />
        <ChatWidget fetch={fetchWithAgent} />
      </ShipPilotProvider>
    );

    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'take me to about' } });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Send message' }));
    });

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /yes, show me/i })).toBeInTheDocument();
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /yes, show me/i }));
    });

    await waitFor(() => {
      expect(screen.getByTestId('agent-mode')).toHaveTextContent('true');
    });

    await waitFor(
      () => {
        expect(screen.getByTestId('agent-mode')).toHaveTextContent('false');
      },
      { timeout: 5000 }
    );
  });

  it('closes panel when close button clicked', () => {
    renderWithProvider(<ChatWidget />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    expect(screen.getByRole('dialog', { name: 'Chat' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Close chat' }));
    expect(screen.queryByRole('dialog', { name: 'Chat' })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Open chat' })).toBeInTheDocument();
  });

  it('typing in input updates displayed value', () => {
    renderWithProvider(<ChatWidget />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'hello world' } });
    expect((input as HTMLInputElement).value).toBe('hello world');
  });

  it('clicking send triggers fetch', async () => {
    const fetchMock = mockStreamingFetch([
      `data: ${JSON.stringify({ delta: 'Hello!' })}\n\n`,
      'data: [DONE]\n\n',
    ]);

    renderWithProvider(<ChatWidget fetch={fetchMock} />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));

    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'test message' } });
    fireEvent.click(screen.getByRole('button', { name: 'Send message' }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledTimes(1);
    });
  });

  it('displays user message after sending', async () => {
    const fetchMock = mockStreamingFetch([
      `data: ${JSON.stringify({ delta: 'Hello!' })}\n\n`,
      'data: [DONE]\n\n',
    ]);

    renderWithProvider(<ChatWidget fetch={fetchMock} />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));

    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'my question' } });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Send message' }));
    });

    expect(screen.getByText('my question')).toBeInTheDocument();
  });

  it('shows Yes/No buttons when agent action is pending', async () => {
    const fetchWithAgent = mockStreamingFetch([
      `data: ${JSON.stringify({ delta: 'Go to about [[AGENT:{"nav":"/about"}]]' })}\n\n`,
      'data: [DONE]\n\n',
    ]);

    renderWithProvider(<ChatWidget fetch={fetchWithAgent} />);
    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));

    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'take me to about' } });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Send message' }));
    });

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /yes, show me/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /no thanks/i })).toBeInTheDocument();
    });
  });

  it('renders the shippilot-agent-border overlay while piloting, removes it after', async () => {
    const fetchWithAgent = mockStreamingFetch([
      `data: ${JSON.stringify({ delta: 'Go to about [[AGENT:{"nav":"/about"}]]' })}\n\n`,
      'data: [DONE]\n\n',
    ]);

    render(
      <ShipPilotProvider config={testConfig} router={testRouter}>
        <ChatWidget fetch={fetchWithAgent} />
      </ShipPilotProvider>
    );

    fireEvent.click(screen.getByRole('button', { name: 'Open chat' }));
    const input = screen.getByRole('textbox', { name: 'Chat input' });
    fireEvent.change(input, { target: { value: 'take me to about' } });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Send message' }));
    });

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /yes, show me/i })).toBeInTheDocument();
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /yes, show me/i }));
    });

    await waitFor(() => {
      expect(document.querySelector('.shippilot-agent-border')).not.toBeNull();
    });

    await waitFor(
      () => {
        expect(document.querySelector('.shippilot-agent-border')).toBeNull();
      },
      { timeout: 5000 }
    );
  });
});
