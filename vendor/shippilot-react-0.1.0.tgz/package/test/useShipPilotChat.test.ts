import { describe, it, expect, vi } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import type { SiteGraph } from '@shippilot/core';
import {
  useShipPilotChat,
  type UseShipPilotChatOptions,
} from '../src/widget/useShipPilotChat.js';
import type { RouterAdapter } from '../src/provider/ShipPilotContext.js';

// ─────────────────────────────────────────────────────────────────────────────
// Minimal test graph
// ─────────────────────────────────────────────────────────────────────────────

const testGraph: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  generatedAt: '2026-01-01T00:00:00.000Z',
  pageCount: 3,
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Home',
      contentChunks: [],
    },
    '/about': {
      path: '/about',
      type: 'top-level',
      navbar: 'nav-about',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'About',
      contentChunks: [],
    },
    '/projects': {
      path: '/projects',
      type: 'top-level',
      navbar: 'nav-projects',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Projects',
      contentChunks: [],
    },
  },
  edges: [],
};

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function mockStreamingFetch(sseChunks: string[]): typeof globalThis.fetch {
  return vi.fn(async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        for (const chunk of sseChunks) {
          controller.enqueue(encoder.encode(chunk));
        }
        controller.close();
      },
    });
    return new Response(stream, { status: 200 });
  }) as typeof globalThis.fetch;
}

function failingFetch(): typeof globalThis.fetch {
  return vi.fn(async () => {
    throw new Error('network');
  }) as typeof globalThis.fetch;
}

function createMockRouter(path = '/'): RouterAdapter {
  return { getCurrentPath: vi.fn(() => path), navigate: vi.fn() };
}

function baseOptions(overrides: Partial<UseShipPilotChatOptions> = {}): UseShipPilotChatOptions {
  return {
    chatEndpoint: '/chat',
    siteGraph: testGraph,
    router: createMockRouter(),
    welcomeMessage: 'Hi there!',
    fetch: mockStreamingFetch(['data: {"delta":"Hello"}\n\n', 'data: [DONE]\n\n']),
    executeNavigation: vi.fn(async () => ({ completed: true, failedSteps: [] })),
    ...overrides,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Initial state
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — initial state', () => {
  it('messages contains welcome message when welcomeMessage provided', () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    expect(result.current.messages).toHaveLength(1);
    expect(result.current.messages[0]).toEqual({ sender: 'bot', text: 'Hi there!' });
  });

  it('messages is empty array when no welcomeMessage', () => {
    const opts = baseOptions({ welcomeMessage: undefined });
    const { result } = renderHook(() => useShipPilotChat(opts));
    expect(result.current.messages).toHaveLength(0);
  });

  it('isLoading starts false', () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    expect(result.current.isLoading).toBe(false);
  });

  it('pendingAgentAction starts null', () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    expect(result.current.pendingAgentAction).toBeNull();
  });

  it('isAgentMode starts false and currentStreamedText starts empty string', () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    expect(result.current.isAgentMode).toBe(false);
    expect(result.current.currentStreamedText).toBe('');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// sendMessage basic
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — sendMessage basic', () => {
  it('adds user message to messages immediately on sendMessage call', async () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    act(() => { result.current.setInput('hello'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(result.current.messages.some(m => m.sender === 'user' && m.text === 'hello')).toBe(true);
  });

  it('isLoading becomes true during fetch', async () => {
    let resolveResponse: (r: Response) => void;
    const hangingFetch = vi.fn(
      () => new Promise<Response>((resolve) => { resolveResponse = resolve; })
    ) as typeof globalThis.fetch;

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: hangingFetch }))
    );

    act(() => { result.current.setInput('hi'); });

    // Start sendMessage but don't await - just kick it off
    act(() => { void result.current.sendMessage(); });

    // isLoading should be true now (after user message added and fetch started)
    await waitFor(() => {
      expect(result.current.isLoading).toBe(true);
    });

    // Clean up: resolve the fetch to avoid dangling promises
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(c) {
        c.enqueue(encoder.encode('data: [DONE]\n\n'));
        c.close();
      },
    });
    resolveResponse!(new Response(stream, { status: 200 }));
  });

  it('adds bot message to messages after stream completes', async () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    act(() => { result.current.setInput('hello'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(result.current.messages.some(m => m.sender === 'bot' && m.text === 'Hello')).toBe(true);
  });

  it('sends POST to chatEndpoint with correct body', async () => {
    const fetchMock = mockStreamingFetch(['data: {"delta":"ok"}\n\n', 'data: [DONE]\n\n']);
    const router = createMockRouter('/about');
    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock, router }))
    );

    act(() => { result.current.setInput('test message'); });
    await act(async () => { await result.current.sendMessage(); });

    expect(fetchMock).toHaveBeenCalledWith(
      '/chat',
      expect.objectContaining({
        method: 'POST',
        headers: expect.objectContaining({ 'Content-Type': 'application/json' }),
        body: expect.any(String),
      })
    );

    const callArgs = (fetchMock as ReturnType<typeof vi.fn>).mock.calls[0];
    const body = JSON.parse(callArgs[1].body as string);
    expect(body.message).toBe('test message');
    expect(body.currentPage).toBe('/about');
    expect(Array.isArray(body.history)).toBe(true);
  });

  it('history is mapped to {role, content} format with last maxHistoryMessages items', async () => {
    const fetchMock = mockStreamingFetch(['data: {"delta":"ok"}\n\n', 'data: [DONE]\n\n']);

    // We need an existing history of messages. Build it by pre-populating via welcomeMessage
    // and then sending messages. But easier: use a custom hook that starts with existing msgs.
    // The simplest approach: send multiple messages and check the history payload.
    // We'll use maxHistoryMessages: 2 and send enough messages to trigger truncation.

    // Start fresh, send message 1
    const fetchMock1 = mockStreamingFetch(['data: {"delta":"reply1"}\n\n', 'data: [DONE]\n\n']);
    const fetchMock2 = mockStreamingFetch(['data: {"delta":"reply2"}\n\n', 'data: [DONE]\n\n']);
    const fetchMock3 = mockStreamingFetch(['data: {"delta":"reply3"}\n\n', 'data: [DONE]\n\n']);

    let callCount = 0;
    const multiMock = vi.fn(async (...args: Parameters<typeof fetch>) => {
      callCount++;
      if (callCount === 1) return fetchMock1(...args);
      if (callCount === 2) return fetchMock2(...args);
      return fetchMock3(...args);
    }) as typeof globalThis.fetch;

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: multiMock, maxHistoryMessages: 2, welcomeMessage: undefined }))
    );

    // Send first message
    act(() => { result.current.setInput('msg1'); });
    await act(async () => { await result.current.sendMessage(); });

    // Send second message
    act(() => { result.current.setInput('msg2'); });
    await act(async () => { await result.current.sendMessage(); });

    // Send third message — check the history in the third call
    act(() => { result.current.setInput('msg3'); });
    await act(async () => { await result.current.sendMessage(); });

    const thirdCallBody = JSON.parse(
      (multiMock as ReturnType<typeof vi.fn>).mock.calls[2][1].body as string
    );
    // maxHistoryMessages: 2 means only last 2 history entries
    expect(thirdCallBody.history.length).toBeLessThanOrEqual(2);
    // All history entries should have role/content format
    for (const entry of thirdCallBody.history) {
      expect(entry).toHaveProperty('role');
      expect(entry).toHaveProperty('content');
      expect(['user', 'assistant']).toContain(entry.role);
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Streaming
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — streaming', () => {
  it('currentStreamedText updates with delta content during streaming', async () => {
    // Use a fetch that yields chunks with a delay so we can observe intermediate state
    let controllerRef: ReadableStreamDefaultController<Uint8Array> | null = null;
    const encoder = new TextEncoder();

    const slowFetch = vi.fn(async () => {
      const stream = new ReadableStream<Uint8Array>({
        start(c) { controllerRef = c; },
      });
      return new Response(stream, { status: 200 });
    }) as typeof globalThis.fetch;

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: slowFetch }))
    );

    act(() => { result.current.setInput('hi'); });

    // Start sendMessage without awaiting
    let sendDone = false;
    act(() => {
      result.current.sendMessage().then(() => { sendDone = true; });
    });

    // Feed first chunk
    await act(async () => {
      controllerRef!.enqueue(encoder.encode('data: {"delta":"Partial"}\n\n'));
    });

    // currentStreamedText should have something
    await waitFor(() => {
      expect(result.current.currentStreamedText).toContain('Partial');
    });

    // Close stream
    await act(async () => {
      controllerRef!.enqueue(encoder.encode('data: [DONE]\n\n'));
      controllerRef!.close();
    });

    await waitFor(() => sendDone);
  });

  it('clears currentStreamedText after stream ends', async () => {
    const { result } = renderHook(() => useShipPilotChat(baseOptions()));
    act(() => { result.current.setInput('hi'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(result.current.currentStreamedText).toBe('');
  });

  it('final bot message equals accumulated delta text', async () => {
    const fetchMock = mockStreamingFetch([
      'data: {"delta":"foo"}\n\n',
      'data: {"delta":" bar"}\n\n',
      'data: [DONE]\n\n',
    ]);
    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock }))
    );
    act(() => { result.current.setInput('hi'); });
    await act(async () => { await result.current.sendMessage(); });

    const botMsg = result.current.messages.find(m => m.sender === 'bot' && m.text === 'foo bar');
    expect(botMsg).toBeDefined();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Agent action
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — agent action', () => {
  it('sets pendingAgentAction when response ends with [[AGENT:...]] tag', async () => {
    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Done ' + tagText;
    const chunks = [
      `data: ${JSON.stringify({ delta: fullResponse })}\n\n`,
      'data: [DONE]\n\n',
    ];
    const fetchMock = mockStreamingFetch(chunks);

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock }))
    );
    act(() => { result.current.setInput('navigate me'); });
    await act(async () => { await result.current.sendMessage(); });

    expect(result.current.pendingAgentAction).toEqual({ nav: '/about' });
  });

  it('bot message text excludes the agent tag', async () => {
    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Done ' + tagText;
    const chunks = [
      `data: ${JSON.stringify({ delta: fullResponse })}\n\n`,
      'data: [DONE]\n\n',
    ];
    const fetchMock = mockStreamingFetch(chunks);

    // No welcome message so first bot message is from the stream
    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock, welcomeMessage: undefined }))
    );
    act(() => { result.current.setInput('navigate me'); });
    await act(async () => { await result.current.sendMessage(); });

    const botMsg = result.current.messages.find(m => m.sender === 'bot');
    expect(botMsg).toBeDefined();
    expect(botMsg!.text).toBe('Done');
    expect(botMsg!.text).not.toContain('[[AGENT:');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// confirmNavigation
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — confirmNavigation', () => {
  async function setupWithPendingAction() {
    const executeNavigation = vi.fn(async () => ({ completed: true, failedSteps: [] }));
    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Result ' + tagText;
    const chunks = [
      `data: ${JSON.stringify({ delta: fullResponse })}\n\n`,
      'data: [DONE]\n\n',
    ];
    const fetchMock = mockStreamingFetch(chunks);
    const router = createMockRouter('/');

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock, executeNavigation, router }))
    );

    act(() => { result.current.setInput('show me about'); });
    await act(async () => { await result.current.sendMessage(); });

    // Confirm pendingAgentAction is set
    expect(result.current.pendingAgentAction).toEqual({ nav: '/about' });

    return { result, executeNavigation };
  }

  it('clears pendingAgentAction after confirm', async () => {
    const { result } = await setupWithPendingAction();
    await act(async () => { await result.current.confirmNavigation(); });
    expect(result.current.pendingAgentAction).toBeNull();
  });

  it('adds "Yes, show me!" user message on confirm', async () => {
    const { result } = await setupWithPendingAction();
    await act(async () => { await result.current.confirmNavigation(); });
    expect(result.current.messages.some(m => m.sender === 'user' && m.text === 'Yes, show me!')).toBe(true);
  });

  it('calls executeNavigation with steps from computeNavigationSteps', async () => {
    const { result, executeNavigation } = await setupWithPendingAction();
    await act(async () => { await result.current.confirmNavigation(); });
    expect(executeNavigation).toHaveBeenCalledTimes(1);
    // First arg should be an array of NavigationStep objects
    const [steps] = (executeNavigation as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(Array.isArray(steps)).toBe(true);
    expect(steps.length).toBeGreaterThan(0);
  });

  it('sets isAgentMode true during navigation and false after', async () => {
    // Use a slow executeNavigation so we can observe intermediate isAgentMode state
    let resolveNav!: (result: { completed: boolean; failedSteps: unknown[] }) => void;
    const navPromise = new Promise<{ completed: boolean; failedSteps: unknown[] }>((res) => { resolveNav = res; });
    const executeNavigation = vi.fn(() => navPromise);

    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Result ' + tagText;
    const chunks = [
      `data: ${JSON.stringify({ delta: fullResponse })}\n\n`,
      'data: [DONE]\n\n',
    ];
    const fetchMock = mockStreamingFetch(chunks);
    const router = createMockRouter('/');

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock, executeNavigation, router }))
    );

    act(() => { result.current.setInput('go to about'); });
    await act(async () => { await result.current.sendMessage(); });

    // Start confirmNavigation — it will pause at executeNavigation
    let confirmDone = false;
    act(() => {
      result.current.confirmNavigation().then(() => { confirmDone = true; });
    });

    // isAgentMode should be true while executeNavigation is pending
    await waitFor(() => {
      expect(result.current.isAgentMode).toBe(true);
    });

    // Resolve navigation
    await act(async () => { resolveNav({ completed: true, failedSteps: [] }); });

    // isAgentMode should be false after
    await waitFor(() => {
      expect(result.current.isAgentMode).toBe(false);
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// declineNavigation
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — declineNavigation', () => {
  async function setupWithPendingAction() {
    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Result ' + tagText;
    const chunks = [
      `data: ${JSON.stringify({ delta: fullResponse })}\n\n`,
      'data: [DONE]\n\n',
    ];
    const fetchMock = mockStreamingFetch(chunks);

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock }))
    );

    act(() => { result.current.setInput('navigate'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(result.current.pendingAgentAction).not.toBeNull();

    return { result };
  }

  it('clears pendingAgentAction on decline', async () => {
    const { result } = await setupWithPendingAction();
    act(() => { result.current.declineNavigation(); });
    expect(result.current.pendingAgentAction).toBeNull();
  });

  it('adds "No thanks." user message on decline', async () => {
    const { result } = await setupWithPendingAction();
    act(() => { result.current.declineNavigation(); });
    expect(result.current.messages.some(m => m.sender === 'user' && m.text === 'No thanks.')).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Errors
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — error handling', () => {
  it('appends error bot message when fetch throws', async () => {
    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: failingFetch() }))
    );
    act(() => { result.current.setInput('hello'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(
      result.current.messages.some(m => m.sender === 'bot' && m.text.toLowerCase().includes('oops'))
    ).toBe(true);
  });

  it('resets isLoading to false after error', async () => {
    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: failingFetch() }))
    );
    act(() => { result.current.setInput('hello'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(result.current.isLoading).toBe(false);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Navigation failure surfacing (D4e)
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — navigation failure surfacing', () => {
  async function setupWithPendingActionUsing(executeNavigation: ReturnType<typeof vi.fn>) {
    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Result ' + tagText;
    const chunks = [
      `data: ${JSON.stringify({ delta: fullResponse })}\n\n`,
      'data: [DONE]\n\n',
    ];
    const fetchMock = mockStreamingFetch(chunks);
    const router = createMockRouter('/');

    const { result } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock, executeNavigation, router }))
    );

    act(() => { result.current.setInput('show me about'); });
    await act(async () => { await result.current.sendMessage(); });
    expect(result.current.pendingAgentAction).toEqual({ nav: '/about' });

    return { result };
  }

  it('appends a failure message when executeNavigation reports incomplete steps', async () => {
    const executeNavigation = vi.fn(async () => ({
      completed: false,
      failedSteps: [{ step: { action: 'directNav', route: '/about' }, reason: 'Timed out' }],
    }));

    const { result } = await setupWithPendingActionUsing(executeNavigation);
    await act(async () => { await result.current.confirmNavigation(); });

    expect(
      result.current.messages.some(
        (m) => m.sender === 'bot' && m.text.includes("couldn't complete the navigation")
      )
    ).toBe(true);
  });

  it('appends a failure message when executeNavigation throws', async () => {
    const executeNavigation = vi.fn(async () => { throw new Error('boom'); });

    const { result } = await setupWithPendingActionUsing(executeNavigation);
    await act(async () => { await result.current.confirmNavigation(); });

    expect(
      result.current.messages.some(
        (m) => m.sender === 'bot' && m.text.includes("couldn't complete the navigation")
      )
    ).toBe(true);
    // isAgentMode must still be reset even though executeNavigation threw
    expect(result.current.isAgentMode).toBe(false);
  });

  it('does not append a failure message on a completed navigation', async () => {
    const executeNavigation = vi.fn(async () => ({ completed: true, failedSteps: [] }));

    const { result } = await setupWithPendingActionUsing(executeNavigation);
    await act(async () => { await result.current.confirmNavigation(); });

    expect(
      result.current.messages.some((m) => m.text.includes("couldn't complete the navigation"))
    ).toBe(false);
  });

  it('shows a failure message when the agent targets an unreachable dynamic route', async () => {
    const dynamicGraph: SiteGraph = {
      ...testGraph,
      nodes: {
        ...testGraph.nodes,
        '/blog/:slug': {
          path: '/blog/:slug',
          type: 'dynamic',
          navbar: null,
          parent: null,
          card: null,
          detail: null,
          targets: [],
          contentSummary: '',
          contentChunks: [],
        },
      },
    };

    const tagText = '[[AGENT:{"nav":"/blog/:slug"}]]';
    const fullResponse = 'Sure ' + tagText;
    const chunks = [`data: ${JSON.stringify({ delta: fullResponse })}\n\n`, 'data: [DONE]\n\n'];
    const fetchMock = mockStreamingFetch(chunks);
    const executeNavigation = vi.fn(async () => ({ completed: true, failedSteps: [] }));

    const { result } = renderHook(() =>
      useShipPilotChat(
        baseOptions({ fetch: fetchMock, executeNavigation, siteGraph: dynamicGraph, router: createMockRouter('/') })
      )
    );

    act(() => { result.current.setInput('go to a blog post'); });
    await act(async () => { await result.current.sendMessage(); });
    await act(async () => { await result.current.confirmNavigation(); });

    expect(executeNavigation).not.toHaveBeenCalled();
    expect(
      result.current.messages.some((m) => m.text.includes("couldn't complete the navigation"))
    ).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Abort on unmount (D4e)
// ─────────────────────────────────────────────────────────────────────────────

describe('useShipPilotChat — abort on unmount', () => {
  it('aborts the in-flight navigation sequence when the component unmounts', async () => {
    let capturedSignal: AbortSignal | undefined;
    const executeNavigation = vi.fn((_steps: unknown, _adapter: unknown, options?: { signal?: AbortSignal }) => {
      capturedSignal = options?.signal;
      return new Promise(() => {}); // never resolves
    });

    const tagText = '[[AGENT:{"nav":"/about"}]]';
    const fullResponse = 'Result ' + tagText;
    const chunks = [`data: ${JSON.stringify({ delta: fullResponse })}\n\n`, 'data: [DONE]\n\n'];
    const fetchMock = mockStreamingFetch(chunks);

    const { result, unmount } = renderHook(() =>
      useShipPilotChat(baseOptions({ fetch: fetchMock, executeNavigation, router: createMockRouter('/') }))
    );

    act(() => { result.current.setInput('go to about'); });
    await act(async () => { await result.current.sendMessage(); });
    act(() => { void result.current.confirmNavigation(); });

    await waitFor(() => { expect(capturedSignal).toBeDefined(); });
    expect(capturedSignal!.aborted).toBe(false);

    unmount();

    expect(capturedSignal!.aborted).toBe(true);
  });
});
