import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    name: 'react',
    environment: 'jsdom',
    globals: true,
    include: ['test/**/*.test.tsx', 'test/**/*.test.ts'],
    setupFiles: ['./test/setup.ts'],
    passWithNoTests: true,
  },
});
