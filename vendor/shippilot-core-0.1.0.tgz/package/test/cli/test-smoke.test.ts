import { describe, it, expect } from 'vitest';
import { generateSmokeQuestions } from '../../src/cli/question-generator.js';
import { runSmoke } from '../../src/cli/commands/test-smoke.js';
import type { SiteGraph, ShipPilotBuildConfig } from '../../src/types.js';

// ─────────────────────────────────────────────────────────────────────────────
// Fixtures
// ─────────────────────────────────────────────────────────────────────────────

const GRAPH: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  pageCount: 3,
  generatedAt: '',
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Portfolio home page',
      contentChunks: [],
    },
    '/about': {
      path: '/about',
      type: 'top-level',
      navbar: 'nav-about',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'About Alessandro, a software engineer',
      contentChunks: [],
    },
    '/projects': {
      path: '/projects',
      type: 'top-level',
      navbar: 'nav-projects',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Projects and side work',
      contentChunks: [],
    },
  },
  edges: [],
};

const BASE_CONFIG: ShipPilotBuildConfig = {
  framework: 'react-router',
  entryPoint: './src/App.tsx',
  outputDir: './shippilot',
  model: {
    endpoint: 'http://localhost/v1/chat/completions',
    modelName: 'test',
    apiKeyEnv: 'TEST_KEY',
  },
  rag: { enabled: false, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 },
  site: { context: '', scope: 'public' },
  chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
  theme: { mode: 'dark', accentColor: '#22c55e', position: 'bottom-right' },
} as ShipPilotBuildConfig;

// ─────────────────────────────────────────────────────────────────────────────
// SSE helpers
// ─────────────────────────────────────────────────────────────────────────────

function makeOpenAISSE(text: string): string[] {
  return [
    `data: ${JSON.stringify({ choices: [{ delta: { content: text }, finish_reason: null }] })}\n\n`,
    'data: [DONE]\n\n',
  ];
}

function mockFetch(text: string): typeof globalThis.fetch {
  return async () => {
    const enc = new TextEncoder();
    const stream = new ReadableStream<Uint8Array>({
      start(c) {
        for (const ch of makeOpenAISSE(text)) c.enqueue(enc.encode(ch));
        c.close();
      },
    });
    return new Response(stream, { status: 200 });
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// generateSmokeQuestions tests
// ─────────────────────────────────────────────────────────────────────────────

describe('generateSmokeQuestions', () => {
  it('produces at least one question per node with contentSummary', () => {
    const questions = generateSmokeQuestions(GRAPH);
    // 3 nodes all have summaries, expect at least 3 questions
    expect(questions.length).toBeGreaterThanOrEqual(3);
  });

  it('respects perPage cap of 1 — at most one question per route', () => {
    const questions = generateSmokeQuestions(GRAPH, { perPage: 1 });
    // 3 routes * 1 per route = 3 max
    expect(questions.length).toBeLessThanOrEqual(3);
  });

  it('no duplicate questions for same route when perPage defaults to 1', () => {
    const questions = generateSmokeQuestions(GRAPH);
    const routes = questions.map((q) => q.route);
    const uniqueRoutes = new Set(routes);
    // Each route should appear exactly once with default perPage
    expect(uniqueRoutes.size).toBe(routes.length);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// runSmoke tests
// ─────────────────────────────────────────────────────────────────────────────

describe('runSmoke', () => {
  it('passes on a well-formed response with no agent tag', async () => {
    const result = await runSmoke({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: mockFetch('This is a great portfolio!'),
    });

    expect(result.passed).toBe(3);
    expect(result.failed).toBe(0);
    expect(result.details).toHaveLength(3);
    expect(result.details.every((d) => d.status === 'pass')).toBe(true);
  });

  it('fails on hallucinated nav route not present in graph', async () => {
    const result = await runSmoke({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: mockFetch('Sure! [[AGENT:{"nav":"/nonexistent"}]]'),
    });

    const failDetails = result.details.filter((d) => d.status === 'fail');
    expect(failDetails.length).toBeGreaterThanOrEqual(1);
    expect(failDetails[0]!.reason).toMatch(/hallucinated route/i);
  });

  it('fails on empty response', async () => {
    const result = await runSmoke({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: mockFetch(''),
    });

    const failDetails = result.details.filter((d) => d.status === 'fail');
    expect(failDetails.length).toBeGreaterThanOrEqual(1);
    expect(failDetails[0]!.reason).toMatch(/empty response/i);
  });
});
