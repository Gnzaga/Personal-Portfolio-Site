import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync, existsSync, readFileSync, writeFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { ScannedSite, VectorStore, ChunkMetadata, SearchResult, EmbeddingProvider } from '../../src/types.js';
import { MockEmbedder } from '../rag/mock-embedder.js';
import { runScan } from '../../src/cli/commands/scan.js';

let tmpDir: string;
beforeEach(() => { tmpDir = mkdtempSync(join(tmpdir(), 'sp-scan-')); });
afterEach(() => { rmSync(tmpDir, { recursive: true, force: true }); });

// Minimal ScannedSite with 3 routes
const FAKE_SITE: ScannedSite = {
  framework: 'react-router',
  routes: [
    {
      path: '/',
      componentFile: 'Home.tsx',
      isDynamic: false,
      navigableElements: [],
      content: { title: 'Home', headings: ['Welcome'], textSnippets: ['Hello world'], metaDescription: null, sections: [{ heading: 'Welcome', text: ['Hello world'] }] },
    },
    {
      path: '/about',
      componentFile: 'About.tsx',
      isDynamic: false,
      navigableElements: [],
      content: { title: 'About', headings: ['About Me'], textSnippets: ['I am a developer'], metaDescription: null, sections: [{ heading: 'About Me', text: ['I am a developer'] }] },
    },
    {
      path: '/projects',
      componentFile: 'Projects.tsx',
      isDynamic: false,
      navigableElements: [],
      content: { title: 'Projects', headings: ['My Work'], textSnippets: ['See my projects'], metaDescription: null, sections: [{ heading: 'My Work', text: ['See my projects'] }] },
    },
  ],
};

class MockVectorStore implements VectorStore {
  saved = false;
  entries: unknown[] = [];

  async add(id: string, vec: number[], meta: ChunkMetadata) {
    this.entries.push({ id, vec, meta });
  }

  async query(): Promise<SearchResult[]> {
    return [];
  }

  async save(path: string) {
    this.saved = true;
    await writeFile(path, '{}');
  }

  async load(): Promise<void> {}
}

// Config with RAG disabled (auto, below threshold)
function makeConfig(overrides?: Record<string, unknown>) {
  return {
    framework: 'react-router' as const,
    entryPoint: './src/App.tsx',
    outputDir: tmpDir,
    model: { endpoint: 'http://localhost', modelName: 'test', apiKeyEnv: 'TEST_KEY' },
    rag: { enabled: 'auto' as const, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 },
    site: { context: '', scope: 'public' },
    chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
    theme: { mode: 'dark' as const, accentColor: '#22c55e', position: 'bottom-right' as const },
    ...overrides,
  };
}

describe('runScan', () => {
  it('writes site-graph.json to outputDir', async () => {
    const config = makeConfig();
    await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
    });

    const graphPath = join(tmpDir, 'site-graph.json');
    expect(existsSync(graphPath)).toBe(true);

    const raw = readFileSync(graphPath, 'utf-8');
    const graph = JSON.parse(raw);
    expect(graph).toHaveProperty('nodes');
    expect(Object.keys(graph.nodes)).toContain('/');
    expect(Object.keys(graph.nodes)).toContain('/about');
    expect(Object.keys(graph.nodes)).toContain('/projects');
  });

  it('RAG disabled when pageCount < threshold and enabled=auto', async () => {
    // 3 routes, threshold=20 → below threshold → RAG off
    const config = makeConfig(); // threshold=20 by default
    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
    });

    expect(result.ragEnabled).toBe(false);
    expect(result.chunkCount).toBeNull();
    expect(existsSync(join(tmpDir, 'site-index.json'))).toBe(false);
  });

  it('RAG enabled when pageCount >= threshold and enabled=auto', async () => {
    // threshold=2, 3 routes → 3 > 2 → RAG on
    const config = makeConfig({ rag: { enabled: 'auto', threshold: 2, topK: 5, chunkSize: 512, chunkOverlap: 50 } });
    const embedder = new MockEmbedder(8);
    const store = new MockVectorStore();

    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
      embedder,
      store,
    });

    expect(result.ragEnabled).toBe(true);
    expect(result.chunkCount).toBeGreaterThan(0);
    expect(store.saved).toBe(true);
  });

  it('RAG respects explicit enabled=true regardless of threshold', async () => {
    // 3 routes, threshold=20 (routes below threshold), but enabled=true forces RAG
    const config = makeConfig({ rag: { enabled: true, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 } });
    const embedder = new MockEmbedder(8);
    const store = new MockVectorStore();

    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
      embedder,
      store,
    });

    expect(result.ragEnabled).toBe(true);
    expect(result.chunkCount).toBeGreaterThan(0);
    expect(store.saved).toBe(true);
  });

  it('RAG respects explicit enabled=false regardless of threshold', async () => {
    // threshold=1 (all routes exceed it), but enabled=false → no RAG
    const config = makeConfig({ rag: { enabled: false, threshold: 1, topK: 5, chunkSize: 512, chunkOverlap: 50 } });
    const store = new MockVectorStore();

    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
      store,
    });

    expect(result.ragEnabled).toBe(false);
    expect(result.chunkCount).toBeNull();
    expect(store.saved).toBe(false);
  });

  it('returns accurate pageCount and edgeCount', async () => {
    const config = makeConfig();
    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
    });

    expect(result.pageCount).toBe(3);
    expect(result.edgeCount).toBeGreaterThanOrEqual(0);
  });

  it('returns orphanRoutes for nodes with no incoming edges', async () => {
    const config = makeConfig();
    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
    });

    // '/' is the root; /about and /projects have no nav links pointing to them in FAKE_SITE
    // (no navigableElements on any route), so they should appear as orphans
    expect(result.orphanRoutes).toContain('/about');
    expect(result.orphanRoutes).toContain('/projects');
  });

  it('refuses to write output and throws when the scan finds 0 pages (finding 9)', async () => {
    const config = makeConfig();
    const EMPTY_SITE: ScannedSite = { framework: 'react-router', routes: [] };

    await expect(
      runScan({
        config,
        projectRoot: tmpDir,
        scan: async () => EMPTY_SITE,
      }),
    ).rejects.toThrow(/0 pages/);

    expect(existsSync(join(tmpDir, 'site-graph.json'))).toBe(false);
  });

  it('returns targetWarnings for synthesized navbar IDs never scanned in JSX', async () => {
    const config = makeConfig();
    const result = await runScan({
      config,
      projectRoot: tmpDir,
      scan: async () => FAKE_SITE,
    });

    // FAKE_SITE has no navigableElements at all, so every synthesized navbar
    // ID is reported as a warning.
    expect(result.targetWarnings.length).toBeGreaterThan(0);
    expect(result.targetWarnings.some((w) => w.expectedId === 'nav-about')).toBe(true);
  });

  it('writes sourceHashes for component files that exist on disk', async () => {
    const componentFile = 'Home.tsx';
    writeFileSync(join(tmpDir, componentFile), 'export default function Home() { return null; }');

    const config = makeConfig();
    await runScan({ config, projectRoot: tmpDir, scan: async () => FAKE_SITE });

    const graph = JSON.parse(readFileSync(join(tmpDir, 'site-graph.json'), 'utf-8'));
    expect(graph.sourceHashes).toHaveProperty('Home.tsx');
    expect(typeof graph.sourceHashes['Home.tsx']).toBe('string');
    expect(graph.sourceHashes['Home.tsx'].length).toBe(64);
  });

  it('skips component files that do not exist on disk without throwing', async () => {
    const config = makeConfig();
    const result = await runScan({ config, projectRoot: tmpDir, scan: async () => FAKE_SITE });

    // None of FAKE_SITE's componentFiles exist in tmpDir — sourceHashes
    // should simply have no entries for them, not throw.
    expect(result).toBeDefined();
    const graph = JSON.parse(readFileSync(join(tmpDir, 'site-graph.json'), 'utf-8'));
    expect(graph.sourceHashes).toEqual({});
  });
});
