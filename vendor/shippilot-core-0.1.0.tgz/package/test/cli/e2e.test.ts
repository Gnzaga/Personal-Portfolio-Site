import { mkdtempSync, rmSync, writeFileSync, mkdirSync, existsSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { runScan } from '../../src/cli/commands/scan.js';
import { runDoctor } from '../../src/cli/commands/doctor.js';

let tmpDir: string;
beforeEach(() => {
  tmpDir = mkdtempSync(join(tmpdir(), 'sp-e2e-'));
  process.env['TEST_API_KEY'] = 'sk-test';
});
afterEach(() => {
  rmSync(tmpDir, { recursive: true, force: true });
  delete process.env['TEST_API_KEY'];
});

const CONFIG = {
  framework: 'react-router' as const,
  entryPoint: './src/App.tsx',
  outputDir: tmpDir,
  model: { endpoint: 'http://localhost:9999', modelName: 'test', apiKeyEnv: 'TEST_API_KEY' },
  rag: { enabled: false as const, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 },
  site: { context: 'Test site', scope: 'public' as const },
  chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
  theme: { mode: 'dark' as const, accentColor: '#22c55e', position: 'bottom-right' as const },
};

// Inline scanner result so the test doesn't need actual source files
const FAKE_SCAN_RESULT = {
  framework: 'react-router' as const,
  routes: [
    {
      path: '/',
      componentFile: 'Home.tsx',
      isDynamic: false,
      navigableElements: [],
      content: {
        title: 'Home',
        headings: ['Welcome'],
        textSnippets: ['Portfolio'],
        metaDescription: null,
        sections: [{ heading: 'Welcome', text: ['Portfolio'] }],
      },
    },
    {
      path: '/about',
      componentFile: 'About.tsx',
      isDynamic: false,
      navigableElements: [],
      content: {
        title: 'About',
        headings: ['About Me'],
        textSnippets: ['I am a developer'],
        metaDescription: null,
        sections: [{ heading: 'About Me', text: ['I am a developer'] }],
      },
    },
  ],
};

test('runScan + runDoctor full pipeline', async () => {
  // Use a local outputDir so CONFIG.outputDir resolves correctly after tmpDir is assigned
  const config = { ...CONFIG, outputDir: tmpDir };

  // 1. Run scan with injected fake scanner and disabled RAG
  const scanResult = await runScan({
    config: config as Parameters<typeof runScan>[0]['config'],
    projectRoot: tmpDir,
    scan: async () => FAKE_SCAN_RESULT,
  });

  // 2. Assert scan produced the graph file
  expect(scanResult.pageCount).toBe(2);
  const graphPath = join(tmpDir, 'site-graph.json');
  expect(existsSync(graphPath)).toBe(true);
  const graph = JSON.parse(readFileSync(graphPath, 'utf-8'));
  expect(Object.keys(graph.nodes).length).toBeGreaterThan(0);

  // 3. Create src/App.tsx in tmpDir so doctor's entry-point check passes
  mkdirSync(join(tmpDir, 'src'), { recursive: true });
  writeFileSync(join(tmpDir, 'src', 'App.tsx'), '// placeholder');

  // 4. Build config with absolute entry point for doctor
  const configWithAbsPath = {
    ...config,
    entryPoint: join(tmpDir, 'src', 'App.tsx'),
    outputDir: tmpDir,
  };

  // 5. Run doctor with a mock fetch so endpoint check doesn't fail on network
  const mockFetch: typeof globalThis.fetch = async () =>
    new Response('{"ok":true}', { status: 200 });
  const report = await runDoctor({
    config: configWithAbsPath as Parameters<typeof runDoctor>[0]['config'],
    projectRoot: tmpDir,
    fetch: mockFetch,
  });

  // 6. Overall should pass or at most warn (API key IS set, graph IS there)
  expect(['pass', 'warn']).toContain(report.overall);

  // 7. Site graph check should pass (we wrote the file)
  const graphCheck = report.checks.find((c) => c.name === 'site graph exists');
  expect(graphCheck).toBeDefined();
  expect(graphCheck!.status).toBe('pass');
});
