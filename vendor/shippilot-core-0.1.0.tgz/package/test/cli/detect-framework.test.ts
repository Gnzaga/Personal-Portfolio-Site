import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { detectFramework } from '../../src/cli/detect-framework';

let tmpDir: string;
beforeEach(() => {
  tmpDir = mkdtempSync(join(tmpdir(), 'sp-detect-'));
});
afterEach(() => {
  rmSync(tmpDir, { recursive: true, force: true });
});

function writePkg(dir: string, deps: Record<string, string> = {}) {
  writeFileSync(join(dir, 'package.json'), JSON.stringify({ dependencies: deps }));
}

describe('detectFramework', () => {
  it('detects nextjs-app when next.config.js and app/ directory are present', () => {
    writeFileSync(join(tmpDir, 'next.config.js'), 'module.exports = {}');
    mkdirSync(join(tmpDir, 'app'));
    writeFileSync(join(tmpDir, 'app', 'page.tsx'), 'export default function Page() {}');

    const result = detectFramework(tmpDir);

    expect(result).toEqual({ framework: 'nextjs-app', entryPoint: 'app' });
  });

  it('detects nextjs-pages when next.config.js and pages/ directory are present', () => {
    writeFileSync(join(tmpDir, 'next.config.js'), 'module.exports = {}');
    mkdirSync(join(tmpDir, 'pages'));
    writeFileSync(join(tmpDir, 'pages', 'index.tsx'), 'export default function Index() {}');

    const result = detectFramework(tmpDir);

    expect(result).toEqual({ framework: 'nextjs-pages', entryPoint: 'pages' });
  });

  it('detects react-router when package.json has react-router-dom and src/App.tsx exists', () => {
    writePkg(tmpDir, { 'react-router-dom': '^6.0.0' });
    mkdirSync(join(tmpDir, 'src'));
    writeFileSync(join(tmpDir, 'src', 'App.tsx'), 'export default function App() {}');

    const result = detectFramework(tmpDir);

    expect(result).toEqual({ framework: 'react-router', entryPoint: 'src/App.tsx' });
  });

  it('returns null when no framework markers are present', () => {
    writePkg(tmpDir, { 'lodash': '^4.0.0' });

    const result = detectFramework(tmpDir);

    expect(result).toBeNull();
  });

  it('prefers src/App.tsx over src/main.tsx for react-router', () => {
    writePkg(tmpDir, { 'react-router-dom': '^6.0.0' });
    mkdirSync(join(tmpDir, 'src'));
    writeFileSync(join(tmpDir, 'src', 'App.tsx'), 'export default function App() {}');
    writeFileSync(join(tmpDir, 'src', 'main.tsx'), 'import App from "./App"');

    const result = detectFramework(tmpDir);

    expect(result?.entryPoint).toBe('src/App.tsx');
  });

  it('detects nextjs-app when next.config.ts (not .js) and app/ directory are present', () => {
    writeFileSync(join(tmpDir, 'next.config.ts'), 'export default {}');
    mkdirSync(join(tmpDir, 'app'));

    const result = detectFramework(tmpDir);

    expect(result).toEqual({ framework: 'nextjs-app', entryPoint: 'app' });
  });
});
