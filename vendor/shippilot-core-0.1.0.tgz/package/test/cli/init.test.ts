import { mkdtempSync, rmSync, existsSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import {
  buildInitConfig,
  writeInitConfig,
  runInit,
  type InitAnswers,
  type InitPrompts,
} from '../../src/cli/commands/init.js';
import { validateConfig } from '../../src/cli/config.js';

let tmpDir: string;
beforeEach(() => {
  tmpDir = mkdtempSync(join(tmpdir(), 'sp-init-'));
});
afterEach(() => {
  rmSync(tmpDir, { recursive: true, force: true });
});

const GOOD_ANSWERS: InitAnswers = {
  framework: 'react-router',
  entryPoint: './src/App.tsx',
  modelEndpoint: 'https://api.openai.com/v1/chat/completions',
  modelName: 'gpt-4o-mini',
  apiKeyEnv: 'SHIPPILOT_API_KEY',
  siteContext: 'A portfolio site.',
  outputDir: './shippilot',
};

describe('buildInitConfig', () => {
  it('produces a config that passes validateConfig', () => {
    const config = buildInitConfig(GOOD_ANSWERS);
    const result = validateConfig(config);
    expect(result.valid).toBe(true);
  });
});

describe('writeInitConfig', () => {
  it('writes to the correct path', async () => {
    const config = buildInitConfig(GOOD_ANSWERS);
    await writeInitConfig(tmpDir, config, { confirm: async () => true });
    const expectedPath = join(tmpDir, 'shippilot.config.json');
    expect(existsSync(expectedPath)).toBe(true);
    const written = JSON.parse(readFileSync(expectedPath, 'utf-8'));
    expect(written.framework).toBe('react-router');
  });

  it('refuses to overwrite when user declines', async () => {
    const config = buildInitConfig(GOOD_ANSWERS);
    await writeInitConfig(tmpDir, config, { confirm: async () => true });

    const config2 = buildInitConfig({ ...GOOD_ANSWERS, modelName: 'gpt-4o' });
    await writeInitConfig(tmpDir, config2, { confirm: async () => false });

    const written = JSON.parse(readFileSync(join(tmpDir, 'shippilot.config.json'), 'utf-8'));
    expect(written.model.modelName).toBe('gpt-4o-mini'); // unchanged
  });

  it('overwrites when user confirms', async () => {
    const config = buildInitConfig(GOOD_ANSWERS);
    await writeInitConfig(tmpDir, config, { confirm: async () => true });

    const config2 = buildInitConfig({ ...GOOD_ANSWERS, modelName: 'gpt-4o' });
    await writeInitConfig(tmpDir, config2, { confirm: async () => true });

    const written = JSON.parse(readFileSync(join(tmpDir, 'shippilot.config.json'), 'utf-8'));
    expect(written.model.modelName).toBe('gpt-4o');
  });
});

describe('runInit', () => {
  it('with canned prompts produces a valid config file', async () => {
    const cannedPrompts: InitPrompts = {
      ask: async (label, def) => {
        if (label.toLowerCase().includes('endpoint')) return GOOD_ANSWERS.modelEndpoint;
        if (label.toLowerCase().includes('model name')) return GOOD_ANSWERS.modelName;
        if (label.toLowerCase().includes('api key')) return GOOD_ANSWERS.apiKeyEnv;
        if (label.toLowerCase().includes('context')) return GOOD_ANSWERS.siteContext;
        if (label.toLowerCase().includes('output')) return GOOD_ANSWERS.outputDir;
        return def ?? '';
      },
      confirm: async () => true,
    };

    await runInit({
      projectRoot: tmpDir,
      prompts: cannedPrompts,
      framework: 'react-router',
      entryPoint: './src/App.tsx',
    });

    expect(existsSync(join(tmpDir, 'shippilot.config.json'))).toBe(true);
  });
});
