import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { loadConfig, validateConfig, mergeWithDefaults } from '../../src/cli/config.js';

const MINIMAL_CONFIG = {
  framework: 'react-router' as const,
  entryPoint: './src/App.tsx',
  outputDir: './shippilot',
  model: {
    endpoint: 'https://api.openai.com/v1/chat/completions',
    modelName: 'gpt-4o-mini',
    apiKeyEnv: 'SHIPPILOT_API_KEY',
  },
};

let tmpDir: string;
beforeEach(() => {
  tmpDir = mkdtempSync(join(tmpdir(), 'shippilot-test-'));
});
afterEach(() => {
  rmSync(tmpDir, { recursive: true, force: true });
});

// ─────────────────────────────────────────────────────────────────────────────
// loadConfig
// ─────────────────────────────────────────────────────────────────────────────

describe('loadConfig', () => {
  it('loads a valid config file from disk and returns parsed + defaulted config', () => {
    writeFileSync(join(tmpDir, 'shippilot.config.json'), JSON.stringify(MINIMAL_CONFIG));

    const config = loadConfig(tmpDir);

    expect(config.framework).toBe('react-router');
    expect(config.entryPoint).toBe('./src/App.tsx');
    expect(config.outputDir).toBe('./shippilot');
    expect(config.model.endpoint).toBe('https://api.openai.com/v1/chat/completions');
    // defaults should be filled in
    expect(config.rag).toBeDefined();
    expect(config.rag!.topK).toBe(5);
  });

  it('throws when shippilot.config.json is missing, error mentions the path', () => {
    expect(() => loadConfig(tmpDir)).toThrow(join(tmpDir, 'shippilot.config.json'));
  });

  it('throws on malformed JSON, error mentions parse or JSON', () => {
    writeFileSync(join(tmpDir, 'shippilot.config.json'), '{ not valid json }');

    expect(() => loadConfig(tmpDir)).toThrow(/parse|JSON/i);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// validateConfig
// ─────────────────────────────────────────────────────────────────────────────

describe('validateConfig', () => {
  it('rejects config missing framework', () => {
    const { framework: _omit, ...withoutFramework } = MINIMAL_CONFIG;
    const result = validateConfig(withoutFramework);

    expect(result.valid).toBe(false);
    if (!result.valid) {
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors.some((e) => /framework/i.test(e))).toBe(true);
    }
  });

  it('rejects config missing model.endpoint', () => {
    const config = {
      ...MINIMAL_CONFIG,
      model: { modelName: 'gpt-4o-mini', apiKeyEnv: 'SHIPPILOT_API_KEY' },
    };
    const result = validateConfig(config);

    expect(result.valid).toBe(false);
    if (!result.valid) {
      expect(result.errors.some((e) => /endpoint/i.test(e))).toBe(true);
    }
  });

  it('accepts a minimal valid config with all required fields', () => {
    const result = validateConfig(MINIMAL_CONFIG);

    expect(result.valid).toBe(true);
    if (result.valid) {
      expect(result.config.framework).toBe('react-router');
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// mergeWithDefaults
// ─────────────────────────────────────────────────────────────────────────────

describe('mergeWithDefaults', () => {
  it('fills in missing rag section with default values', () => {
    const config = mergeWithDefaults(MINIMAL_CONFIG);

    expect(config.rag).toEqual({
      enabled: 'auto',
      threshold: 20,
      topK: 5,
      chunkSize: 512,
      chunkOverlap: 50,
    });
  });

  it('user-provided rag.threshold overrides the default', () => {
    const config = mergeWithDefaults({
      ...MINIMAL_CONFIG,
      rag: { enabled: 'auto', threshold: 50, topK: 5, chunkSize: 512, chunkOverlap: 50 },
    });

    expect(config.rag!.threshold).toBe(50);
    // other defaults remain intact
    expect(config.rag!.topK).toBe(5);
    expect(config.rag!.chunkSize).toBe(512);
  });
});
