import { mkdtempSync, rmSync, writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { runDoctor } from '../../src/cli/commands/doctor.js';
import type { ShipPilotBuildConfig } from '../../src/types.js';

let tmpDir: string;
let entryFile: string;

beforeEach(() => {
  tmpDir = mkdtempSync(join(tmpdir(), 'sp-doctor-'));
  entryFile = join(tmpDir, 'src', 'App.tsx');
  mkdirSync(join(tmpDir, 'src'), { recursive: true });
  writeFileSync(entryFile, '// placeholder');
  process.env.TEST_KEY = 'sk-test';
});

afterEach(() => {
  rmSync(tmpDir, { recursive: true, force: true });
  delete process.env.TEST_KEY;
});

// Minimal valid config
function makeConfig(overrides?: Partial<{ rag: { enabled: boolean } }>): ShipPilotBuildConfig {
  return {
    framework: 'react-router',
    entryPoint: join(tmpDir, 'src', 'App.tsx'),
    outputDir: tmpDir,
    model: { endpoint: 'http://localhost:9999', modelName: 'test', apiKeyEnv: 'TEST_KEY' },
    rag: { enabled: 'auto', threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50, ...overrides?.rag },
    site: { context: '', scope: 'public' },
    chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
    theme: { mode: 'dark', accentColor: '#22c55e', position: 'bottom-right' },
  } as ShipPilotBuildConfig;
}

// A minimal valid site-graph.json
const GOOD_GRAPH = {
  scope: 'public',
  framework: 'react-router',
  pageCount: 3,
  generatedAt: new Date().toISOString(),
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      contentSummary: 'Home',
      contentChunks: [],
    },
    '/about': {
      path: '/about',
      type: 'top-level',
      navbar: 'nav-about',
      parent: null,
      card: null,
      detail: null,
      contentSummary: 'About',
      contentChunks: [],
    },
  },
  edges: [
    { from: '/', to: '/about', element: 'nav-about', action: 'navClick' },
  ],
};

// Mock fetch helpers
const mockFetch200 = async () => new Response(JSON.stringify({ ok: true }), { status: 200 });
const mockFetch500 = async () => new Response('error', { status: 500 });
const mockFetchThrows = async (): Promise<Response> => { throw new Error('network error'); };

// Helper to find a check by name
const check = (report: Awaited<ReturnType<typeof runDoctor>>, name: string) =>
  report.checks.find((c) => c.name === name)!;

// ─────────────────────────────────────────────────────────────────────────────

describe('runDoctor', () => {
  it('passes overall when all checks succeed', async () => {
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));

    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetch200,
    });

    expect(report.overall).toBe('pass');
    for (const c of report.checks) {
      expect(c.status).toBe('pass');
    }
  });

  it('fails when entry point does not exist', async () => {
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));

    const config = makeConfig();
    config.entryPoint = join(tmpDir, 'src', 'NonExistent.tsx');

    const report = await runDoctor({
      config,
      projectRoot: tmpDir,
      fetch: mockFetch200,
    });

    expect(check(report, 'entry point exists').status).toBe('fail');
    expect(report.overall).toBe('fail');
  });

  it('fails when api key env var is not set', async () => {
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));
    delete process.env.TEST_KEY;

    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetch200,
    });

    expect(check(report, 'api key set').status).toBe('fail');
    expect(report.overall).toBe('fail');
  });

  it('fails when site-graph.json is missing', async () => {
    // Don't write site-graph.json
    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetch200,
    });

    expect(check(report, 'site graph exists').status).toBe('fail');
    expect(report.overall).toBe('fail');
  });

  it('warns when graph has no edges (possible orphan nodes)', async () => {
    const orphanGraph = {
      ...GOOD_GRAPH,
      edges: [],
    };
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(orphanGraph));

    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetch200,
    });

    expect(check(report, 'site graph structure').status).toBe('warn');
  });

  it('fails when endpoint returns non-200', async () => {
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));

    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetch500,
    });

    expect(check(report, 'model endpoint reachable').status).toBe('fail');
    expect(report.overall).toBe('fail');
  });

  it('fails when endpoint throws (network error)', async () => {
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));

    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetchThrows,
    });

    expect(check(report, 'model endpoint reachable').status).toBe('fail');
    expect(report.overall).toBe('fail');
  });

  it('overall is fail when any single check fails', async () => {
    writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));
    // Cause api key check to fail
    delete process.env.TEST_KEY;

    const report = await runDoctor({
      config: makeConfig(),
      projectRoot: tmpDir,
      fetch: mockFetch200,
    });

    const anyFail = report.checks.some((c) => c.status === 'fail');
    expect(anyFail).toBe(true);
    expect(report.overall).toBe('fail');
  });

  describe('site graph freshness', () => {
    it('warns when a recorded source file has changed since the graph was written', async () => {
      const componentFile = 'src/pages/About.tsx';
      const absPath = join(tmpDir, componentFile);
      mkdirSync(join(tmpDir, 'src', 'pages'), { recursive: true });
      const originalSource = 'export default function About() { return null; }';
      writeFileSync(absPath, originalSource);
      const originalHash = createHash('sha256').update(originalSource).digest('hex');

      const graphWithHashes = { ...GOOD_GRAPH, sourceHashes: { [componentFile]: originalHash } };
      writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(graphWithHashes));

      // Change the source file after the graph was recorded
      writeFileSync(absPath, 'export default function About() { return "changed"; }');

      const report = await runDoctor({ config: makeConfig(), projectRoot: tmpDir, fetch: mockFetch200 });

      expect(check(report, 'site graph freshness').status).toBe('warn');
      expect(check(report, 'site graph freshness').message).toMatch(/stale/i);
    });

    it('passes when recorded hashes match current source file contents', async () => {
      const componentFile = 'src/pages/About.tsx';
      const absPath = join(tmpDir, componentFile);
      mkdirSync(join(tmpDir, 'src', 'pages'), { recursive: true });
      const source = 'export default function About() { return null; }';
      writeFileSync(absPath, source);
      const hash = createHash('sha256').update(source).digest('hex');

      const graphWithHashes = { ...GOOD_GRAPH, sourceHashes: { [componentFile]: hash } };
      writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(graphWithHashes));

      const report = await runDoctor({ config: makeConfig(), projectRoot: tmpDir, fetch: mockFetch200 });

      expect(check(report, 'site graph freshness').status).toBe('pass');
    });

    it('passes with a note when the graph has no recorded source hashes', async () => {
      writeFileSync(join(tmpDir, 'site-graph.json'), JSON.stringify(GOOD_GRAPH));

      const report = await runDoctor({ config: makeConfig(), projectRoot: tmpDir, fetch: mockFetch200 });

      expect(check(report, 'site graph freshness').status).toBe('pass');
    });
  });
});
