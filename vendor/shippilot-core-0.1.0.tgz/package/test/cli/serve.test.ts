import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import type { Server } from 'node:http';
import { mkdir, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import type { SiteGraph, ShipPilotBuildConfig } from '../../src/types.js';
import { buildServeApp, runServe, getListeningAddress } from '../../src/cli/commands/serve.js';
import { MockEmbedder } from '../rag/mock-embedder.js';

const GRAPH: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  pageCount: 1,
  generatedAt: '',
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Home',
      contentChunks: [],
    },
  },
  edges: [],
};

const CONFIG: ShipPilotBuildConfig = {
  framework: 'react-router',
  entryPoint: './src/App.tsx',
  outputDir: './shippilot',
  model: {
    endpoint: 'http://localhost:9999/v1/chat/completions',
    modelName: 'test',
    apiKeyEnv: 'TEST_KEY',
  },
  rag: { enabled: false, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 },
  site: { context: '', scope: 'public' },
  chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
  theme: { mode: 'dark', accentColor: '#22c55e', position: 'bottom-right' },
} as ShipPilotBuildConfig;

const mockFetch: typeof globalThis.fetch = async () => {
  const enc = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    start(c) {
      c.enqueue(enc.encode('data: {"delta":"Hello!"}\n\n'));
      c.enqueue(enc.encode('data: [DONE]\n\n'));
      c.close();
    },
  });
  return new Response(stream, {
    status: 200,
    headers: { 'Content-Type': 'text/event-stream' },
  });
};

describe('buildServeApp', () => {
  let server: Server;
  let baseUrl: string;

  beforeEach(async () => {
    const app = await buildServeApp({
      config: CONFIG,
      siteGraph: GRAPH,
      apiKey: 'sk-test',
      fetch: mockFetch,
    });
    await new Promise<void>((resolve, reject) => {
      server = app.listen(0);
      server.once('listening', resolve);
      server.once('error', reject);
    });
    const { port } = await getListeningAddress(server);
    baseUrl = `http://localhost:${port}`;
  });

  afterEach(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  });

  it('GET /healthz returns 200 { ok: true }', async () => {
    const res = await fetch(`${baseUrl}/healthz`);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
  });

  it('POST /chat with empty body returns 400', async () => {
    const res = await fetch(`${baseUrl}/chat`, {
      method: 'POST',
      body: '{}',
      headers: { 'Content-Type': 'application/json' },
    });
    expect(res.status).toBe(400);
  });

  it('POST /chat with valid message returns 200 stream', async () => {
    const res = await fetch(`${baseUrl}/chat`, {
      method: 'POST',
      body: JSON.stringify({ message: 'hello', currentPage: '/' }),
      headers: { 'Content-Type': 'application/json' },
    });
    expect(res.status).toBe(200);
    expect(res.headers.get('content-type')).toMatch(/text\/event-stream/);
  });

  it('CORS headers present for localhost origin', async () => {
    const res = await fetch(`${baseUrl}/healthz`, {
      headers: { Origin: 'http://localhost:3000' },
    });
    expect(res.headers.get('access-control-allow-origin')).toBeTruthy();
  });

  it('POST /chat with malformed JSON body returns 400', async () => {
    const res = await fetch(`${baseUrl}/chat`, {
      method: 'POST',
      body: 'not json',
      headers: { 'Content-Type': 'application/json' },
    });
    expect(res.status).toBe(400);
  });
});

describe('runServe', () => {
  let tmpDir: string;
  let outputDir: string;
  let serverResult: { url: string; close: () => Promise<void> } | null = null;

  const GRAPH_DATA: SiteGraph = {
    scope: 'public',
    framework: 'react-router',
    pageCount: 1,
    generatedAt: '',
    nodes: {
      '/': {
        path: '/',
        type: 'top-level',
        navbar: 'nav-home',
        parent: null,
        card: null,
        detail: null,
        targets: [],
        contentSummary: 'Home',
        contentChunks: [],
      },
    },
    edges: [],
  };

  const makeConfig = (dir: string): ShipPilotBuildConfig => ({
    framework: 'react-router',
    entryPoint: './src/App.tsx',
    outputDir: 'out',
    model: {
      endpoint: 'http://localhost:9999/v1/chat/completions',
      modelName: 'test',
      apiKeyEnv: 'TEST_KEY',
    },
    rag: { enabled: false, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 },
    site: { context: '', scope: 'public' },
    chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
    theme: { mode: 'dark', accentColor: '#22c55e', position: 'bottom-right' },
  } as ShipPilotBuildConfig);

  beforeEach(async () => {
    tmpDir = join(tmpdir(), `shippilot-test-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    outputDir = join(tmpDir, 'out');
    await mkdir(outputDir, { recursive: true });
    await writeFile(join(outputDir, 'site-graph.json'), JSON.stringify(GRAPH_DATA), 'utf-8');
  });

  afterEach(async () => {
    if (serverResult) {
      await serverResult.close();
      serverResult = null;
    }
    await rm(tmpDir, { recursive: true, force: true });
  });

  it('skips RAG wiring when site-index.json is absent', async () => {
    const embedder = new MockEmbedder(8);
    const config = makeConfig(tmpDir);

    serverResult = await runServe({
      config,
      projectRoot: tmpDir,
      port: 0,
      embedder,
    });

    const res = await fetch(`${serverResult.url}/healthz`);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);

    // embedder should NOT have been called — no index, no RAG
    expect(embedder.embedCalls).toHaveLength(0);
  });

  it('loads vector store when site-index.json exists', async () => {
    // Write a minimal valid LocalVectorStore serialization
    const indexData = {
      dimensions: 8,
      entries: [],
    };
    await writeFile(join(outputDir, 'site-index.json'), JSON.stringify(indexData), 'utf-8');

    const embedder = new MockEmbedder(8);
    const config = makeConfig(tmpDir);

    serverResult = await runServe({
      config,
      projectRoot: tmpDir,
      port: 0,
      embedder,
    });

    const res = await fetch(`${serverResult.url}/healthz`);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
  });

  it('forwards embedder to chat middleware when index exists', async () => {
    const indexData = {
      dimensions: 8,
      entries: [],
    };
    await writeFile(join(outputDir, 'site-index.json'), JSON.stringify(indexData), 'utf-8');

    const embedder = new MockEmbedder(8);
    const config = makeConfig(tmpDir);

    serverResult = await runServe({
      config,
      projectRoot: tmpDir,
      port: 0,
      embedder,
    });

    // Server should start and /healthz should respond — middleware received the embedder
    const res = await fetch(`${serverResult.url}/healthz`);
    expect(res.status).toBe(200);

    // Chat endpoint should respond (even if it fails the AI call — middleware is wired)
    const chatRes = await fetch(`${serverResult.url}/chat`, {
      method: 'POST',
      body: JSON.stringify({ message: 'hello', currentPage: '/' }),
      headers: { 'Content-Type': 'application/json' },
    });
    // 400/500 are acceptable since the AI endpoint won't respond in test,
    // but 404 would mean the route wasn't registered
    expect(chatRes.status).not.toBe(404);
  });
});
