import { describe, it, expect } from 'vitest';
import { createInteractiveSession } from '../../src/cli/commands/interactive.js';
import type { SiteGraph, ShipPilotBuildConfig } from '../../src/types.js';

// ─────────────────────────────────────────────────────────────────────────────
// Fixtures
// ─────────────────────────────────────────────────────────────────────────────

const GRAPH: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  pageCount: 2,
  generatedAt: '',
  nodes: {
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Home',
      contentChunks: [],
    },
    '/about': {
      path: '/about',
      type: 'top-level',
      navbar: 'nav-about',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'About',
      contentChunks: [],
    },
  },
  edges: [],
};

const BASE_CONFIG: ShipPilotBuildConfig = {
  framework: 'react-router',
  entryPoint: './src/App.tsx',
  outputDir: './shippilot',
  model: {
    endpoint: 'http://localhost:9999/v1/chat/completions',
    modelName: 'test',
    apiKeyEnv: 'TEST_KEY',
  },
  rag: { enabled: false, threshold: 20, topK: 5, chunkSize: 512, chunkOverlap: 50 },
  site: { context: '', scope: 'public' },
  chat: { maxHistoryMessages: 10, welcomeMessage: '', agentModeLabel: 'Piloting...' },
  theme: { mode: 'dark', accentColor: '#22c55e', position: 'bottom-right' },
} as ShipPilotBuildConfig;

// ─────────────────────────────────────────────────────────────────────────────
// SSE helpers
// ─────────────────────────────────────────────────────────────────────────────

function sseChunks(text: string): string[] {
  return [
    `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\n`,
    'data: [DONE]\n\n',
  ];
}

function mockFetch(text: string): typeof globalThis.fetch {
  return async () => {
    const enc = new TextEncoder();
    const stream = new ReadableStream<Uint8Array>({
      start(c) {
        for (const ch of sseChunks(text)) c.enqueue(enc.encode(ch));
        c.close();
      },
    });
    return new Response(stream, { status: 200 });
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('createInteractiveSession', () => {
  it('single turn: sends message and returns response text', async () => {
    const session = createInteractiveSession({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: mockFetch('Hello from bot'),
    });

    const result = await session.sendMessage('hi');
    expect(result.response).toBe('Hello from bot');
  });

  it('extracts agent action from response and strips tag from response text', async () => {
    const agentText = 'Sure, navigating now [[AGENT:{"nav":"/about"}]]';
    const session = createInteractiveSession({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: mockFetch(agentText),
    });

    const result = await session.sendMessage('go to about');
    expect(result.agentAction).not.toBeNull();
    expect(result.agentAction!.nav).toBe('/about');
    expect(result.response).not.toContain('[[AGENT:');
  });

  it('accumulates history across multiple turns', async () => {
    const session = createInteractiveSession({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: mockFetch('bot reply'),
    });

    await session.sendMessage('first message');
    await session.sendMessage('second message');

    const history = session.history();
    expect(history).toHaveLength(4);
    expect(history[0]).toEqual({ role: 'user', content: 'first message' });
    expect(history[1]).toEqual({ role: 'assistant', content: 'bot reply' });
    expect(history[2]).toEqual({ role: 'user', content: 'second message' });
    expect(history[3]).toEqual({ role: 'assistant', content: 'bot reply' });
  });

  it('respects currentPage option by including it in the system prompt', async () => {
    let capturedSystemMessage: string | undefined;

    const capturingFetch: typeof globalThis.fetch = async (_url, init) => {
      const body = JSON.parse(init!.body as string) as { messages: Array<{ role: string; content: string }> };
      capturedSystemMessage = body.messages[0]?.content;
      const enc = new TextEncoder();
      const stream = new ReadableStream<Uint8Array>({
        start(c) {
          for (const ch of sseChunks('ok')) c.enqueue(enc.encode(ch));
          c.close();
        },
      });
      return new Response(stream, { status: 200 });
    };

    const session = createInteractiveSession({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: capturingFetch,
      currentPage: '/about',
    });

    await session.sendMessage('hello');

    expect(capturedSystemMessage).toBeDefined();
    expect(capturedSystemMessage).toContain('/about');
  });

  it('throws when upstream returns a non-200 status', async () => {
    const failFetch: typeof globalThis.fetch = async () => {
      return new Response('Internal Server Error', { status: 500 });
    };

    const session = createInteractiveSession({
      config: BASE_CONFIG,
      siteGraph: GRAPH,
      apiKey: 'test-key',
      fetch: failFetch,
    });

    await expect(session.sendMessage('hi')).rejects.toThrow();
  });
});
