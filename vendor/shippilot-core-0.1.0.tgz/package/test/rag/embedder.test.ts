import { describe, it, expect } from 'vitest';
import { LocalEmbedder } from '../../src/rag/embedder.js';

describe.skip('LocalEmbedder (requires model download — run manually)', () => {
  it('has dimensions 384', () => {
    const embedder = new LocalEmbedder();
    expect(embedder.dimensions).toBe(384);
  });

  it('embed returns one vector of length 384 for a single text', async () => {
    const embedder = new LocalEmbedder();
    const result = await embedder.embed(['hello world']);
    expect(result).toHaveLength(1);
    expect(result[0]).toHaveLength(384);
  });

  it('embed returns one vector per input for multiple texts', async () => {
    const embedder = new LocalEmbedder();
    const result = await embedder.embed(['apple', 'banana', 'cherry']);
    expect(result).toHaveLength(3);
    for (const vec of result) {
      expect(vec).toHaveLength(384);
    }
  });

  it('embedding is deterministic (same input = same output)', async () => {
    const embedder = new LocalEmbedder();
    const [a] = await embedder.embed(['test string']);
    const [b] = await embedder.embed(['test string']);
    expect(a).toEqual(b);
  });
});
