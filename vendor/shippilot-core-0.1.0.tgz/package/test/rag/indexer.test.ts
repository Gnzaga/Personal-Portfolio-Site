import { describe, it, expect } from 'vitest';
import type { SiteGraph, ScannedSite, ScannedRoute, VectorStore, ChunkMetadata, SearchResult } from '../../src/types.js';
import { indexGraph } from '../../src/rag/indexer.js';
import { MockEmbedder } from './mock-embedder.js';

// ---------------------------------------------------------------------------
// MockVectorStore
// ---------------------------------------------------------------------------

class MockVectorStore implements VectorStore {
  entries: Array<{ id: string; vector: number[]; metadata: ChunkMetadata }> = [];
  readonly dimensions: number;

  constructor(dims = 8) { this.dimensions = dims; }

  async add(id: string, vector: number[], metadata: ChunkMetadata): Promise<void> {
    this.entries.push({ id, vector, metadata });
  }

  async query(_vector: number[], _topK: number): Promise<SearchResult[]> { return []; }
  async save(_path: string): Promise<void> {}
  async load(_path: string): Promise<void> {}
}

// ---------------------------------------------------------------------------
// Helpers for building minimal fixtures
// ---------------------------------------------------------------------------

function makeRoute(path: string, title: string, snippets: string[]): ScannedRoute {
  return {
    path,
    componentFile: `./src/pages${path}.tsx`,
    isDynamic: false,
    navigableElements: [],
    content: {
      title,
      headings: [],
      textSnippets: snippets,
      metaDescription: null,
      sections: [],
    },
  };
}

function makeGraph(paths: string[]): SiteGraph {
  const nodes: SiteGraph['nodes'] = {};
  for (const path of paths) {
    nodes[path] = {
      path,
      type: 'top-level',
      navbar: `nav-${path.replace('/', '')}`,
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: `Summary for ${path}`,
      contentChunks: [],
    };
  }
  return {
    scope: 'public',
    framework: 'react-router',
    generatedAt: '2026-04-05T00:00:00.000Z',
    pageCount: paths.length,
    nodes,
    edges: [],
  };
}

function makeScannedSite(routes: ScannedRoute[]): ScannedSite {
  return { routes, framework: 'react-router' };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('indexGraph', () => {
  it('indexes all chunks from routes present in the graph', async () => {
    const routeA = makeRoute('/about', 'About Me', ['I am a developer with 5 years of experience building web applications.']);
    const routeB = makeRoute('/projects', 'My Projects', ['I have built many open source libraries and tools over the years.']);
    const graph = makeGraph(['/about', '/projects']);
    const site = makeScannedSite([routeA, routeB]);
    const store = new MockVectorStore();
    const embedder = new MockEmbedder();

    await indexGraph(graph, site, { embedder, store });

    expect(store.entries.length).toBeGreaterThan(0);
    const routes = store.entries.map(e => e.metadata.route);
    expect(routes).toContain('/about');
    expect(routes).toContain('/projects');
  });

  it('skips routes not present in graph.nodes', async () => {
    const routeA = makeRoute('/about', 'About', ['About content here for this page.']);
    const routeGhost = makeRoute('/ghost', 'Ghost', ['This route is not in the graph at all.']);
    const graph = makeGraph(['/about']); // /ghost is NOT in graph
    const site = makeScannedSite([routeA, routeGhost]);
    const store = new MockVectorStore();
    const embedder = new MockEmbedder();

    await indexGraph(graph, site, { embedder, store });

    const routes = store.entries.map(e => e.metadata.route);
    expect(routes).toContain('/about');
    expect(routes).not.toContain('/ghost');
  });

  it('batches embed() calls according to batchSize', async () => {
    // Create 33 routes so with batchSize=32 we expect 2 embed() calls
    const paths = Array.from({ length: 33 }, (_, i) => `/page-${i}`);
    const routes = paths.map(p =>
      makeRoute(p, `Page ${p}`, [`This is the content for page ${p} which has enough text to produce a chunk.`])
    );
    const graph = makeGraph(paths);
    const site = makeScannedSite(routes);
    const store = new MockVectorStore();
    const embedder = new MockEmbedder();

    await indexGraph(graph, site, { embedder, store, batchSize: 32 });

    // 33 routes × 1 chunk each (short content) = 33 chunks → 2 batches
    expect(embedder.embedCalls.length).toBe(2);
    expect(embedder.embedCalls[0]!.length).toBe(32);
    expect(embedder.embedCalls[1]!.length).toBe(1);
  });

  it('passes chunk text to embedder in order', async () => {
    const routeA = makeRoute('/alpha', 'Alpha', ['Alpha page content text goes here.']);
    const routeB = makeRoute('/beta', 'Beta', ['Beta page content text goes here.']);
    const graph = makeGraph(['/alpha', '/beta']);
    const site = makeScannedSite([routeA, routeB]);
    const store = new MockVectorStore();
    const embedder = new MockEmbedder();

    await indexGraph(graph, site, { embedder, store });

    const allTexts = embedder.embedCalls.flat();
    // Both routes should contribute text to the embedder
    const hasAlpha = allTexts.some(t => t.includes('Alpha'));
    const hasBeta = allTexts.some(t => t.includes('Beta'));
    expect(hasAlpha).toBe(true);
    expect(hasBeta).toBe(true);

    // Alpha route text must appear before Beta route text
    const alphaIdx = allTexts.findIndex(t => t.includes('Alpha'));
    const betaIdx = allTexts.findIndex(t => t.includes('Beta'));
    expect(alphaIdx).toBeLessThan(betaIdx);
  });

  it('stores entries with correct metadata', async () => {
    const route = makeRoute('/home', 'Home Page', ['Welcome to the home page of this site.']);
    const graph = makeGraph(['/home']);
    const site = makeScannedSite([route]);
    const store = new MockVectorStore();
    const embedder = new MockEmbedder();

    await indexGraph(graph, site, { embedder, store });

    expect(store.entries.length).toBeGreaterThan(0);
    const first = store.entries[0]!;
    expect(first.metadata.route).toBe('/home');
    expect(typeof first.metadata.text).toBe('string');
    expect(first.metadata.text.length).toBeGreaterThan(0);
    // heading is null or string
    expect(first.metadata.heading === null || typeof first.metadata.heading === 'string').toBe(true);
  });

  it('returns accurate chunkCount matching store entries', async () => {
    const routeA = makeRoute('/foo', 'Foo', ['Foo content for this test page.']);
    const routeB = makeRoute('/bar', 'Bar', ['Bar content for this test page.']);
    const graph = makeGraph(['/foo', '/bar']);
    const site = makeScannedSite([routeA, routeB]);
    const store = new MockVectorStore();
    const embedder = new MockEmbedder();

    const result = await indexGraph(graph, site, { embedder, store });

    expect(result.chunkCount).toBe(store.entries.length);
  });
});
