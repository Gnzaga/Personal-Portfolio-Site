import { describe, it, expect } from 'vitest';
import { retrieveRelevantChunks } from '../../src/rag/retriever.js';
import { MockEmbedder } from './mock-embedder.js';
import type { VectorStore, SearchResult, SiteGraph, GraphNode } from '../../src/types.js';

class MockVectorStore implements VectorStore {
  results: SearchResult[] = [];
  lastQueryVec: number[] | null = null;
  lastTopK: number | null = null;
  readonly dimensions = 8;
  async add() {}
  async query(vec: number[], topK: number) {
    this.lastQueryVec = vec;
    this.lastTopK = topK;
    return this.results;
  }
  async save() {}
  async load() {}
}

function makeGraph(routes: string[]): SiteGraph {
  const nodes: Record<string, GraphNode> = {};
  for (const r of routes) {
    nodes[r] = {
      path: r,
      type: 'top-level',
      navbar: null,
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: '',
      contentChunks: [],
    };
  }
  return {
    scope: 'public',
    nodes,
    edges: [],
    generatedAt: '',
    framework: 'react-router',
    pageCount: routes.length,
  };
}

function makeResult(id: string, route: string, score: number): SearchResult {
  return {
    id,
    score,
    metadata: { route, heading: null, text: `text for ${id}` },
  };
}

describe('retrieveRelevantChunks', () => {
  it('embeds the query string', async () => {
    const embedder = new MockEmbedder();
    const store = new MockVectorStore();
    const graph = makeGraph(['/home']);

    await retrieveRelevantChunks('find my portfolio', {
      embedder,
      store,
      graph,
    });

    expect(embedder.embedCalls[0]![0]).toBe('find my portfolio');
  });

  it('returns up to topK chunks when all routes are in graph', async () => {
    const embedder = new MockEmbedder();
    const store = new MockVectorStore();
    store.results = [
      makeResult('a', '/home', 0.9),
      makeResult('b', '/about', 0.8),
      makeResult('c', '/projects', 0.7),
      makeResult('d', '/contact', 0.6),
    ];
    const graph = makeGraph(['/home', '/about', '/projects', '/contact']);

    const chunks = await retrieveRelevantChunks('hello', {
      embedder,
      store,
      graph,
      topK: 3,
    });

    expect(chunks).toHaveLength(3);
  });

  it('drops chunks whose route is not in graph.nodes', async () => {
    const embedder = new MockEmbedder();
    const store = new MockVectorStore();
    store.results = [
      makeResult('a', '/home', 0.9),
      makeResult('b', '/unknown-route', 0.85),
      makeResult('c', '/about', 0.7),
    ];
    const graph = makeGraph(['/home', '/about']);

    const chunks = await retrieveRelevantChunks('hello', {
      embedder,
      store,
      graph,
      topK: 5,
    });

    expect(chunks).toHaveLength(2);
    expect(chunks.map(c => c.route)).toEqual(['/home', '/about']);
  });

  it('over-fetches from store (topK * 2)', async () => {
    const embedder = new MockEmbedder();
    const store = new MockVectorStore();
    store.results = [];
    const graph = makeGraph(['/home']);

    await retrieveRelevantChunks('hello', {
      embedder,
      store,
      graph,
      topK: 3,
    });

    expect(store.lastTopK).toBe(6);
  });

  it('results preserve order from store (highest score first)', async () => {
    const embedder = new MockEmbedder();
    const store = new MockVectorStore();
    store.results = [
      makeResult('a', '/home', 0.95),
      makeResult('b', '/about', 0.80),
      makeResult('c', '/projects', 0.60),
    ];
    const graph = makeGraph(['/home', '/about', '/projects']);

    const chunks = await retrieveRelevantChunks('hello', {
      embedder,
      store,
      graph,
      topK: 3,
    });

    expect(chunks.map(c => c.id)).toEqual(['a', 'b', 'c']);
  });

  it('returns [] when store returns no results', async () => {
    const embedder = new MockEmbedder();
    const store = new MockVectorStore();
    store.results = [];
    const graph = makeGraph(['/home', '/about']);

    const chunks = await retrieveRelevantChunks('hello', {
      embedder,
      store,
      graph,
      topK: 5,
    });

    expect(chunks).toEqual([]);
  });
});
