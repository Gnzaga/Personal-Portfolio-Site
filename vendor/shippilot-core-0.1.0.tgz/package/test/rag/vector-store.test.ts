import { describe, it, expect, afterEach } from 'vitest';
import { unlink } from 'node:fs/promises';
import { LocalVectorStore } from '../../src/rag/vector-store.js';
import type { ChunkMetadata } from '../../src/types.js';

const TEST_FILE = '/tmp/shippilot-test-vs.json';

afterEach(async () => {
  try {
    await unlink(TEST_FILE);
  } catch {
    // file may not exist — that's fine
  }
});

const makeMetadata = (route: string, text: string): ChunkMetadata => ({
  route,
  heading: null,
  text,
});

describe('LocalVectorStore', () => {
  it('constructor sets dimensions property correctly', () => {
    const store = new LocalVectorStore(128);
    expect(store.dimensions).toBe(128);
  });

  it('add + query single identical vector returns 1 result with score ≈ 1.0', async () => {
    const store = new LocalVectorStore(3);
    const vec = [1, 0, 0];
    const meta = makeMetadata('/home', 'Home page content');
    await store.add('chunk-1', vec, meta);

    const results = await store.query(vec, 1);
    expect(results).toHaveLength(1);
    expect(results[0]!.score).toBeCloseTo(1.0, 4);
    expect(results[0]!.id).toBe('chunk-1');
  });

  it('query with topK=2 against 3 stored vectors returns exactly 2 sorted descending by score', async () => {
    const store = new LocalVectorStore(3);
    // vec A: [1,0,0], query [1,0,0] → score 1.0 (identical)
    // vec B: [0,1,0], query [1,0,0] → score 0.0 (orthogonal)
    // vec C: [1,1,0] normalized, query [1,0,0] → score ≈ 0.707
    await store.add('a', [1, 0, 0], makeMetadata('/a', 'A'));
    await store.add('b', [0, 1, 0], makeMetadata('/b', 'B'));
    await store.add('c', [1, 1, 0], makeMetadata('/c', 'C'));

    const results = await store.query([1, 0, 0], 2);
    expect(results).toHaveLength(2);
    expect(results[0]!.id).toBe('a');
    expect(results[1]!.id).toBe('c');
    expect(results[0]!.score).toBeGreaterThan(results[1]!.score);
  });

  it('topK > stored count returns all stored entries without throwing', async () => {
    const store = new LocalVectorStore(2);
    await store.add('x', [1, 0], makeMetadata('/x', 'X'));
    await store.add('y', [0, 1], makeMetadata('/y', 'Y'));

    const results = await store.query([1, 0], 10);
    expect(results).toHaveLength(2);
  });

  it('query against orthogonal vector returns score ≈ 0', async () => {
    const store = new LocalVectorStore(2);
    await store.add('p', [1, 0], makeMetadata('/p', 'P'));

    const results = await store.query([0, 1], 1);
    expect(results).toHaveLength(1);
    expect(results[0]!.score).toBeCloseTo(0, 4);
  });

  it('dimension mismatch on add throws error with message containing "dimension"', async () => {
    const store = new LocalVectorStore(3);
    await expect(
      store.add('bad', [1, 0], makeMetadata('/bad', 'bad'))
    ).rejects.toThrow(/dimension/i);
  });

  it('dimension mismatch on load throws error with message containing "dimension"', async () => {
    // Save a store with 4 dimensions, then try to load into a 3-dimension store
    const storeA = new LocalVectorStore(4);
    await storeA.add('q', [1, 0, 0, 0], makeMetadata('/q', 'Q'));
    await storeA.save(TEST_FILE);

    const storeB = new LocalVectorStore(3);
    await expect(storeB.load(TEST_FILE)).rejects.toThrow(/dimension/i);
  });

  it('save + load round-trip produces same query result', async () => {
    const storeA = new LocalVectorStore(3);
    await storeA.add('r1', [1, 0, 0], makeMetadata('/r1', 'First'));
    await storeA.add('r2', [0, 1, 0], makeMetadata('/r2', 'Second'));
    await storeA.save(TEST_FILE);

    const storeB = new LocalVectorStore(3);
    await storeB.load(TEST_FILE);

    const results = await storeB.query([1, 0, 0], 1);
    expect(results).toHaveLength(1);
    expect(results[0]!.id).toBe('r1');
    expect(results[0]!.score).toBeCloseTo(1.0, 4);
  });

  it('metadata returned from query matches what was passed to add', async () => {
    const store = new LocalVectorStore(3);
    const meta: ChunkMetadata = {
      route: '/projects/homelab',
      heading: 'My Homelab',
      text: 'I run a Talos-based Kubernetes cluster.',
    };
    await store.add('meta-test', [1, 0, 0], meta);

    const results = await store.query([1, 0, 0], 1);
    expect(results[0]!.metadata).toEqual(meta);
  });
});
