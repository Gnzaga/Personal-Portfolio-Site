import type { EmbeddingProvider } from '../../src/types.js';

function hashVec(text: string, dims: number): number[] {
  const v = new Array<number>(dims).fill(0);
  for (let i = 0; i < text.length; i++) {
    v[i % dims] = (v[i % dims]! + text.charCodeAt(i)) % 1000;
  }
  return v;
}

function normalize(v: number[]): number[] {
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  if (norm === 0) return v;
  return v.map(x => x / norm);
}

export class MockEmbedder implements EmbeddingProvider {
  readonly dimensions: number;
  readonly embedCalls: string[][] = [];

  constructor(dims = 8) { this.dimensions = dims; }

  embed(texts: string[]): Promise<number[][]> {
    this.embedCalls.push(texts);
    return Promise.resolve(texts.map(t => normalize(hashVec(t, this.dimensions))));
  }
}
