import { describe, it, expect } from 'vitest';
import { chunkRouteContent } from '../../src/rag/chunker.js';
import type { ScannedRoute, ExtractedContent } from '../../src/types.js';

// ---------------------------------------------------------------------------
// Fixture helper
// ---------------------------------------------------------------------------

function makeRoute(overrides: Partial<ExtractedContent> = {}, path = '/test'): ScannedRoute {
  return {
    path,
    componentFile: './Test.tsx',
    isDynamic: false,
    navigableElements: [],
    content: {
      title: null,
      headings: [],
      textSnippets: [],
      metaDescription: null,
      sections: [],
      ...overrides,
    },
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('chunkRouteContent', () => {
  it('returns [] for a route with no content', () => {
    const route = makeRoute();
    expect(chunkRouteContent(route)).toEqual([]);
  });

  it('returns [] when title and sections are all empty/whitespace', () => {
    const route = makeRoute({ title: '', sections: [{ heading: '', text: [''] }] });
    expect(chunkRouteContent(route)).toEqual([]);
  });

  it('returns one chunk with heading null for short text with no headings', () => {
    const route = makeRoute({
      sections: [{ heading: null, text: ['Hello world this is a short snippet.'] }],
    });
    const chunks = chunkRouteContent(route);
    expect(chunks).toHaveLength(1);
    expect(chunks[0].heading).toBeNull();
    expect(chunks[0].text).toContain('Hello world');
  });

  it('splits long text into multiple chunks each within chunkSize, with overlap', () => {
    const longText = Array(600).fill('wordy').join(' ');
    const route = makeRoute({ sections: [{ heading: null, text: [longText] }] });
    const chunks = chunkRouteContent(route, { chunkSize: 512, chunkOverlap: 50 });

    expect(chunks.length).toBeGreaterThanOrEqual(2);

    for (const chunk of chunks) {
      const tokens = Math.ceil(chunk.text.length / 4);
      expect(tokens).toBeLessThanOrEqual(512 + 50 + 10);
    }

    const tail = chunks[0].text.slice(-100);
    const overlapStart = chunks[1].text.slice(0, 300);
    expect(overlapStart).toContain(tail.trim().split(' ').slice(-5).join(' '));
  });

  it('tags chunks with the heading active when the chunk starts', () => {
    const introText = Array(15).fill('word').join(' ');
    const gettingStartedText = Array(15).fill('step').join(' ');
    const route = makeRoute({
      sections: [
        { heading: 'Introduction', text: [introText] },
        { heading: 'Getting Started', text: [gettingStartedText] },
      ],
    });
    const chunks = chunkRouteContent(route, { chunkSize: 20, chunkOverlap: 0 });
    const headings = chunks.map((c) => c.heading);
    expect(headings).toContain('Introduction');
    expect(headings).toContain('Getting Started');
  });

  it('preserves the starting heading even if the chunk spans a heading boundary', () => {
    const route = makeRoute({
      sections: [
        { heading: 'First Section', text: ['Short text one.'] },
        { heading: 'Second Section', text: ['Short text two.'] },
      ],
    });
    const chunks = chunkRouteContent(route, { chunkSize: 512 });
    if (chunks.length === 1) {
      expect(chunks[0].heading).toBe('First Section');
    } else {
      expect(chunks[0].heading).toBe('First Section');
    }
  });

  it('seeds each chunk with the last chunkOverlap tokens from the previous chunk', () => {
    const text = Array(300).fill('hello').join(' ');
    const route = makeRoute({ sections: [{ heading: null, text: [text] }] });
    const chunks = chunkRouteContent(route, { chunkSize: 200, chunkOverlap: 40 });

    expect(chunks.length).toBeGreaterThanOrEqual(2);

    const chunk0End = chunks[0].text.split(' ').slice(-20).join(' ');
    expect(chunks[1].text).toContain(chunk0End.split(' ').slice(-5).join(' '));
  });

  it('respects custom chunkSize and chunkOverlap options', () => {
    const text = Array(100).fill('abcd').join(' ');
    const route = makeRoute({ sections: [{ heading: null, text: [text] }] });

    const bigChunks = chunkRouteContent(route, { chunkSize: 512, chunkOverlap: 0 });
    const smallChunks = chunkRouteContent(route, { chunkSize: 50, chunkOverlap: 10 });

    expect(smallChunks.length).toBeGreaterThan(bigChunks.length);
  });

  it('generates unique IDs in the form path#chunk-N starting at 0', () => {
    const text = Array(600).fill('token').join(' ');
    const route = makeRoute({ sections: [{ heading: null, text: [text] }] }, '/my/page');
    const chunks = chunkRouteContent(route, { chunkSize: 200, chunkOverlap: 20 });

    expect(chunks.length).toBeGreaterThanOrEqual(2);

    chunks.forEach((chunk, i) => {
      expect(chunk.id).toBe(`/my/page#chunk-${i}`);
      expect(chunk.route).toBe('/my/page');
    });

    const ids = chunks.map((c) => c.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  // Regression test for the heading/paragraph mispairing bug (finding 4): the
  // old code zipped `headings` and `textSnippets` positionally via shift(),
  // so a section with more paragraphs than another section would silently
  // borrow the wrong heading. `sections` structurally pairs each heading with
  // its own paragraphs, so this must not happen.
  it("tags every paragraph in a section with that section's heading, even when sections have different paragraph counts", () => {
    const route = makeRoute({
      sections: [
        {
          heading: 'Overview',
          text: [
            'First paragraph under Overview.',
            'Second paragraph under Overview.',
            'Third paragraph under Overview.',
          ],
        },
        { heading: 'Details', text: ['A single paragraph under Details.'] },
      ],
    });
    const chunks = chunkRouteContent(route, { chunkSize: 512 });

    const overviewChunk = chunks.find((c) => c.text.includes('Second paragraph under Overview.'));
    expect(overviewChunk).toBeDefined();
    expect(overviewChunk!.heading).toBe('Overview');

    const detailsChunk = chunks.find((c) => c.text.includes('A single paragraph under Details.'));
    expect(detailsChunk).toBeDefined();
    expect(detailsChunk!.heading).toBe('Details');
  });
});
