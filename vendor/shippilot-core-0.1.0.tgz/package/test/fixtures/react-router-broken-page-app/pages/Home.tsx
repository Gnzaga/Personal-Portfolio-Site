export default function Home() {
  return (
    <div>
      <h1>Home</h1>
      <p>This page parses fine.</p>
    </div>
  );
}
