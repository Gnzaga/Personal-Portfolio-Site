import type { ScannedSite } from '../../src/types';

// ---------------------------------------------------------------------------
// React Router fixture — represents the expected scanner output for
// packages/core/test/fixtures/react-router-app/
// ---------------------------------------------------------------------------

export const reactRouterScannedSite: ScannedSite = {
  framework: 'react-router',
  routes: [
    {
      path: '/',
      componentFile: 'pages/Home.tsx',
      isDynamic: false,
      content: {
        title: 'Welcome to My Site',
        headings: ['Welcome to My Site'],
        textSnippets: [
          'This is a personal portfolio showcasing my projects and experience.',
        ],
        metaDescription: null,
        sections: [
          {
            heading: 'Welcome to My Site',
            text: ['This is a personal portfolio showcasing my projects and experience.'],
          },
        ],
      },
      navigableElements: [
        {
          type: 'navlink',
          text: 'View Projects',
          destination: '/projects',
          suggestedTargetId: 'nav-view-projects',
          selector: 'a[href="/projects"]',
        },
      ],
    },
    {
      path: '/projects',
      componentFile: 'pages/Projects.tsx',
      isDynamic: false,
      content: {
        title: 'Projects',
        headings: ['Projects', 'Homelab Infrastructure'],
        textSnippets: [
          'Here are some of my recent projects.',
          'A self-hosted server cluster running Proxmox and Kubernetes.',
        ],
        metaDescription: null,
        sections: [
          { heading: 'Projects', text: ['Here are some of my recent projects.'] },
          {
            heading: 'Homelab Infrastructure',
            text: ['A self-hosted server cluster running Proxmox and Kubernetes.'],
          },
        ],
      },
      navigableElements: [
        {
          type: 'link',
          text: 'View Details',
          destination: '/projects/homelab',
          suggestedTargetId: 'project-homelab-detail',
          selector: '[data-agent-target="project-homelab-detail"]',
        },
      ],
    },
    {
      path: '/projects/homelab',
      componentFile: 'pages/projects/Homelab.tsx',
      isDynamic: false,
      content: {
        title: 'Homelab Infrastructure',
        headings: ['Homelab Infrastructure', 'Overview', 'Key Features'],
        textSnippets: [
          'Three Proxmox nodes with 208GB combined RAM running a Talos-based Kubernetes cluster.',
          'High availability, automated deployments with ArgoCD, and comprehensive monitoring.',
        ],
        metaDescription: null,
        sections: [
          { heading: 'Homelab Infrastructure', text: [] },
          {
            heading: 'Overview',
            text: ['Three Proxmox nodes with 208GB combined RAM running a Talos-based Kubernetes cluster.'],
          },
          {
            heading: 'Key Features',
            text: ['High availability, automated deployments with ArgoCD, and comprehensive monitoring.'],
          },
        ],
        dataAgentTargets: ['homelab-heading'],
      },
      navigableElements: [
        {
          type: 'link',
          text: 'Back to Projects',
          destination: '/projects',
          suggestedTargetId: 'link-back-to-projects',
          selector: 'a[href="/projects"]',
        },
      ],
    },
  ],
};

// ---------------------------------------------------------------------------
// Next.js fixture — represents the expected scanner output for
// packages/core/test/fixtures/nextjs-app/
// ---------------------------------------------------------------------------

export const nextjsScannedSite: ScannedSite = {
  framework: 'nextjs-app',
  routes: [
    {
      path: '/',
      componentFile: 'app/page.tsx',
      isDynamic: false,
      content: {
        title: 'Welcome',
        headings: ['Welcome'],
        textSnippets: ['This is the home page of a Next.js site.'],
        metaDescription: null,
        sections: [
          { heading: 'Welcome', text: ['This is the home page of a Next.js site.'] },
        ],
      },
      navigableElements: [],
    },
    {
      path: '/about',
      componentFile: 'app/about/page.tsx',
      isDynamic: false,
      content: {
        title: 'About Us',
        headings: ['About Us'],
        textSnippets: ['Learn more about our team and mission.'],
        metaDescription: null,
        sections: [
          { heading: 'About Us', text: ['Learn more about our team and mission.'] },
        ],
      },
      navigableElements: [],
    },
    {
      path: '/projects',
      componentFile: 'app/projects/page.tsx',
      isDynamic: false,
      content: {
        title: 'Projects',
        headings: ['Projects'],
        textSnippets: ['Our featured projects and case studies.'],
        metaDescription: null,
        sections: [
          { heading: 'Projects', text: ['Our featured projects and case studies.'] },
        ],
      },
      navigableElements: [
        {
          type: 'link',
          text: 'Homelab Details',
          destination: '/projects/homelab',
          suggestedTargetId: 'link-homelab-details',
          selector: 'a[href="/projects/homelab"]',
        },
      ],
    },
    {
      path: '/projects/homelab',
      componentFile: 'app/projects/homelab/page.tsx',
      isDynamic: false,
      content: {
        title: 'Homelab Project',
        headings: ['Homelab Project'],
        textSnippets: ['A detailed look at the homelab infrastructure.'],
        metaDescription: null,
        sections: [
          { heading: 'Homelab Project', text: ['A detailed look at the homelab infrastructure.'] },
        ],
      },
      navigableElements: [],
    },
    {
      path: '/projects/:slug',
      componentFile: 'app/projects/[slug]/page.tsx',
      isDynamic: true,
      content: {
        title: 'Project Details',
        headings: ['Project Details'],
        textSnippets: [],
        metaDescription: null,
        sections: [
          { heading: 'Project Details', text: [] },
        ],
      },
      navigableElements: [],
    },
  ],
};
