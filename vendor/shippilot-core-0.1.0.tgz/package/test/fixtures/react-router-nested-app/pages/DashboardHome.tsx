export default function DashboardHome() {
  return (
    <div>
      <h2>Dashboard Home</h2>
      <p>Overview of your account.</p>
    </div>
  );
}
