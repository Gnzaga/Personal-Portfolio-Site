export default function DashboardSettings() {
  return (
    <div>
      <h2>Settings</h2>
      <p>Manage your preferences.</p>
    </div>
  );
}
