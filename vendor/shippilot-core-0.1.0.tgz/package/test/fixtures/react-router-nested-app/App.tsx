import { lazy } from 'react';
import { Routes, Route } from 'react-router-dom';

const DashboardLayout = lazy(() => import('./pages/DashboardLayout'));
const DashboardHome = lazy(() => import('./pages/DashboardHome'));
const DashboardSettings = lazy(() => import('./pages/DashboardSettings'));

export default function App() {
  return (
    <Routes>
      <Route path="/dashboard" element={<DashboardLayout />}>
        <Route index element={<DashboardHome />} />
        <Route path="settings" element={<DashboardSettings />} />
      </Route>
    </Routes>
  );
}
