import type { SiteGraph } from '../../src/types.js';

/**
 * A typed SiteGraph fixture mirroring the portfolio site's navigation structure.
 * Target IDs are taken directly from the reference siteGraph.js implementation.
 */
export const portfolioGraph: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  generatedAt: '2026-04-04T00:00:00.000Z',
  pageCount: 17,

  nodes: {
    // ── Top-level pages ──
    '/': {
      path: '/',
      type: 'top-level',
      navbar: 'nav-home',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Home page',
      contentChunks: [],
    },
    '/about': {
      path: '/about',
      type: 'top-level',
      navbar: 'nav-about',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'About page',
      contentChunks: [],
    },
    '/projects': {
      path: '/projects',
      type: 'top-level',
      navbar: 'nav-projects',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Projects listing page',
      contentChunks: [],
    },
    '/experience': {
      path: '/experience',
      type: 'top-level',
      navbar: 'nav-experience',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Experience page',
      contentChunks: [],
    },
    '/blog': {
      path: '/blog',
      type: 'top-level',
      navbar: 'nav-blog',
      parent: null,
      card: null,
      detail: null,
      targets: [],
      contentSummary: 'Blog listing page',
      contentChunks: [],
    },

    // ── Project detail pages ──
    '/projects/homelab': {
      path: '/projects/homelab',
      type: 'detail',
      navbar: null,
      parent: '/projects',
      card: 'project-homelab',
      detail: 'project-homelab-detail',
      targets: [],
      contentSummary: 'Homelab project detail',
      contentChunks: [],
    },
    '/projects/portfolio-project': {
      path: '/projects/portfolio-project',
      type: 'detail',
      navbar: null,
      parent: '/projects',
      card: 'project-portfolio',
      detail: 'project-portfolio-detail',
      targets: [],
      contentSummary: 'Portfolio project detail',
      contentChunks: [],
    },
    '/projects/kubernetes-cluster': {
      path: '/projects/kubernetes-cluster',
      type: 'detail',
      navbar: null,
      parent: '/projects',
      card: 'project-kubernetes',
      detail: 'project-kubernetes-detail',
      targets: [],
      contentSummary: 'Kubernetes cluster project detail',
      contentChunks: [],
    },

    // ── Blog detail pages ──
    '/blog/learning-networking': {
      path: '/blog/learning-networking',
      type: 'detail',
      navbar: null,
      parent: '/blog',
      card: 'blog-learning-networking',
      detail: 'blog-learning-networking-link',
      targets: [],
      contentSummary: 'Blog post about learning networking',
      contentChunks: [],
    },
    '/blog/self-hosting-begins': {
      path: '/blog/self-hosting-begins',
      type: 'detail',
      navbar: null,
      parent: '/blog',
      card: 'blog-self-hosting-begins',
      detail: 'blog-self-hosting-begins-link',
      targets: [],
      contentSummary: 'Blog post about self-hosting beginnings',
      contentChunks: [],
    },
  },

  edges: [
    // Top-level nav edges
    { from: '/', to: '/about', element: 'nav-about', action: 'navClick' },
    { from: '/', to: '/projects', element: 'nav-projects', action: 'navClick' },
    { from: '/', to: '/experience', element: 'nav-experience', action: 'navClick' },
    { from: '/', to: '/blog', element: 'nav-blog', action: 'navClick' },
    // Project detail edges
    { from: '/projects', to: '/projects/homelab', element: 'project-homelab-detail', action: 'clickDetail' },
    { from: '/projects', to: '/projects/portfolio-project', element: 'project-portfolio-detail', action: 'clickDetail' },
    { from: '/projects', to: '/projects/kubernetes-cluster', element: 'project-kubernetes-detail', action: 'clickDetail' },
    // Blog detail edges
    { from: '/blog', to: '/blog/learning-networking', element: 'blog-learning-networking-link', action: 'clickDetail' },
    { from: '/blog', to: '/blog/self-hosting-begins', element: 'blog-self-hosting-begins-link', action: 'clickDetail' },
  ],
};
