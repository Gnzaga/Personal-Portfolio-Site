export default function Home({ slug }: { slug: string }) {
  return (
    <div>
      <h1>Home</h1>
      <a href={slug}>Dynamic</a>
    </div>
  );
}
