import DepthChain3 from './DepthChain3';

export default function DepthChain2() {
  return (
    <div>
      <h1>Depth2</h1>
      <DepthChain3 />
    </div>
  );
}
