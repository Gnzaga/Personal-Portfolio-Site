import Hero from './Hero';

export default function WithHero() {
  return (
    <div>
      <h1>Portfolio</h1>
      <p>Welcome to my site.</p>
      <Hero />
    </div>
  );
}
