import { Link } from 'react-router-dom';

export default function Projects() {
  return (
    <div>
      <h1>Projects</h1>
      <p>Here are some of my recent projects.</p>
      <div data-agent-target="project-homelab">
        <h2>Homelab Infrastructure</h2>
        <p>A self-hosted server cluster running Proxmox and Kubernetes.</p>
        <Link to="/projects/homelab" data-agent-target="project-homelab-detail">
          View Details
        </Link>
      </div>
    </div>
  );
}
