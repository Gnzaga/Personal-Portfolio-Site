import DepthChain2 from './DepthChain2';

export default function DepthChain1() {
  return (
    <div>
      <h1>Depth1</h1>
      <DepthChain2 />
    </div>
  );
}
