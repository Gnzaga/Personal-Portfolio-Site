import DepthChain1 from './DepthChain1';

export default function DepthChain0() {
  return (
    <div>
      <h1>Depth0</h1>
      <DepthChain1 />
    </div>
  );
}
