export default function DepthChain4() {
  return (
    <div>
      <h1>Depth4</h1>
    </div>
  );
}
