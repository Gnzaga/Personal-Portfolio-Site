import { Link } from 'react-router-dom';

export default function Homelab() {
  return (
    <div>
      <h1>Homelab Infrastructure</h1>
      <h2>Overview</h2>
      <p>Three Proxmox nodes with 208GB combined RAM running a Talos-based Kubernetes cluster.</p>
      <h2>Key Features</h2>
      <p>High availability, automated deployments with ArgoCD, and comprehensive monitoring.</p>
      <Link to="/projects">Back to Projects</Link>
    </div>
  );
}
