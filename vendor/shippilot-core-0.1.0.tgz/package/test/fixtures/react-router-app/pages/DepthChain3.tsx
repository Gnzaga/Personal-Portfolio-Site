import DepthChain4 from './DepthChain4';

export default function DepthChain3() {
  return (
    <div>
      <h1>Depth3</h1>
      <DepthChain4 />
    </div>
  );
}
