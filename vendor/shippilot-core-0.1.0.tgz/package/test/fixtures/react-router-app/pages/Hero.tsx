export default function Hero() {
  return (
    <div>
      <h2>Featured Project</h2>
      <p>A deep dive into the homelab build.</p>
    </div>
  );
}
