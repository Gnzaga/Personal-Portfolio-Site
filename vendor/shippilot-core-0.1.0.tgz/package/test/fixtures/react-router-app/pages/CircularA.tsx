import CircularB from './CircularB';

export default function CircularA() {
  return (
    <div>
      <h1>A</h1>
      <CircularB />
    </div>
  );
}
