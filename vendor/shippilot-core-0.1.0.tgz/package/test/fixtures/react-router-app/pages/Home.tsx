import { NavLink } from 'react-router-dom';

export default function Home() {
  return (
    <div>
      <h1>Welcome to My Site</h1>
      <p>This is a personal portfolio showcasing my projects and experience.</p>
      <nav>
        <NavLink to="/projects">View Projects</NavLink>
      </nav>
    </div>
  );
}
