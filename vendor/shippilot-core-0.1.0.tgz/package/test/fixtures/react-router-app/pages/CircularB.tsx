import CircularA from './CircularA';

export default function CircularB() {
  return (
    <div>
      <h2>B</h2>
      <CircularA />
    </div>
  );
}
