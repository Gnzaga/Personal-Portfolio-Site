export default function Home() {
  return (
    <div>
      <h1>Alias Home</h1>
      <p>Resolved via the @/* tsconfig path alias.</p>
    </div>
  );
}
