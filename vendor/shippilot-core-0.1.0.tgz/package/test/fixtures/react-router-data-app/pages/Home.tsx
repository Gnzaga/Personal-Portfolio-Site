export default function Home() {
  return (
    <div>
      <h1>Data Router Home</h1>
      <p>Built with createBrowserRouter.</p>
    </div>
  );
}
