export default function About() {
  return (
    <div>
      <h2>About</h2>
      <p>Nested under the root layout route.</p>
    </div>
  );
}
