export default function Root() {
  return (
    <div>
      <h1>Root Layout</h1>
    </div>
  );
}
