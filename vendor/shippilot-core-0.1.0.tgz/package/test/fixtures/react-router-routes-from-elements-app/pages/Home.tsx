export default function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Rendered via createRoutesFromElements.</p>
    </div>
  );
}
