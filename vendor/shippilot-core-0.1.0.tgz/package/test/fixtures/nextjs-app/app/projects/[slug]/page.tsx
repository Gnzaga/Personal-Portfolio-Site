export default function ProjectDetail({ params }: { params: { slug: string } }) {
  return (
    <div>
      <h1>Project Details</h1>
      <p>Dynamic project page for {params.slug}.</p>
    </div>
  );
}
