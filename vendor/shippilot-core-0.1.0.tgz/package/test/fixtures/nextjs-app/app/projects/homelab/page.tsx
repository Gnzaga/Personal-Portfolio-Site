export default function Homelab() {
  return (
    <div>
      <h1>Homelab Project</h1>
      <p>A detailed look at the homelab infrastructure.</p>
    </div>
  );
}
