import Link from 'next/link';

export default function Projects() {
  return (
    <div>
      <h1>Projects</h1>
      <p>Our featured projects and case studies.</p>
      <Link href="/projects/homelab" data-agent-target="project-homelab-detail">
        Homelab Details
      </Link>
    </div>
  );
}
