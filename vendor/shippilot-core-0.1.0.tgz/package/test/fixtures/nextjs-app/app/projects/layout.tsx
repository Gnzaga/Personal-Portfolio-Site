export default function ProjectsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div>
      <h2>Projects Section</h2>
      {children}
    </div>
  );
}
