export default function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>Learn more about our team and mission.</p>
    </div>
  );
}
