export default function TeamSlot() {
  return (
    <div>
      <h2>Team</h2>
    </div>
  );
}
