export default function InterceptedPhoto({ params }: { params: { id: string } }) {
  return (
    <div>
      <h2>Photo Modal</h2>
      <p>Intercepted photo {params.id}.</p>
    </div>
  );
}
