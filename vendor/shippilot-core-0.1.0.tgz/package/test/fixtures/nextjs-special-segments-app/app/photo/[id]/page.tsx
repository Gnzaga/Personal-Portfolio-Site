export default function Photo({ params }: { params: { id: string } }) {
  return (
    <div>
      <h1>Photo</h1>
      <p>Full photo page {params.id}.</p>
    </div>
  );
}
