export default function About() {
  return (
    <div>
      <h1>About</h1>
      <p>Also declared in routes.tsx.</p>
    </div>
  );
}
