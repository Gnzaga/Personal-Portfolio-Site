export default function Home() {
  return (
    <div>
      <h1>Cross-File Home</h1>
      <p>Routes are declared in a separate routes.tsx module.</p>
    </div>
  );
}
