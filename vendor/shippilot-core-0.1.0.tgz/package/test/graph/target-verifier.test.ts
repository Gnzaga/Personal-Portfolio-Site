import { describe, it, expect } from 'vitest';
import { verifyTargets } from '../../src/graph/target-verifier.js';
import type { SiteGraph, GraphNode } from '../../src/types.js';

function makeNode(overrides: Partial<GraphNode> & { path: string }): GraphNode {
  return {
    path: overrides.path,
    type: 'top-level',
    navbar: null,
    parent: null,
    card: null,
    detail: null,
    targets: [],
    contentSummary: '',
    contentChunks: [],
    ...overrides,
  };
}

function makeGraph(nodes: Record<string, GraphNode>): SiteGraph {
  return {
    scope: 'public',
    framework: 'react-router',
    generatedAt: '2026-01-01T00:00:00.000Z',
    pageCount: Object.keys(nodes).length,
    nodes,
    edges: [],
  };
}

describe('verifyTargets', () => {
  it('returns no warnings when every synthesized ID is present in scanned targets', () => {
    const graph = makeGraph({
      '/': makeNode({ path: '/', navbar: 'nav-home', targets: ['nav-home'] }),
      '/projects': makeNode({
        path: '/projects',
        navbar: 'nav-projects',
        targets: ['nav-projects', 'project-homelab', 'project-homelab-detail'],
      }),
      '/projects/homelab': makeNode({
        path: '/projects/homelab',
        type: 'detail',
        parent: '/projects',
        card: 'project-homelab',
        detail: 'project-homelab-detail',
        targets: [],
      }),
    });

    expect(verifyTargets(graph)).toEqual([]);
  });

  it('warns when a card ID is synthesized but never appears in the parent page JSX (audit repro)', () => {
    const graph = makeGraph({
      '/projects': makeNode({
        path: '/projects',
        navbar: 'nav-projects',
        targets: ['nav-projects', 'homelab-heading'],
      }),
      '/projects/homelab': makeNode({
        path: '/projects/homelab',
        type: 'detail',
        parent: '/projects',
        card: 'homelab-card',
        detail: 'homelab-heading',
        targets: [],
      }),
    });

    const warnings = verifyTargets(graph);
    expect(warnings).toEqual([
      {
        route: '/projects',
        field: 'card',
        expectedId: 'homelab-card',
        message: 'expected data-agent-target="homelab-card" not found in JSX for /projects',
      },
    ]);
  });

  it('warns when a navbar ID never appears anywhere in the scanned site', () => {
    const graph = makeGraph({
      '/': makeNode({ path: '/', navbar: 'nav-home', targets: [] }),
    });

    expect(verifyTargets(graph)).toEqual([
      {
        route: '/',
        field: 'navbar',
        expectedId: 'nav-home',
        message: 'expected data-agent-target="nav-home" not found in JSX for /',
      },
    ]);
  });

  it('attributes card/detail warnings to the parent route even when the parent node is missing from the graph', () => {
    const graph = makeGraph({
      '/projects/homelab': makeNode({
        path: '/projects/homelab',
        type: 'detail',
        parent: '/projects',
        card: 'project-homelab',
        detail: 'project-homelab-detail',
        targets: [],
      }),
    });

    const warnings = verifyTargets(graph);
    expect(warnings.map((w) => w.field).sort()).toEqual(['card', 'detail']);
    expect(warnings.every((w) => w.route === '/projects')).toBe(true);
  });
});
