import { describe, it, expect } from 'vitest';
import { buildSiteGraph } from '../../src/graph/graph-builder.js';
import { reactRouterScannedSite, nextjsScannedSite } from '../fixtures/scannedSiteFixtures.js';
import type { ScannedSite } from '../../src/types.js';

// ---------------------------------------------------------------------------
// Helper: build graph once for all assertions
// ---------------------------------------------------------------------------
const graph = (() => {
  // Lazily evaluated so individual test failures don't block describe blocks
  let _graph: ReturnType<typeof buildSiteGraph> | undefined;
  return () => {
    if (!_graph) _graph = buildSiteGraph(reactRouterScannedSite);
    return _graph;
  };
})();

// ---------------------------------------------------------------------------
// Classification tests
// ---------------------------------------------------------------------------
describe('graph-builder: node classification', () => {
  it('classifies "/" as top-level', () => {
    expect(graph().nodes['/'].type).toBe('top-level');
  });

  it('classifies "/projects" as top-level', () => {
    expect(graph().nodes['/projects'].type).toBe('top-level');
  });

  it('classifies "/projects/homelab" as detail because parent /projects exists', () => {
    expect(graph().nodes['/projects/homelab'].type).toBe('detail');
  });
});

// ---------------------------------------------------------------------------
// Node field tests
// ---------------------------------------------------------------------------
describe('graph-builder: node fields', () => {
  it('sets navbar on top-level nodes — "/" → "nav-home"', () => {
    expect(graph().nodes['/'].navbar).toBe('nav-home');
  });

  it('sets navbar on top-level nodes — "/projects" → "nav-projects"', () => {
    expect(graph().nodes['/projects'].navbar).toBe('nav-projects');
  });

  it('sets parent on detail nodes — "/projects/homelab" has parent "/projects"', () => {
    expect(graph().nodes['/projects/homelab'].parent).toBe('/projects');
  });

  it('sets card target on detail nodes — "/projects/homelab" has card "project-homelab"', () => {
    expect(graph().nodes['/projects/homelab'].card).toBe('project-homelab');
  });

  it('sets detail target on detail nodes — "/projects/homelab" has detail "project-homelab-detail"', () => {
    expect(graph().nodes['/projects/homelab'].detail).toBe('project-homelab-detail');
  });

  it('top-level nodes have null parent, card, and detail', () => {
    const home = graph().nodes['/'];
    expect(home.parent).toBeNull();
    expect(home.card).toBeNull();
    expect(home.detail).toBeNull();

    const projects = graph().nodes['/projects'];
    expect(projects.parent).toBeNull();
    expect(projects.card).toBeNull();
    expect(projects.detail).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Content tests
// ---------------------------------------------------------------------------
describe('graph-builder: content generation', () => {
  it('generates a non-empty contentSummary for all non-dynamic nodes', () => {
    for (const node of Object.values(graph().nodes)) {
      if (node.type !== 'dynamic') {
        expect(node.contentSummary.length).toBeGreaterThan(0);
      }
    }
  });

  it('generates contentChunks from page content — at least some chunks for pages with text', () => {
    // /projects/homelab has both headings and textSnippets
    const homelab = graph().nodes['/projects/homelab'];
    expect(homelab.contentChunks.length).toBeGreaterThan(0);
  });

  it('each contentChunk has a non-empty id, text, and correct route', () => {
    const homelab = graph().nodes['/projects/homelab'];
    for (const chunk of homelab.contentChunks) {
      expect(chunk.id.length).toBeGreaterThan(0);
      expect(chunk.text.length).toBeGreaterThan(0);
      expect(chunk.route).toBe('/projects/homelab');
    }
  });
});

// ---------------------------------------------------------------------------
// Edge tests
// ---------------------------------------------------------------------------
describe('graph-builder: edges', () => {
  it('creates edges from navigable elements — Projects.tsx has link to /projects/homelab', () => {
    const edges = graph().edges;
    const edge = edges.find(
      (e) => e.from === '/projects' && e.to === '/projects/homelab',
    );
    expect(edge).toBeDefined();
  });

  it('creates structural clickDetail edges for detail pages even without explicit Link', () => {
    // The /projects/homelab is a detail of /projects — must have an edge
    const edges = graph().edges;
    const edge = edges.find(
      (e) =>
        e.from === '/projects' &&
        e.to === '/projects/homelab' &&
        e.action === 'clickDetail',
    );
    expect(edge).toBeDefined();
  });

  it('edges from navigable elements to top-level destinations use navClick', () => {
    // Home page has a navlink to /projects
    const edges = graph().edges;
    const edge = edges.find(
      (e) => e.from === '/' && e.to === '/projects',
    );
    expect(edge).toBeDefined();
    expect(edge!.action).toBe('navClick');
  });

  it('edges to detail destinations use clickDetail', () => {
    const edges = graph().edges;
    const edge = edges.find(
      (e) => e.from === '/projects' && e.to === '/projects/homelab',
    );
    expect(edge).toBeDefined();
    expect(edge!.action).toBe('clickDetail');
  });

  it('edge element matches the suggestedTargetId from the navigable element', () => {
    // Projects.tsx has: suggestedTargetId: 'project-homelab-detail'
    const edges = graph().edges;
    const edge = edges.find(
      (e) => e.from === '/projects' && e.to === '/projects/homelab',
    );
    expect(edge).toBeDefined();
    expect(edge!.element).toBe('project-homelab-detail');
  });
});

// ---------------------------------------------------------------------------
// Metadata tests
// ---------------------------------------------------------------------------
describe('graph-builder: metadata', () => {
  it('generatedAt is a valid ISO timestamp', () => {
    const ts = graph().generatedAt;
    expect(() => new Date(ts).toISOString()).not.toThrow();
    expect(new Date(ts).toISOString()).toBe(ts);
  });

  it('framework matches the input ScannedSite', () => {
    expect(graph().framework).toBe('react-router');
  });

  it('pageCount equals the number of non-dynamic routes', () => {
    const nonDynamic = reactRouterScannedSite.routes.filter((r) => !r.isDynamic).length;
    expect(graph().pageCount).toBe(nonDynamic);
  });

  it('scope is "public"', () => {
    expect(graph().scope).toBe('public');
  });
});

// ---------------------------------------------------------------------------
// Orphan test
// ---------------------------------------------------------------------------
describe('graph-builder: orphan routes', () => {
  it('includes orphan route in the graph (warns but does not remove)', () => {
    // Build a modified ScannedSite with a route that has no parent in the set
    const siteWithOrphan: ScannedSite = {
      ...reactRouterScannedSite,
      routes: [
        ...reactRouterScannedSite.routes,
        {
          path: '/orphan/deep-page',
          componentFile: 'pages/orphan/DeepPage.tsx',
          isDynamic: false,
          content: {
            title: 'Orphan Page',
            headings: ['Orphan Page'],
            textSnippets: ['This page has no parent in the route set.'],
            metaDescription: null,
            sections: [{ heading: 'Orphan Page', text: ['This page has no parent in the route set.'] }],
          },
          navigableElements: [],
        },
      ],
    };

    const g = buildSiteGraph(siteWithOrphan);
    // The orphan must still be present
    expect(g.nodes['/orphan/deep-page']).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// Targets (D3)
// ---------------------------------------------------------------------------
describe('graph-builder: targets', () => {
  it('unions data-agent-target attributes and navigableElement suggestedTargetIds, deduped', () => {
    const homelab = graph().nodes['/projects/homelab'];
    expect(homelab.targets).toContain('link-back-to-projects');
    expect(homelab.targets).toContain('homelab-heading');
    expect(new Set(homelab.targets).size).toBe(homelab.targets.length);
  });

  it('/projects targets include the scanned detail link suggestedTargetId', () => {
    expect(graph().nodes['/projects'].targets).toEqual(['project-homelab-detail']);
  });

  it('dynamic nodes have empty targets', () => {
    const dynamicGraph = buildSiteGraph(nextjsScannedSite);
    expect(dynamicGraph.nodes['/projects/:slug'].targets).toEqual([]);
  });
});
