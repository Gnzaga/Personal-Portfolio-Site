import { describe, it, expect } from 'vitest';
import {
  toSlug,
  navTargetId,
  cardTargetId,
  detailTargetId,
} from '../../src/graph/target-id-generator.js';

describe('toSlug', () => {
  it('converts "Homelab Project" to "homelab-project"', () => {
    expect(toSlug('Homelab Project')).toBe('homelab-project');
  });

  it('leaves an already-slugged string unchanged', () => {
    expect(toSlug('already-slugged')).toBe('already-slugged');
  });

  it('trims and collapses surrounding spaces', () => {
    expect(toSlug('  Spaces  Around  ')).toBe('spaces-around');
  });

  it('lowercases UPPERCASE input', () => {
    expect(toSlug('UPPERCASE')).toBe('uppercase');
  });
});

describe('navTargetId', () => {
  it('maps "/" to "nav-home"', () => {
    expect(navTargetId('/')).toBe('nav-home');
  });

  it('maps "/projects" to "nav-projects"', () => {
    expect(navTargetId('/projects')).toBe('nav-projects');
  });

  it('maps "/about" to "nav-about"', () => {
    expect(navTargetId('/about')).toBe('nav-about');
  });

  it('maps "/blog" to "nav-blog"', () => {
    expect(navTargetId('/blog')).toBe('nav-blog');
  });
});

describe('cardTargetId', () => {
  it('singularizes "projects" → "project-homelab"', () => {
    expect(cardTargetId('projects', 'homelab')).toBe('project-homelab');
  });

  it('singularizes "blogs" → "blog-my-post"', () => {
    expect(cardTargetId('blogs', 'my-post')).toBe('blog-my-post');
  });

  it('singularizes "posts" → "post-first"', () => {
    expect(cardTargetId('posts', 'first')).toBe('post-first');
  });

  it('uses unknown plural section as-is → "team-alice"', () => {
    expect(cardTargetId('team', 'alice')).toBe('team-alice');
  });
});

describe('detailTargetId', () => {
  it('produces "project-homelab-detail" for ("projects", "homelab")', () => {
    expect(detailTargetId('projects', 'homelab')).toBe('project-homelab-detail');
  });

  it('produces "blog-my-post-detail" for ("blogs", "my-post")', () => {
    expect(detailTargetId('blogs', 'my-post')).toBe('blog-my-post-detail');
  });
});
