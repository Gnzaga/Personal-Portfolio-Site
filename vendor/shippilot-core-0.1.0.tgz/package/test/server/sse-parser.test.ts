import { describe, it, expect } from 'vitest';
import { parseSSELine, parseSSEChunk } from '../../src/server/sse-parser';

describe('parseSSELine', () => {
  describe('OpenAI format', () => {
    it('parses a delta with content', () => {
      const line = 'data: {"choices":[{"delta":{"content":"Hello"}}]}';
      expect(parseSSELine(line)).toEqual({ type: 'delta', content: 'Hello' });
    });

    it('parses a delta with a space-prefixed content', () => {
      const line = 'data: {"choices":[{"delta":{"content":" world"}}]}';
      expect(parseSSELine(line)).toEqual({ type: 'delta', content: ' world' });
    });

    it('ignores a delta with no content field', () => {
      const line = 'data: {"choices":[{"delta":{}}]}';
      expect(parseSSELine(line)).toEqual({ type: 'ignore' });
    });

    it('ignores a delta with only role field', () => {
      const line = 'data: {"choices":[{"delta":{"role":"assistant"}}]}';
      expect(parseSSELine(line)).toEqual({ type: 'ignore' });
    });
  });

  describe('Ollama format', () => {
    it('parses message.content', () => {
      const line = 'data: {"message":{"content":"Hi"}}';
      expect(parseSSELine(line)).toEqual({ type: 'delta', content: 'Hi' });
    });

    it('parses response field', () => {
      const line = 'data: {"response":"Hello"}';
      expect(parseSSELine(line)).toEqual({ type: 'delta', content: 'Hello' });
    });
  });

  describe('Terminator', () => {
    it('returns done for [DONE] with space after colon', () => {
      expect(parseSSELine('data: [DONE]')).toEqual({ type: 'done' });
    });

    it('returns done for [DONE] without space after colon', () => {
      expect(parseSSELine('data:[DONE]')).toEqual({ type: 'done' });
    });
  });

  describe('Ignored lines', () => {
    it('ignores empty string', () => {
      expect(parseSSELine('')).toEqual({ type: 'ignore' });
    });

    it('ignores SSE comment lines', () => {
      expect(parseSSELine(': keep-alive')).toEqual({ type: 'ignore' });
    });

    it('ignores non-data event lines', () => {
      expect(parseSSELine('event: ping')).toEqual({ type: 'ignore' });
    });

    it('ignores lines with invalid JSON gracefully', () => {
      expect(parseSSELine('data: not valid json')).toEqual({ type: 'ignore' });
    });
  });
});

describe('parseSSEChunk', () => {
  it('parses multiple OpenAI delta lines', () => {
    const chunk = [
      'data: {"choices":[{"delta":{"content":"Hello"}}]}',
      'data: {"choices":[{"delta":{"content":" world"}}]}',
      'data: {"choices":[{"delta":{"content":"!"}}]}',
    ].join('\n');

    const result = parseSSEChunk(chunk);
    expect(result).toHaveLength(3);
    expect(result[0]).toEqual({ type: 'delta', content: 'Hello' });
    expect(result[1]).toEqual({ type: 'delta', content: ' world' });
    expect(result[2]).toEqual({ type: 'delta', content: '!' });
  });

  it('handles mixed content lines followed by a terminator', () => {
    const chunk = [
      'data: {"choices":[{"delta":{"content":"A"}}]}',
      'data: {"choices":[{"delta":{"content":"B"}}]}',
      'data: [DONE]',
    ].join('\n');

    const result = parseSSEChunk(chunk);
    expect(result).toHaveLength(3);
    expect(result[0]).toEqual({ type: 'delta', content: 'A' });
    expect(result[1]).toEqual({ type: 'delta', content: 'B' });
    expect(result[2]).toEqual({ type: 'done' });
  });

  it('skips empty lines between data lines', () => {
    const chunk = [
      'data: {"choices":[{"delta":{"content":"A"}}]}',
      '',
      'data: {"choices":[{"delta":{"content":"B"}}]}',
    ].join('\n');

    const result = parseSSEChunk(chunk);
    expect(result).toHaveLength(2);
    expect(result[0]).toEqual({ type: 'delta', content: 'A' });
    expect(result[1]).toEqual({ type: 'delta', content: 'B' });
  });

  it('handles CRLF line endings', () => {
    const chunk = [
      'data: {"choices":[{"delta":{"content":"A"}}]}',
      'data: {"choices":[{"delta":{"content":"B"}}]}',
    ].join('\r\n');

    const result = parseSSEChunk(chunk);
    expect(result).toHaveLength(2);
    expect(result[0]).toEqual({ type: 'delta', content: 'A' });
    expect(result[1]).toEqual({ type: 'delta', content: 'B' });
  });
});
