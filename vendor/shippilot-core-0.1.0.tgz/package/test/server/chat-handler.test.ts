import { describe, it, expect, vi } from 'vitest';
import { handleChatRequest, type ChatHandlerOptions } from '../../src/server/chat-handler.js';
import { portfolioGraph } from '../fixtures/portfolioGraph.js';

// ─────────────────────────────────────────────────────────────────────────────
// Test helpers
// ─────────────────────────────────────────────────────────────────────────────

function mockFetch(chunks: string[], status = 200): typeof globalThis.fetch {
  return async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        for (const chunk of chunks) {
          controller.enqueue(encoder.encode(chunk));
        }
        controller.close();
      },
    });
    return new Response(stream, { status, headers: { 'content-type': 'text/event-stream' } });
  };
}

function failingFetch(): typeof globalThis.fetch {
  return async () => {
    throw new Error('network fail');
  };
}

async function collectStream(stream: ReadableStream<Uint8Array>): Promise<string> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let result = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    result += decoder.decode(value);
  }
  return result;
}

function baseOptions(overrides: Partial<ChatHandlerOptions> = {}): ChatHandlerOptions {
  return {
    model: {
      endpoint: 'https://example.com/v1/chat/completions',
      apiKey: 'test-key',
      modelName: 'gpt-4o-mini',
    },
    siteGraph: portfolioGraph,
    siteContext: 'Test site',
    ...overrides,
  };
}

// Minimal valid upstream chunks for tests that don't care about content
const minimalChunks = [
  'data: {"choices":[{"delta":{"content":"hello"}}]}\n\n',
  'data: [DONE]\n\n',
];

// ─────────────────────────────────────────────────────────────────────────────
// Validation
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — validation', () => {
  it('rejects empty message with 400', async () => {
    const result = await handleChatRequest(
      { message: '' },
      baseOptions({ fetch: mockFetch(minimalChunks) }),
    );
    expect(result.status).toBe(400);
    expect(typeof result.body).toBe('string');
    expect((result.body as string).toLowerCase()).toContain('message');
  });

  it('rejects non-string message with 400', async () => {
    const result = await handleChatRequest(
      { message: 123 as any },
      baseOptions({ fetch: mockFetch(minimalChunks) }),
    );
    expect(result.status).toBe(400);
    expect(typeof result.body).toBe('string');
  });

  it('rejects missing message with 400', async () => {
    const result = await handleChatRequest(
      { currentPage: '/' } as any,
      baseOptions({ fetch: mockFetch(minimalChunks) }),
    );
    expect(result.status).toBe(400);
    expect(typeof result.body).toBe('string');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// History handling
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — history handling', () => {
  it('filters invalid history entries', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    const history = [
      { role: 'user', content: 'valid user msg' },
      { role: 'invalid-role', content: 'bad role' },   // invalid role
      { role: 'assistant', content: 'valid assistant msg' },
      { role: 'user' },                                  // missing content
      { content: 'missing role' },                       // missing role
      null,                                              // null entry
    ] as any;

    await handleChatRequest(
      { message: 'hello', history },
      baseOptions({ fetch: fetchSpy }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    const historyMessages = requestBody.messages.slice(1, -1); // exclude system and user

    expect(historyMessages).toHaveLength(2);
    expect(historyMessages[0]).toEqual({ role: 'user', content: 'valid user msg' });
    expect(historyMessages[1]).toEqual({ role: 'assistant', content: 'valid assistant msg' });
  });

  it('truncates history to maxHistoryMessages', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    const history = Array.from({ length: 15 }, (_, i) => ({
      role: i % 2 === 0 ? 'user' : 'assistant',
      content: `message ${i}`,
    })) as any;

    await handleChatRequest(
      { message: 'hello', history },
      baseOptions({ fetch: fetchSpy, maxHistoryMessages: 5 }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    const historyMessages = requestBody.messages.slice(1, -1);
    expect(historyMessages).toHaveLength(5);
    // Should be the last 5 messages
    expect(historyMessages[0].content).toBe('message 10');
    expect(historyMessages[4].content).toBe('message 14');
  });

  it('default maxHistoryMessages is 10', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    const history = Array.from({ length: 15 }, (_, i) => ({
      role: i % 2 === 0 ? 'user' : 'assistant',
      content: `message ${i}`,
    })) as any;

    await handleChatRequest(
      { message: 'hello', history },
      baseOptions({ fetch: fetchSpy }), // no maxHistoryMessages
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    const historyMessages = requestBody.messages.slice(1, -1);
    expect(historyMessages).toHaveLength(10);
    expect(historyMessages[0].content).toBe('message 5');
    expect(historyMessages[9].content).toBe('message 14');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Message array construction
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — message array construction', () => {
  it('builds messages array with system + history + user', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    const history = [
      { role: 'user', content: 'prior question' },
      { role: 'assistant', content: 'prior answer' },
    ];

    await handleChatRequest(
      { message: 'new question', currentPage: '/about', history },
      baseOptions({ fetch: fetchSpy }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    const messages = requestBody.messages;

    expect(messages[0].role).toBe('system');
    expect(messages[1]).toEqual({ role: 'user', content: 'prior question' });
    expect(messages[2]).toEqual({ role: 'assistant', content: 'prior answer' });
    expect(messages[3]).toEqual({ role: 'user', content: 'new question' });
  });

  it('system message uses buildSystemPrompt output', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'hi', currentPage: '/about' },
      baseOptions({ fetch: fetchSpy }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    const systemMessage = requestBody.messages[0];

    expect(systemMessage.role).toBe('system');
    // buildSystemPrompt includes the currentPage in PAGE CONTEXT
    expect(systemMessage.content).toContain('/about');
    expect(systemMessage.content).toContain('PAGE CONTEXT');
  });

  it('currentPage defaults to "/" when missing', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'hi' }, // no currentPage
      baseOptions({ fetch: fetchSpy }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    const systemMessage = requestBody.messages[0];
    // The system prompt should reference the root page
    expect(systemMessage.content).toContain('/');
    // The root page contentSummary is 'Home page'
    expect(systemMessage.content).toContain('Home page');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Upstream request
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — upstream request', () => {
  it('forwards Authorization header with Bearer prefix', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: fetchSpy, model: { endpoint: 'https://example.com/v1/chat/completions', apiKey: 'sk-xxx', modelName: 'gpt-4o-mini' } }),
    );

    const requestInit = fetchSpy.mock.calls[0][1]!;
    const headers = requestInit.headers as Record<string, string>;
    expect(headers['Authorization']).toBe('Bearer sk-xxx');
  });

  it('handles apiKey with existing "Bearer " prefix', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: fetchSpy, model: { endpoint: 'https://example.com/v1/chat/completions', apiKey: 'Bearer sk-xxx', modelName: 'gpt-4o-mini' } }),
    );

    const requestInit = fetchSpy.mock.calls[0][1]!;
    const headers = requestInit.headers as Record<string, string>;
    // Should NOT double-prefix
    expect(headers['Authorization']).toBe('Bearer sk-xxx');
  });

  it('sends stream: true in body', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: fetchSpy }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    expect(requestBody.stream).toBe(true);
  });

  it('sends modelName in body', async () => {
    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: fetchSpy }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0][1]!.body as string);
    expect(requestBody.model).toBe('gpt-4o-mini');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Error handling
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — error handling', () => {
  it('returns 502 when fetch throws', async () => {
    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: failingFetch() }),
    );
    expect(result.status).toBe(502);
  });

  it('returns 502 when upstream returns non-200', async () => {
    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: mockFetch(minimalChunks, 500) }),
    );
    expect(result.status).toBe(502);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Streaming
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — streaming', () => {
  it('streams OpenAI-format deltas as downstream SSE', async () => {
    const chunks = [
      'data: {"choices":[{"delta":{"content":"Hello"}}]}\n\n',
      'data: {"choices":[{"delta":{"content":" world"}}]}\n\n',
      'data: [DONE]\n\n',
    ];

    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: mockFetch(chunks) }),
    );

    expect(result.status).toBe(200);
    const output = await collectStream(result.body as ReadableStream<Uint8Array>);

    expect(output).toContain('data: {"delta":"Hello"}\n\n');
    expect(output).toContain('data: {"delta":" world"}\n\n');
  });

  it('terminates stream with [DONE]', async () => {
    const chunks = [
      'data: {"choices":[{"delta":{"content":"hi"}}]}\n\n',
      'data: [DONE]\n\n',
    ];

    const result = await handleChatRequest(
      { message: 'hello' },
      baseOptions({ fetch: mockFetch(chunks) }),
    );

    const output = await collectStream(result.body as ReadableStream<Uint8Array>);
    expect(output).toMatch(/data: \[DONE\]\n\n$/);
  });

  it('handles multiple deltas in single upstream chunk', async () => {
    const chunks = [
      // Two SSE events in one chunk
      'data: {"choices":[{"delta":{"content":"foo"}}]}\n\ndata: {"choices":[{"delta":{"content":"bar"}}]}\n\n',
      'data: [DONE]\n\n',
    ];

    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: mockFetch(chunks) }),
    );

    const output = await collectStream(result.body as ReadableStream<Uint8Array>);
    expect(output).toContain('data: {"delta":"foo"}\n\n');
    expect(output).toContain('data: {"delta":"bar"}\n\n');
  });

  it('ignores malformed upstream lines', async () => {
    const chunks = [
      'this is not valid SSE\n',
      'data: {broken json}\n\n',
      'data: {"choices":[{"delta":{"content":"good"}}]}\n\n',
      'data: [DONE]\n\n',
    ];

    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: mockFetch(chunks) }),
    );

    expect(result.status).toBe(200);
    const output = await collectStream(result.body as ReadableStream<Uint8Array>);
    expect(output).toContain('data: {"delta":"good"}\n\n');
    // Should not contain broken content
    expect(output).not.toContain('broken json');
  });

  it('response status is 200 with SSE content-type on success', async () => {
    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ fetch: mockFetch(minimalChunks) }),
    );

    expect(result.status).toBe(200);
    expect(result.headers['Content-Type']).toContain('text/event-stream');
  });
});
