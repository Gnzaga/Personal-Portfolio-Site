import { describe, it, expect } from 'vitest';
import { createChatHandler } from '../../src/server/nextjs-handler.js';
import type { ChatHandlerOptions } from '../../src/server/chat-handler.js';
import { portfolioGraph } from '../fixtures/portfolioGraph.js';

// ─────────────────────────────────────────────────────────────────────────────
// Test helpers
// ─────────────────────────────────────────────────────────────────────────────

function mockFetch(chunks: string[], status = 200): typeof globalThis.fetch {
  return async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        for (const chunk of chunks) {
          controller.enqueue(encoder.encode(chunk));
        }
        controller.close();
      },
    });
    return new Response(stream, { status, headers: { 'content-type': 'text/event-stream' } });
  };
}

function baseOptions(overrides: Partial<ChatHandlerOptions> = {}): ChatHandlerOptions {
  return {
    model: {
      endpoint: 'https://example.com/v1/chat/completions',
      apiKey: 'test-key',
      modelName: 'gpt-4o-mini',
    },
    siteGraph: portfolioGraph,
    siteContext: 'Test site',
    ...overrides,
  };
}

function makeRequest(body: unknown): Request {
  return new Request('http://localhost/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: typeof body === 'string' ? body : JSON.stringify(body),
  });
}

async function readResponse(response: Response): Promise<string> {
  const text = await response.text();
  return text;
}

// Minimal valid upstream chunks
const minimalChunks = [
  'data: {"choices":[{"delta":{"content":"hello"}}]}\n\n',
  'data: [DONE]\n\n',
];

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('createChatHandler', () => {
  it('returns 400 Response for malformed JSON body', async () => {
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req = makeRequest('this is not valid json{{{');
    const response = await handler(req);
    expect(response.status).toBe(400);
  });

  it('returns 400 Response for empty message', async () => {
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req = makeRequest({ message: '' });
    const response = await handler(req);
    expect(response.status).toBe(400);
  });

  it('returns 400 Response for missing message', async () => {
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req = makeRequest({ currentPage: '/' });
    const response = await handler(req);
    expect(response.status).toBe(400);
  });

  it('returns 200 Response with SSE content-type on success', async () => {
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req = makeRequest({ message: 'hello' });
    const response = await handler(req);
    expect(response.status).toBe(200);
    expect(response.headers.get('Content-Type')).toContain('text/event-stream');
  });

  it('Response body is a ReadableStream on success', async () => {
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req = makeRequest({ message: 'hello' });
    const response = await handler(req);
    expect(response.body).toBeInstanceOf(ReadableStream);
  });

  it('Response body contains SSE delta chunks', async () => {
    const chunks = [
      'data: {"choices":[{"delta":{"content":"Hello"}}]}\n\n',
      'data: {"choices":[{"delta":{"content":" world"}}]}\n\n',
      'data: [DONE]\n\n',
    ];
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(chunks) }));
    const req = makeRequest({ message: 'hello' });
    const response = await handler(req);
    const body = await readResponse(response);
    expect(body).toContain('data: {"delta":"Hello"}\n\n');
    expect(body).toContain('data: {"delta":" world"}\n\n');
  });

  it('Response body ends with [DONE] terminator', async () => {
    const handler = createChatHandler(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req = makeRequest({ message: 'hello' });
    const response = await handler(req);
    const body = await readResponse(response);
    expect(body).toMatch(/data: \[DONE\]\n\n$/);
  });
});
