import { describe, it, expect } from 'vitest';
import { createChatMiddleware, type ExpressRequest, type ExpressResponse } from '../../src/server/express-middleware.js';
import type { ChatHandlerOptions } from '../../src/server/chat-handler.js';
import { portfolioGraph } from '../fixtures/portfolioGraph.js';

// ─────────────────────────────────────────────────────────────────────────────
// Test helpers
// ─────────────────────────────────────────────────────────────────────────────

function mockFetch(chunks: string[], status = 200): typeof globalThis.fetch {
  return async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        for (const chunk of chunks) {
          controller.enqueue(encoder.encode(chunk));
        }
        controller.close();
      },
    });
    return new Response(stream, { status, headers: { 'content-type': 'text/event-stream' } });
  };
}

function baseOptions(overrides: Partial<ChatHandlerOptions> = {}): ChatHandlerOptions {
  return {
    model: {
      endpoint: 'https://example.com/v1/chat/completions',
      apiKey: 'test-key',
      modelName: 'gpt-4o-mini',
    },
    siteGraph: portfolioGraph,
    siteContext: 'Test site',
    ...overrides,
  };
}

function createMockRes() {
  const chunks: string[] = [];
  let statusCode = 200;
  let jsonBody: unknown = null;
  let headWritten: { status: number; headers: Record<string, string> } | null = null;
  let ended = false;

  const res: ExpressResponse = {
    status(code: number) { statusCode = code; return this; },
    json(body: unknown) { jsonBody = body; ended = true; },
    writeHead(status: number, headers: Record<string, string>) {
      headWritten = { status, headers };
    },
    write(chunk: string | Uint8Array) {
      const text = typeof chunk === 'string' ? chunk : new TextDecoder().decode(chunk);
      chunks.push(text);
      return true;
    },
    end() { ended = true; },
    flushHeaders() {},
  };

  return { res, getState: () => ({ statusCode, jsonBody, headWritten, ended, chunks }) };
}

// Minimal valid upstream chunks for streaming tests
const minimalChunks = [
  'data: {"choices":[{"delta":{"content":"hello"}}]}\n\n',
  'data: [DONE]\n\n',
];

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('createChatMiddleware', () => {
  it('returns 400 JSON error for empty message', async () => {
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req: ExpressRequest = { body: { message: '' } };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    expect(state.statusCode).toBe(400);
    expect(state.jsonBody).toMatchObject({ error: expect.any(String) });
    expect(state.ended).toBe(true);
  });

  it('returns 400 JSON error for missing body', async () => {
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req: ExpressRequest = { body: undefined };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    expect(state.statusCode).toBe(400);
    expect(state.jsonBody).toMatchObject({ error: expect.any(String) });
  });

  it('returns 400 JSON error for non-string message', async () => {
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req: ExpressRequest = { body: { message: 42 } };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    expect(state.statusCode).toBe(400);
    expect(state.jsonBody).toMatchObject({ error: expect.any(String) });
  });

  it('writes SSE headers on success', async () => {
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req: ExpressRequest = { body: { message: 'hello' } };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    expect(state.headWritten).not.toBeNull();
    expect(state.headWritten!.status).toBe(200);
    expect(state.headWritten!.headers['Content-Type']).toBe('text/event-stream');
  });

  it('writes SSE delta chunks to response', async () => {
    const chunks = [
      'data: {"choices":[{"delta":{"content":"Hello"}}]}\n\n',
      'data: {"choices":[{"delta":{"content":" world"}}]}\n\n',
      'data: [DONE]\n\n',
    ];
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(chunks) }));
    const req: ExpressRequest = { body: { message: 'hi' } };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    const allChunks = state.chunks.join('');
    expect(allChunks).toContain('data: {"delta":');
  });

  it('writes [DONE] terminator', async () => {
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req: ExpressRequest = { body: { message: 'hi' } };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    const allChunks = state.chunks.join('');
    expect(allChunks).toContain('data: [DONE]\n\n');
  });

  it('ends the response after streaming', async () => {
    const middleware = createChatMiddleware(baseOptions({ fetch: mockFetch(minimalChunks) }));
    const req: ExpressRequest = { body: { message: 'hi' } };
    const { res, getState } = createMockRes();

    await middleware(req, res);

    const state = getState();
    expect(state.ended).toBe(true);
  });
});
