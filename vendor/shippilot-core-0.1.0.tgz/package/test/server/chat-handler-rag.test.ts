import { describe, it, expect, vi } from 'vitest';
import { handleChatRequest, type ChatHandlerOptions } from '../../src/server/chat-handler.js';
import type { VectorStore, SearchResult, ChunkMetadata } from '../../src/types.js';
import { portfolioGraph } from '../fixtures/portfolioGraph.js';
import { MockEmbedder } from '../rag/mock-embedder.js';

// ─────────────────────────────────────────────────────────────────────────────
// Mock vector store
// ─────────────────────────────────────────────────────────────────────────────

class MockVectorStore implements VectorStore {
  searchResults: SearchResult[] = [];
  addCalls: number = 0;

  async add(): Promise<void> {
    this.addCalls++;
  }

  async query(): Promise<SearchResult[]> {
    return this.searchResults;
  }

  async save(): Promise<void> {}
  async load(): Promise<void> {}
}

class ThrowingVectorStore implements VectorStore {
  async add(): Promise<void> {}

  async query(): Promise<SearchResult[]> {
    throw new Error('vector store exploded');
  }

  async save(): Promise<void> {}
  async load(): Promise<void> {}
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared helpers (mirrors chat-handler.test.ts patterns)
// ─────────────────────────────────────────────────────────────────────────────

function mockFetch(chunks: string[], status = 200): typeof globalThis.fetch {
  return async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        for (const chunk of chunks) {
          controller.enqueue(encoder.encode(chunk));
        }
        controller.close();
      },
    });
    return new Response(stream, { status, headers: { 'content-type': 'text/event-stream' } });
  };
}

const minimalChunks = [
  'data: {"choices":[{"delta":{"content":"hello"}}]}\n\n',
  'data: [DONE]\n\n',
];

function baseOptions(overrides: Partial<ChatHandlerOptions> = {}): ChatHandlerOptions {
  return {
    model: {
      endpoint: 'https://example.com/v1/chat/completions',
      apiKey: 'test-key',
      modelName: 'gpt-4o-mini',
    },
    siteGraph: portfolioGraph,
    siteContext: 'Test site',
    fetch: mockFetch(minimalChunks),
    ...overrides,
  };
}

function makeSearchResult(
  id: string,
  route: string,
  text: string,
  heading: string | null = null,
): SearchResult {
  return {
    id,
    score: 0.9,
    metadata: { route, heading, text } satisfies ChunkMetadata,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('handleChatRequest — RAG integration', () => {
  it('retrieves chunks and they appear in the system prompt', async () => {
    const vectorStore = new MockVectorStore();
    const embedder = new MockEmbedder();

    // Seed a result whose route is a known node in portfolioGraph
    vectorStore.searchResults = [
      makeSearchResult('chunk-1', '/about', 'I studied computer science at university.'),
    ];

    const fetchSpy = vi.fn(mockFetch(minimalChunks));

    await handleChatRequest(
      { message: 'Tell me about your education', currentPage: '/' },
      baseOptions({ fetch: fetchSpy, vectorStore, embeddingProvider: embedder }),
    );

    const requestBody = JSON.parse(fetchSpy.mock.calls[0]![1]!.body as string);
    const systemPrompt: string = requestBody.messages[0].content;

    expect(systemPrompt).toContain('I studied computer science at university.');
  });

  it('does not call the retriever when vectorStore is absent', async () => {
    const embedder = new MockEmbedder();

    await handleChatRequest(
      { message: 'hi' },
      // embeddingProvider present, but no vectorStore
      baseOptions({ embeddingProvider: embedder }),
    );

    // embed() should never have been called since retrieval was skipped
    expect(embedder.embedCalls).toHaveLength(0);
  });

  it('does not call the retriever when embeddingProvider is absent', async () => {
    const vectorStore = new MockVectorStore();

    await handleChatRequest(
      { message: 'hi' },
      // vectorStore present, but no embeddingProvider
      baseOptions({ vectorStore }),
    );

    // add() should not have been touched — just confirm query was never called by
    // checking addCalls is still 0 (we can't spy directly, but since no embed
    // happens, the store's query is never called either)
    expect(vectorStore.addCalls).toBe(0);
  });

  it('returns 502 when the vector store query throws', async () => {
    const vectorStore = new ThrowingVectorStore();
    const embedder = new MockEmbedder();

    const result = await handleChatRequest(
      { message: 'hi' },
      baseOptions({ vectorStore, embeddingProvider: embedder }),
    );

    expect(result.status).toBe(502);
    expect(result.body).toBe('RAG retrieval failed');
  });
});
