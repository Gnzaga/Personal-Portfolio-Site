import { buildSystemPrompt } from '../src/prompt/prompt-builder.js';
import { portfolioGraph } from './fixtures/portfolioGraph.js';
import type { PromptBuilderOptions, ContentChunk } from '../src/types.js';

// Base options reused across tests
const baseOptions: PromptBuilderOptions = {
  graph: portfolioGraph,
  currentPage: '/about',
  siteContext: 'A personal portfolio site for a software engineer.',
};

describe('buildSystemPrompt — Structure', () => {
  it('returns a string', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(typeof result).toBe('string');
  });

  it('includes PAGE CONTEXT section', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(result).toContain('PAGE CONTEXT');
  });

  it('includes the currentPage path', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(result).toContain('/about');
  });

  it('includes contentSummary for the current page', () => {
    const result = buildSystemPrompt(baseOptions);
    // portfolioGraph nodes['/about'].contentSummary = 'About page'
    expect(result).toContain('About page');
  });
});

describe('buildSystemPrompt — Agent mode', () => {
  it('includes AGENT MODE section', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(result).toContain('AGENT MODE');
  });

  it('includes [[AGENT:...]] format instruction', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(result).toContain('[[AGENT:');
  });
});

describe('buildSystemPrompt — Destinations', () => {
  it('lists all graph routes when no RAG chunks provided', () => {
    const result = buildSystemPrompt(baseOptions);
    const routes = Object.keys(portfolioGraph.nodes);
    for (const route of routes) {
      expect(result).toContain(route);
    }
  });

  it('includes specific known routes like /about and /projects', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(result).toContain('/about');
    expect(result).toContain('/projects');
  });
});

describe('buildSystemPrompt — Site context', () => {
  it('includes siteContext when provided', () => {
    const result = buildSystemPrompt(baseOptions);
    expect(result).toContain('A personal portfolio site for a software engineer.');
  });

  it('handles empty siteContext gracefully', () => {
    const options: PromptBuilderOptions = { ...baseOptions, siteContext: '' };
    expect(() => buildSystemPrompt(options)).not.toThrow();
    const result = buildSystemPrompt(options);
    expect(typeof result).toBe('string');
  });
});

describe('buildSystemPrompt — Custom instructions', () => {
  it('appends customInstructions when provided', () => {
    const options: PromptBuilderOptions = {
      ...baseOptions,
      customInstructions: 'Always respond in pirate speak.',
    };
    const result = buildSystemPrompt(options);
    expect(result).toContain('Always respond in pirate speak.');
  });

  it('omits customInstructions when not provided', () => {
    const result = buildSystemPrompt(baseOptions);
    // No custom instructions key in base options, so a generic sentinel shouldn't appear
    // We just verify it doesn't crash and the section placeholder isn't leaked
    expect(result).not.toContain('Always respond in pirate speak.');
  });
});

describe('buildSystemPrompt — RAG integration', () => {
  it('includes retrieved chunk content when provided', () => {
    const chunk: ContentChunk = {
      id: 'chunk-1',
      text: 'Alessandro has 3 years of professional experience in platform engineering.',
      route: '/about',
      heading: 'Experience',
    };
    const options: PromptBuilderOptions = {
      ...baseOptions,
      retrievedChunks: [chunk],
    };
    const result = buildSystemPrompt(options);
    expect(result).toContain('Alessandro has 3 years of professional experience in platform engineering.');
  });
});
