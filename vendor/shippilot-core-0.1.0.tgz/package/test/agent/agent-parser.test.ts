import { describe, it, expect } from 'vitest';
import { extractAgentAction, stripAgentTags } from '../../src/agent/agent-parser.js';

// ─── extractAgentAction ───────────────────────────────────────────────────────

describe('extractAgentAction', () => {
  it('1. no tag → cleanedText is original text, agentAction is null', () => {
    const result = extractAgentAction('Hello there');
    expect(result).toEqual({ cleanedText: 'Hello there', agentAction: null });
  });

  it('2. simple nav tag → cleanedText trimmed, agentAction parsed', () => {
    const result = extractAgentAction('Hello [[AGENT:{"nav":"/projects"}]]');
    expect(result.cleanedText).toBe('Hello');
    expect(result.agentAction).toEqual({ nav: '/projects' });
  });

  it('3. tag with nav AND target → both fields in agentAction', () => {
    const result = extractAgentAction('Done [[AGENT:{"nav":"/about","target":"skills"}]]');
    expect(result.cleanedText).toBe('Done');
    expect(result.agentAction).toEqual({ nav: '/about', target: 'skills' });
  });

  it('4. invalid JSON in tag → agentAction null, ALL tags stripped from cleanedText (no raw-tag leak)', () => {
    const result = extractAgentAction('text [[AGENT:{broken]]');
    expect(result.agentAction).toBeNull();
    expect(result.cleanedText).toBe('text');
    expect(result.cleanedText).not.toContain('[[AGENT:');
  });

  it('5. multiple spaces/whitespace in text are preserved up to tag', () => {
    const result = extractAgentAction('Hello   world [[AGENT:{"nav":"/x"}]]');
    expect(result.cleanedText).toBe('Hello   world');
    expect(result.agentAction).toEqual({ nav: '/x' });
  });

  it('6. empty text → cleanedText empty, agentAction null', () => {
    const result = extractAgentAction('');
    expect(result).toEqual({ cleanedText: '', agentAction: null });
  });

  it('7. only tag, no preceding text → cleanedText empty, agentAction populated', () => {
    const result = extractAgentAction('[[AGENT:{"nav":"/home"}]]');
    expect(result.cleanedText).toBe('');
    expect(result.agentAction).toEqual({ nav: '/home' });
  });
});

// ─── stripAgentTags ───────────────────────────────────────────────────────────

describe('stripAgentTags', () => {
  it('8. complete tag is removed, preceding text preserved', () => {
    const result = stripAgentTags('Hello [[AGENT:{"nav":"/x"}]]');
    expect(result).toBe('Hello ');
  });

  it('9. partial tag [[AGENT:... at end is stripped', () => {
    const result = stripAgentTags('Hello [[AGENT:');
    expect(result).toBe('Hello ');
  });

  it('10. dangling [[ at end is stripped', () => {
    const result = stripAgentTags('Hello [[');
    expect(result).toBe('Hello ');
  });

  it('11. no tag → text unchanged', () => {
    const result = stripAgentTags('Hello there');
    expect(result).toBe('Hello there');
  });
});

// ─── D5: shared match function, last-match-wins, trailing text ───────────────

describe('extractAgentAction — tolerates trailing text after the tag (no end anchor)', () => {
  it('12. extracts the tag even when text follows the closing ]]', () => {
    const result = extractAgentAction('Done[[AGENT:{"nav":"/x"}]] extra trailing text');
    expect(result.agentAction).toEqual({ nav: '/x' });
    expect(result.cleanedText).toBe('Done extra trailing text');
    expect(result.cleanedText).not.toContain('[[AGENT:');
  });

  it('13. takes the LAST tag when multiple complete tags are present', () => {
    const result = extractAgentAction('First[[AGENT:{"nav":"/a"}]] Second[[AGENT:{"nav":"/b"}]]');
    expect(result.agentAction).toEqual({ nav: '/b' });
    expect(result.cleanedText).toBe('First Second');
  });

  it('14. invalid JSON with trailing text still strips the tag and returns null action', () => {
    const result = extractAgentAction('Hi[[AGENT:{oops}]] bye');
    expect(result.agentAction).toBeNull();
    expect(result.cleanedText).toBe('Hi bye');
  });
});

describe('extractAgentAction and stripAgentTags never disagree on what counts as a tag', () => {
  it('when a tag is present, cleanedText always equals stripAgentTags(text).trim()', () => {
    const withTag = [
      'Hello [[AGENT:{"nav":"/projects"}]]',
      'text [[AGENT:{broken]]',
      'Done[[AGENT:{"nav":"/x"}]] extra trailing text',
      'First[[AGENT:{"nav":"/a"}]] Second[[AGENT:{"nav":"/b"}]]',
      '[[AGENT:{"nav":"/home"}]]',
    ];
    for (const sample of withTag) {
      expect(extractAgentAction(sample).cleanedText).toBe(stripAgentTags(sample).trim());
    }
  });

  it('when no tag is present, cleanedText equals the original text unchanged', () => {
    expect(extractAgentAction('Hello there').cleanedText).toBe('Hello there');
    expect(extractAgentAction('').cleanedText).toBe('');
  });
});
