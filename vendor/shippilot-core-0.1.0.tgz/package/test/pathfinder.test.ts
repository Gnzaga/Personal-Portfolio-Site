import { computeNavigationSteps } from '../src/graph/pathfinder.js';
import { portfolioGraph } from './fixtures/portfolioGraph.js';
import type { SiteGraph } from '../src/types.js';

// ─────────────────────────────────────────────────────────────────────────────
// 1. Same-page
// ─────────────────────────────────────────────────────────────────────────────
describe('same-page navigation', () => {
  it('returns [] when from === to with no elementTarget', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/projects', '/projects');
    expect(steps).toEqual([]);
  });

  it('returns scroll + highlight when from === to with elementTarget', () => {
    const steps = computeNavigationSteps(
      portfolioGraph,
      '/projects',
      '/projects',
      'project-homelab',
    );
    expect(steps).toEqual([
      { action: 'scroll', target: 'project-homelab' },
      { action: 'highlight', target: 'project-homelab', duration: 3000 },
    ]);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. Top-level destination
// ─────────────────────────────────────────────────────────────────────────────
describe('top-level destination', () => {
  it('produces navClick with correct navTarget and route', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/', '/about');
    expect(steps).toEqual([
      { action: 'navClick', navTarget: 'nav-about', route: '/about' },
    ]);
  });

  it('appends scroll + highlight after navClick when elementTarget given', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/', '/projects', 'project-homelab');
    expect(steps).toEqual([
      { action: 'navClick', navTarget: 'nav-projects', route: '/projects' },
      { action: 'scroll', target: 'project-homelab' },
      { action: 'highlight', target: 'project-homelab', duration: 3000 },
    ]);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. Detail page from a different parent
// ─────────────────────────────────────────────────────────────────────────────
describe('detail page from different parent', () => {
  it('produces navClick → scroll → highlight → clickDetail sequence', () => {
    // Navigating from '/' to '/projects/homelab'
    const steps = computeNavigationSteps(portfolioGraph, '/', '/projects/homelab');
    expect(steps).toEqual([
      { action: 'navClick', navTarget: 'nav-projects', route: '/projects' },
      { action: 'scroll', target: 'project-homelab' },
      { action: 'highlight', target: 'project-homelab', duration: 1500 },
      { action: 'clickDetail', target: 'project-homelab-detail', route: '/projects/homelab' },
    ]);
  });

  it('step count is 4', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/about', '/blog/learning-networking');
    expect(steps).toHaveLength(4);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. Detail page from same parent
// ─────────────────────────────────────────────────────────────────────────────
describe('detail page from same parent', () => {
  it('skips navClick, starts with scroll', () => {
    // Already on /projects, navigate to /projects/homelab
    const steps = computeNavigationSteps(portfolioGraph, '/projects', '/projects/homelab');
    expect(steps[0]).toEqual({ action: 'scroll', target: 'project-homelab' });
  });

  it('step count is 3', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/projects', '/projects/kubernetes-cluster');
    expect(steps).toHaveLength(3);
    // Verify the full sequence: scroll → highlight → clickDetail
    expect(steps).toEqual([
      { action: 'scroll', target: 'project-kubernetes' },
      { action: 'highlight', target: 'project-kubernetes', duration: 1500 },
      { action: 'clickDetail', target: 'project-kubernetes-detail', route: '/projects/kubernetes-cluster' },
    ]);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. Unknown route
// ─────────────────────────────────────────────────────────────────────────────
describe('unknown route', () => {
  it('returns directNav for unrecognized route', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/', '/some/unknown/page');
    expect(steps).toEqual([
      { action: 'directNav', route: '/some/unknown/page' },
    ]);
  });

  it('returns [] for empty string toRoute', () => {
    const steps = computeNavigationSteps(portfolioGraph, '/', '');
    expect(steps).toEqual([]);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. Deeply nested detail pages (3+ levels) — D7
// ─────────────────────────────────────────────────────────────────────────────

const threeLevelGraph: SiteGraph = {
  scope: 'public',
  framework: 'react-router',
  generatedAt: '2026-01-01T00:00:00.000Z',
  pageCount: 3,
  nodes: {
    '/docs': {
      path: '/docs', type: 'top-level', navbar: 'nav-docs', parent: null, card: null, detail: null,
      targets: [], contentSummary: 'Docs', contentChunks: [],
    },
    '/docs/guides': {
      path: '/docs/guides', type: 'detail', navbar: null, parent: '/docs',
      card: 'docs-guides-card', detail: 'docs-guides-detail',
      targets: [], contentSummary: 'Guides', contentChunks: [],
    },
    '/docs/guides/setup': {
      path: '/docs/guides/setup', type: 'detail', navbar: null, parent: '/docs/guides',
      card: 'guides-setup-card', detail: 'guides-setup-detail',
      targets: [], contentSummary: 'Setup guide', contentChunks: [],
    },
  },
  edges: [],
};

describe('deeply nested detail pages (3+ levels)', () => {
  it('walks the full ancestor chain when starting from the top-level page', () => {
    const steps = computeNavigationSteps(threeLevelGraph, '/docs', '/docs/guides/setup');
    expect(steps).toEqual([
      { action: 'scroll', target: 'docs-guides-card' },
      { action: 'highlight', target: 'docs-guides-card', duration: 1500 },
      { action: 'clickDetail', target: 'docs-guides-detail', route: '/docs/guides' },
      { action: 'scroll', target: 'guides-setup-card' },
      { action: 'highlight', target: 'guides-setup-card', duration: 1500 },
      { action: 'clickDetail', target: 'guides-setup-detail', route: '/docs/guides/setup' },
    ]);
  });

  it('navigates to the top-level ancestor first when starting from an unrelated page', () => {
    const steps = computeNavigationSteps(threeLevelGraph, '/', '/docs/guides/setup');
    expect(steps[0]).toEqual({ action: 'navClick', navTarget: 'nav-docs', route: '/docs' });
    expect(steps).toHaveLength(7);
  });

  it('skips already-visited ancestors when starting midway through the chain', () => {
    const steps = computeNavigationSteps(threeLevelGraph, '/docs/guides', '/docs/guides/setup');
    expect(steps).toEqual([
      { action: 'scroll', target: 'guides-setup-card' },
      { action: 'highlight', target: 'guides-setup-card', duration: 1500 },
      { action: 'clickDetail', target: 'guides-setup-detail', route: '/docs/guides/setup' },
    ]);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 7. Dynamic destinations — D7
// ─────────────────────────────────────────────────────────────────────────────

describe('dynamic destinations', () => {
  it('returns [] for a dynamic destination instead of a literal-pattern step', () => {
    const graphWithDynamic: SiteGraph = {
      ...portfolioGraph,
      nodes: {
        ...portfolioGraph.nodes,
        '/blog/:slug': {
          path: '/blog/:slug', type: 'dynamic', navbar: null, parent: null, card: null, detail: null,
          targets: [], contentSummary: '', contentChunks: [],
        },
      },
    };
    const steps = computeNavigationSteps(graphWithDynamic, '/', '/blog/:slug');
    expect(steps).toEqual([]);
  });

  it('returns [] even when an elementTarget is given for a dynamic destination', () => {
    const graphWithDynamic: SiteGraph = {
      ...portfolioGraph,
      nodes: {
        ...portfolioGraph.nodes,
        '/blog/:slug': {
          path: '/blog/:slug', type: 'dynamic', navbar: null, parent: null, card: null, detail: null,
          targets: [], contentSummary: '', contentChunks: [],
        },
      },
    };
    const steps = computeNavigationSteps(graphWithDynamic, '/', '/blog/:slug', 'some-target');
    expect(steps).toEqual([]);
  });
});
