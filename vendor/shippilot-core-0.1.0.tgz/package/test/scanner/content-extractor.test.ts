import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { describe, it, expect } from 'vitest';
import {
  extractContentFromSource,
  extractContentFromFile,
  extractContentFromFileRecursive,
} from '../../src/scanner/content-extractor.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixtureDir = path.resolve(__dirname, '../fixtures/react-router-app');

// ─── Heading extraction ───────────────────────────────────────────────────────

describe('heading extraction', () => {
  it('extracts h1 as title and headings', () => {
    const result = extractContentFromSource('<h1>Hello World</h1>');
    expect(result.content.title).toBe('Hello World');
    expect(result.content.headings).toEqual(['Hello World']);
  });

  it('extracts multiple heading levels', () => {
    const result = extractContentFromSource(
      '<div><h1>Title</h1><h2>Subtitle</h2><h3>Section</h3></div>',
    );
    expect(result.content.headings).toEqual(['Title', 'Subtitle', 'Section']);
    expect(result.content.title).toBe('Title');
  });

  it('returns null title and empty headings when none present', () => {
    const result = extractContentFromSource('<div><p>No headings here</p></div>');
    expect(result.content.title).toBeNull();
    expect(result.content.headings).toEqual([]);
  });

  it('uses first heading as title regardless of level', () => {
    const result = extractContentFromSource('<div><h2>First Heading</h2><h1>Later H1</h1></div>');
    expect(result.content.title).toBe('First Heading');
    expect(result.content.headings).toEqual(['First Heading', 'Later H1']);
  });
});

// ─── Text extraction ──────────────────────────────────────────────────────────

describe('text extraction', () => {
  it('extracts paragraph text', () => {
    const result = extractContentFromSource('<p>Some text</p>');
    expect(result.content.textSnippets).toContain('Some text');
  });

  it('extracts span text', () => {
    const result = extractContentFromSource('<span>Inline text</span>');
    expect(result.content.textSnippets).toContain('Inline text');
  });

  it('handles dynamic-only expressions gracefully', () => {
    const result = extractContentFromSource('<p>{variable}</p>');
    // Should not throw; textSnippets may be empty or contain empty string
    expect(result.content.textSnippets).toBeDefined();
  });

  it('collects multiple text snippets', () => {
    const result = extractContentFromSource(
      '<div><p>First paragraph</p><p>Second paragraph</p></div>',
    );
    expect(result.content.textSnippets).toContain('First paragraph');
    expect(result.content.textSnippets).toContain('Second paragraph');
  });

  // Finding 13: TEXT_TAGS was limited to p/span; expand to common content tags.
  it.each([
    ['li', '<ul><li>List item</li></ul>', 'List item'],
    ['code', '<code>const x = 1;</code>', 'const x = 1;'],
    ['pre', '<pre>preformatted text</pre>', 'preformatted text'],
    ['td', '<table><tr><td>Cell text</td></tr></table>', 'Cell text'],
    ['th', '<table><tr><th>Header text</th></tr></table>', 'Header text'],
    ['blockquote', '<blockquote>A quote</blockquote>', 'A quote'],
    ['figcaption', '<figure><figcaption>A caption</figcaption></figure>', 'A caption'],
    ['dd', '<dl><dd>Definition text</dd></dl>', 'Definition text'],
    ['dt', '<dl><dt>Term text</dt></dl>', 'Term text'],
  ])('extracts text from <%s>', (_tag, source, expectedText) => {
    const result = extractContentFromSource(source);
    expect(result.content.textSnippets).toContain(expectedText);
  });

  it('does not double-count text when a text tag nests another text tag (e.g. <pre><code>)', () => {
    const result = extractContentFromSource('<pre><code>const x = 1;</code></pre>');
    expect(result.content.textSnippets).toEqual(['const x = 1;']);
  });

  it('does not double-count text when a <span> nests inside a <p>', () => {
    const result = extractContentFromSource('<p>Outer <span>Inner</span> text</p>');
    expect(result.content.textSnippets).toEqual(['Outer Inner text']);
  });
});

// ─── Link extraction ──────────────────────────────────────────────────────────

describe('link extraction', () => {
  it('extracts Link component as navlink type', () => {
    const result = extractContentFromSource(
      `import { Link } from 'react-router-dom';
       function A() { return <Link to="/about">About</Link>; }`,
    );
    const link = result.navigableElements.find(el => el.destination === '/about');
    expect(link).toBeDefined();
    expect(link!.type).toBe('link');
    expect(link!.text).toBe('About');
  });

  it('extracts NavLink component as navlink type', () => {
    const result = extractContentFromSource(
      `import { NavLink } from 'react-router-dom';
       function A() { return <NavLink to="/projects">Projects</NavLink>; }`,
    );
    const link = result.navigableElements.find(el => el.destination === '/projects');
    expect(link).toBeDefined();
    expect(link!.type).toBe('navlink');
    expect(link!.text).toBe('Projects');
  });

  it('extracts anchor tags as anchor type', () => {
    const result = extractContentFromSource('<a href="/contact">Contact</a>');
    const link = result.navigableElements.find(el => el.destination === '/contact');
    expect(link).toBeDefined();
    expect(link!.type).toBe('anchor');
  });

  it('excludes external URLs from anchor tags', () => {
    const result = extractContentFromSource('<a href="https://github.com">GitHub</a>');
    const external = result.navigableElements.find(
      el => el.destination === 'https://github.com',
    );
    expect(external).toBeUndefined();
  });

  it('excludes http:// external URLs', () => {
    const result = extractContentFromSource('<a href="http://example.com">Example</a>');
    const external = result.navigableElements.find(
      el => el.destination?.startsWith('http://'),
    );
    expect(external).toBeUndefined();
  });

  it('generates suggestedTargetId from text when no data-agent-target', () => {
    const result = extractContentFromSource('<a href="/contact">Contact Us</a>');
    const link = result.navigableElements.find(el => el.destination === '/contact');
    expect(link!.suggestedTargetId).toBeTruthy();
    expect(typeof link!.suggestedTargetId).toBe('string');
  });

  it('generates a selector for anchor links', () => {
    const result = extractContentFromSource('<a href="/contact">Contact</a>');
    const link = result.navigableElements.find(el => el.destination === '/contact');
    expect(link!.selector).toContain('/contact');
  });

  it('generates a selector for Link components', () => {
    const result = extractContentFromSource(
      `function A() { return <Link to="/about">About</Link>; }`,
    );
    const link = result.navigableElements.find(el => el.destination === '/about');
    expect(link!.selector).toBeTruthy();
  });

  it('reads href on next/link-style <Link href="..."> (D2)', () => {
    const result = extractContentFromSource(
      `import Link from 'next/link';
       function A() { return <Link href="/dashboard">Dashboard</Link>; }`,
    );
    const link = result.navigableElements.find(el => el.destination === '/dashboard');
    expect(link).toBeDefined();
    expect(link!.type).toBe('link');
    expect(link!.text).toBe('Dashboard');
  });

  it('prefers "to" over "href" when a Link has both (react-router precedence)', () => {
    const result = extractContentFromSource(
      `function A() { return <Link to="/a" href="/b">A</Link>; }`,
    );
    const link = result.navigableElements.find(el => el.text === 'A');
    expect(link!.destination).toBe('/a');
  });

  it('excludes external http(s) destinations on next/link-style <Link href="...">', () => {
    const result = extractContentFromSource(
      `import Link from 'next/link';
       function A() { return <Link href="https://example.com">External</Link>; }`,
    );
    const external = result.navigableElements.find(el => el.text === 'External');
    expect(external).toBeUndefined();
  });
});

// ─── data-agent-target handling ───────────────────────────────────────────────

describe('data-agent-target', () => {
  it('uses data-agent-target value as suggestedTargetId for Link', () => {
    const result = extractContentFromSource(
      `function A() { return <Link to="/about" data-agent-target="nav-about">About</Link>; }`,
    );
    const link = result.navigableElements.find(el => el.destination === '/about');
    expect(link).toBeDefined();
    expect(link!.suggestedTargetId).toBe('nav-about');
  });

  it('uses data-agent-target value as suggestedTargetId for anchor', () => {
    const result = extractContentFromSource(
      '<a href="/contact" data-agent-target="nav-contact">Contact</a>',
    );
    const link = result.navigableElements.find(el => el.destination === '/contact');
    expect(link).toBeDefined();
    expect(link!.suggestedTargetId).toBe('nav-contact');
  });

  it('generates selector using data-agent-target when present', () => {
    const result = extractContentFromSource(
      '<a href="/contact" data-agent-target="nav-contact">Contact</a>',
    );
    const link = result.navigableElements.find(el => el.destination === '/contact');
    expect(link!.selector).toBe('[data-agent-target="nav-contact"]');
  });

  it('parses div with data-agent-target without errors', () => {
    // Should not throw; data-agent-target on non-links is OK
    expect(() =>
      extractContentFromSource('<div data-agent-target="my-target">text</div>'),
    ).not.toThrow();
  });
});

// ─── TypeScript support ───────────────────────────────────────────────────────

describe('TypeScript support', () => {
  it('parses TSX with typed props without error', () => {
    const source = `
      import React from 'react';

      interface Props {
        name: string;
        count: number;
      }

      export default function MyComponent({ name, count }: Props) {
        return (
          <div>
            <h1>{name}</h1>
            <p>Count: {count}</p>
          </div>
        );
      }
    `;
    expect(() => extractContentFromSource(source)).not.toThrow();
  });

  it('parses generic type annotations without error', () => {
    const source = `
      const items = new Array<string>();
      function Comp() {
        return <h1>Hello</h1>;
      }
    `;
    expect(() => extractContentFromSource(source)).not.toThrow();
    const result = extractContentFromSource(source);
    expect(result.content.headings).toContain('Hello');
  });
});

// ─── Fixture file tests ───────────────────────────────────────────────────────

describe('extractContentFromFile - Projects.tsx fixture', () => {
  const projectsFile = path.join(fixtureDir, 'pages/Projects.tsx');

  it('finds h1 "Projects"', () => {
    const result = extractContentFromFile(projectsFile);
    expect(result.content.title).toBe('Projects');
    expect(result.content.headings).toContain('Projects');
  });

  it('finds h2 "Homelab Infrastructure"', () => {
    const result = extractContentFromFile(projectsFile);
    expect(result.content.headings).toContain('Homelab Infrastructure');
  });

  it('finds the Link to /projects/homelab', () => {
    const result = extractContentFromFile(projectsFile);
    const link = result.navigableElements.find(
      el => el.destination === '/projects/homelab',
    );
    expect(link).toBeDefined();
    expect(link!.text).toBe('View Details');
  });

  it('uses data-agent-target="project-homelab-detail" for the detail link', () => {
    const result = extractContentFromFile(projectsFile);
    const link = result.navigableElements.find(
      el => el.destination === '/projects/homelab',
    );
    expect(link!.suggestedTargetId).toBe('project-homelab-detail');
  });

  it('selector for detail link uses data-agent-target', () => {
    const result = extractContentFromFile(projectsFile);
    const link = result.navigableElements.find(
      el => el.destination === '/projects/homelab',
    );
    expect(link!.selector).toBe('[data-agent-target="project-homelab-detail"]');
  });

  it('extracts paragraph text snippets', () => {
    const result = extractContentFromFile(projectsFile);
    expect(result.content.textSnippets).toContain('Here are some of my recent projects.');
    expect(result.content.textSnippets).toContain(
      'A self-hosted server cluster running Proxmox and Kubernetes.',
    );
  });
});

// ─── sections (D1) ─────────────────────────────────────────────────────────────

describe('sections', () => {
  it('groups a single heading with its following paragraph', () => {
    const result = extractContentFromSource('<div><h1>Title</h1><p>Body text.</p></div>');
    expect(result.content.sections).toEqual([
      { heading: 'Title', text: ['Body text.'] },
    ]);
  });

  it('assigns a null-heading section to text before the first heading', () => {
    const result = extractContentFromSource(
      '<div><p>Preamble.</p><h1>Title</h1><p>Body.</p></div>',
    );
    expect(result.content.sections).toEqual([
      { heading: null, text: ['Preamble.'] },
      { heading: 'Title', text: ['Body.'] },
    ]);
  });

  it('starts a new section per heading even with no text between them', () => {
    const result = extractContentFromSource('<div><h1>A</h1><h2>B</h2><p>Text.</p></div>');
    expect(result.content.sections).toEqual([
      { heading: 'A', text: [] },
      { heading: 'B', text: ['Text.'] },
    ]);
  });

  it('derives headings and textSnippets from sections', () => {
    const result = extractContentFromSource(
      '<div><h1>A</h1><p>One.</p><h2>B</h2><p>Two.</p></div>',
    );
    expect(result.content.headings).toEqual(['A', 'B']);
    expect(result.content.textSnippets).toEqual(['One.', 'Two.']);
  });

  it('matches the Projects.tsx fixture section grouping', () => {
    const result = extractContentFromFile(path.join(fixtureDir, 'pages/Projects.tsx'));
    expect(result.content.sections).toEqual([
      { heading: 'Projects', text: ['Here are some of my recent projects.'] },
      {
        heading: 'Homelab Infrastructure',
        text: ['A self-hosted server cluster running Proxmox and Kubernetes.'],
      },
    ]);
  });
});

// ─── Recursive import-following extraction (finding 4) ────────────────────────

describe('extractContentFromFileRecursive', () => {
  it('merges content from a locally-imported, rendered child component', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/WithHero.tsx'));
    expect(result.content.sections).toEqual([
      { heading: 'Portfolio', text: ['Welcome to my site.'] },
      { heading: 'Featured Project', text: ['A deep dive into the homelab build.'] },
    ]);
    expect(result.content.headings).toEqual(['Portfolio', 'Featured Project']);
    expect(result.content.textSnippets).toEqual([
      'Welcome to my site.',
      'A deep dive into the homelab build.',
    ]);
  });

  it('keeps the entry file\'s own title as the page title', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/WithHero.tsx'));
    expect(result.content.title).toBe('Portfolio');
  });

  it('does not follow bare/package imports (e.g. react-router-dom Link/NavLink)', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/Home.tsx'));
    // Home.tsx renders <NavLink> from 'react-router-dom' — must not attempt to
    // resolve/recurse into it as if it were a local component.
    expect(result.content.title).toBe('Welcome to My Site');
    expect(result.content.sections).toEqual([
      {
        heading: 'Welcome to My Site',
        text: ['This is a personal portfolio showcasing my projects and experience.'],
      },
    ]);
  });

  it('guards against circular local imports without infinite recursion', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/CircularA.tsx'));
    expect(result.content.headings).toEqual(['A', 'B']);
  });

  it('stops following imports past the default depth limit of 3', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/DepthChain0.tsx'));
    // Depth0 (own) -> Depth1 -> Depth2 -> Depth3 all included; Depth4 is one level too deep.
    expect(result.content.headings).toEqual(['Depth0', 'Depth1', 'Depth2', 'Depth3']);
  });

  it('respects a custom maxDepth option', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/DepthChain0.tsx'), {
      maxDepth: 1,
    });
    expect(result.content.headings).toEqual(['Depth0', 'Depth1']);
  });
});

describe('extractContentFromFile - Homelab.tsx fixture', () => {
  const homelabFile = path.join(fixtureDir, 'pages/projects/Homelab.tsx');

  it('finds h1 "Homelab Infrastructure"', () => {
    const result = extractContentFromFile(homelabFile);
    expect(result.content.title).toBe('Homelab Infrastructure');
    expect(result.content.headings).toContain('Homelab Infrastructure');
  });

  it('finds h2 headings', () => {
    const result = extractContentFromFile(homelabFile);
    expect(result.content.headings).toContain('Overview');
    expect(result.content.headings).toContain('Key Features');
  });

  it('extracts paragraph text snippets', () => {
    const result = extractContentFromFile(homelabFile);
    expect(result.content.textSnippets).toContain(
      'Three Proxmox nodes with 208GB combined RAM running a Talos-based Kubernetes cluster.',
    );
    expect(result.content.textSnippets).toContain(
      'High availability, automated deployments with ArgoCD, and comprehensive monitoring.',
    );
  });

  it('finds the Link back to /projects', () => {
    const result = extractContentFromFile(homelabFile);
    const link = result.navigableElements.find(el => el.destination === '/projects');
    expect(link).toBeDefined();
    expect(link!.text).toBe('Back to Projects');
  });
});

// ─── Dynamic link destinations (finding 7) ─────────────────────────────────────

describe('dynamic link destinations', () => {
  it('records the static prefix of a template-literal destination with pattern: true', () => {
    const result = extractContentFromSource(
      'function A({ slug }) { return <Link to={`/projects/${slug}`}>View</Link>; }',
    );
    const link = result.navigableElements.find((el) => el.text === 'View');
    expect(link).toBeDefined();
    expect(link!.destination).toBe('/projects/');
    expect(link!.pattern).toBe(true);
  });

  it('does not set pattern for an ordinary static destination', () => {
    const result = extractContentFromSource('<Link to="/about">About</Link>');
    const link = result.navigableElements.find((el) => el.text === 'About');
    expect(link!.pattern).toBeFalsy();
  });

  it('counts a fully dynamic destination as unresolvable and drops it (destination: null)', () => {
    const result = extractContentFromSource(
      'function A({ href }) { return <a href={href}>Dynamic</a>; }',
    );
    const link = result.navigableElements.find((el) => el.text === 'Dynamic');
    expect(link).toBeDefined();
    expect(link!.destination).toBeNull();
    expect(result.unresolvableLinkCount).toBe(1);
  });

  it('applies pattern-prefix extraction to native <a href> template literals too', () => {
    const result = extractContentFromSource(
      'function A({ id }) { return <a href={`/blog/${id}`}>Post</a>; }',
    );
    const link = result.navigableElements.find((el) => el.text === 'Post');
    expect(link!.destination).toBe('/blog/');
    expect(link!.pattern).toBe(true);
  });

  it('does not count a missing destination attribute as unresolvable', () => {
    const result = extractContentFromSource('<a data-agent-target="icon-link" />');
    expect(result.unresolvableLinkCount).toBe(0);
  });

  it('sums unresolvableLinkCount across recursively-merged imported components', () => {
    const result = extractContentFromFileRecursive(path.join(fixtureDir, 'pages/WithHero.tsx'));
    expect(result.unresolvableLinkCount).toBe(0);
  });
});

// ─── metaDescription (finding 8) ───────────────────────────────────────────────

describe('metaDescription extraction', () => {
  it('reads <meta name="description"> from a <Helmet> block', () => {
    const result = extractContentFromSource(
      `import { Helmet } from 'react-helmet';
       function A() {
         return (
           <Helmet>
             <title>Page Title</title>
             <meta name="description" content="A great page." />
           </Helmet>
         );
       }`,
    );
    expect(result.content.metaDescription).toBe('A great page.');
  });

  it('uses the Helmet <title> as content.title only when no h1/h2 is present', () => {
    const result = extractContentFromSource(
      `<Helmet><title>Page Title</title></Helmet>`,
    );
    expect(result.content.title).toBe('Page Title');
  });

  it('does not let a Helmet <title> override an existing h1 title', () => {
    const result = extractContentFromSource(
      `<div><h1>Real Heading</h1><Helmet><title>SEO Title</title></Helmet></div>`,
    );
    expect(result.content.title).toBe('Real Heading');
  });

  it('reads <meta name="description"> from a Next.js <Head> block', () => {
    const result = extractContentFromSource(
      `import Head from 'next/head';
       function A() {
         return (
           <Head>
             <meta name="description" content="Next.js head description." />
           </Head>
         );
       }`,
    );
    expect(result.content.metaDescription).toBe('Next.js head description.');
  });

  it('reads title/description from a Next.js `export const metadata` object literal', () => {
    const result = extractContentFromSource(
      `export const metadata = {
         title: 'My Page',
         description: 'SEO description here.',
       };
       export default function Page() {
         return <h1>Real Heading</h1>;
       }`,
    );
    expect(result.content.metaDescription).toBe('SEO description here.');
    expect(result.content.title).toBe('Real Heading');
  });

  it('falls back to `metadata.title` when the page has no heading of its own', () => {
    const result = extractContentFromSource(
      `export const metadata = { title: 'My Page', description: 'SEO description.' };
       export default function Page() {
         return <p>No heading here.</p>;
       }`,
    );
    expect(result.content.title).toBe('My Page');
  });
});

// ─── MDX / Markdown pages (finding 12) ─────────────────────────────────────────

describe('extractContentFromFile - MDX/MD pages', () => {
  const mdxFixtureDir = path.resolve(__dirname, '../fixtures/nextjs-mdx-app/app');

  it('extracts headings/paragraphs from a .mdx file, skipping frontmatter and imports', () => {
    const result = extractContentFromFile(path.join(mdxFixtureDir, 'blog/page.mdx'));
    expect(result.content.title).toBe('Blog Post Heading');
    expect(result.content.headings).toEqual(['Blog Post Heading', 'Subheading']);
    expect(result.content.textSnippets).toEqual([
      'This is the first paragraph of the blog post.',
      'Another paragraph after the subheading.',
    ]);
    expect(result.navigableElements).toEqual([]);
  });

  it('extracts headings/paragraphs from a plain .md file', () => {
    const result = extractContentFromFile(path.join(mdxFixtureDir, 'docs/page.md'));
    expect(result.content.title).toBe('Docs Page');
    expect(result.content.textSnippets).toEqual(['Plain markdown docs content here.']);
  });
});

// ─── dataAgentTargets (D3) ─────────────────────────────────────────────────

describe('dataAgentTargets', () => {
  it('collects data-agent-target attribute values from non-link elements', () => {
    const result = extractContentFromSource(
      '<div><h1 data-agent-target="hero">Title</h1><div data-agent-target="panel">x</div></div>',
    );
    expect(result.content.dataAgentTargets).toEqual(['hero', 'panel']);
  });

  it('dedupes repeated data-agent-target values', () => {
    const result = extractContentFromSource(
      '<div><span data-agent-target="dup">a</span><span data-agent-target="dup">b</span></div>',
    );
    expect(result.content.dataAgentTargets).toEqual(['dup']);
  });

  it('also includes data-agent-target values from link elements', () => {
    const result = extractContentFromSource(
      '<a href="/contact" data-agent-target="nav-contact">Contact</a>',
    );
    expect(result.content.dataAgentTargets).toEqual(['nav-contact']);
  });

  it('returns empty array when no data-agent-target attributes are present', () => {
    const result = extractContentFromSource('<div><p>No targets here</p></div>');
    expect(result.content.dataAgentTargets).toEqual([]);
  });
});

// ─── Programmatic navigation via onClick (finding 9) ──────────────────────────

describe('programmatic navigation via onClick', () => {
  it('captures onClick={() => navigate("/x")} as a button NavigableElement', () => {
    const result = extractContentFromSource(
      `function A() {
         const navigate = useNavigate();
         return <button onClick={() => navigate('/projects')}>Go</button>;
       }`,
    );
    const el = result.navigableElements.find((e) => e.destination === '/projects');
    expect(el).toBeDefined();
    expect(el!.type).toBe('button');
  });

  it('captures onClick={() => router.push("/x")} as a button NavigableElement', () => {
    const result = extractContentFromSource(
      `function A() {
         return <div onClick={() => router.push('/about')}>Card</div>;
       }`,
    );
    const el = result.navigableElements.find((e) => e.destination === '/about');
    expect(el).toBeDefined();
    expect(el!.type).toBe('button');
  });

  it('captures onClick with a block-statement arrow body', () => {
    const result = extractContentFromSource(
      `function A() {
         return <button onClick={() => { navigate('/contact'); }}>Contact</button>;
       }`,
    );
    const el = result.navigableElements.find((e) => e.destination === '/contact');
    expect(el).toBeDefined();
  });

  it('uses data-agent-target as suggestedTargetId when present on the clickable element', () => {
    const result = extractContentFromSource(
      `function A() {
         return <button data-agent-target="go-projects" onClick={() => navigate('/projects')}>Go</button>;
       }`,
    );
    const el = result.navigableElements.find((e) => e.destination === '/projects');
    expect(el!.suggestedTargetId).toBe('go-projects');
  });

  it('falls back to a slug of the button text when no data-agent-target is present', () => {
    const result = extractContentFromSource(
      `function A() {
         return <button onClick={() => navigate('/projects')}>View Projects</button>;
       }`,
    );
    const el = result.navigableElements.find((e) => e.destination === '/projects');
    expect(el!.suggestedTargetId).toBe('view-projects');
  });

  it('ignores onClick handlers with no navigate/router.push call', () => {
    const result = extractContentFromSource(
      `function A() {
         return <button onClick={() => console.log('clicked')}>Click</button>;
       }`,
    );
    expect(result.navigableElements).toHaveLength(0);
  });

  it('ignores onClick handlers whose call argument is not a string literal', () => {
    const result = extractContentFromSource(
      `function A() {
         const path = getPath();
         return <button onClick={() => navigate(path)}>Go</button>;
       }`,
    );
    expect(result.navigableElements).toHaveLength(0);
  });
});
