import { describe, it, expect, vi } from 'vitest';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { scanNextJs } from '../../src/scanner/nextjs-scanner.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixtureDir = path.resolve(__dirname, '../fixtures/nextjs-app');
const appDir = path.resolve(fixtureDir, 'app');
const unresolvableLinkFixtureDir = path.resolve(__dirname, '../fixtures/nextjs-unresolvable-link-app');
const emptyFixtureDir = path.resolve(__dirname, '../fixtures/nextjs-empty-app');
const specialSegmentsFixtureDir = path.resolve(__dirname, '../fixtures/nextjs-special-segments-app');
const mdxFixtureDir = path.resolve(__dirname, '../fixtures/nextjs-mdx-app');

describe('scanNextJs — data-agent-target survives end-to-end (D3 verification)', () => {
  it('carries data-agent-target through to suggestedTargetId/selector on the scanned route', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const projects = result.routes.find((r) => r.path === '/projects');
    expect(projects).toBeDefined();
    const link = projects!.navigableElements.find(
      (e) => e.destination === '/projects/homelab',
    );
    expect(link).toBeDefined();
    expect(link!.suggestedTargetId).toBe('project-homelab-detail');
    expect(link!.selector).toBe('[data-agent-target="project-homelab-detail"]');
  });
});

describe('scanNextJs — MDX/MD pages (finding 12)', () => {
  it('discovers page.mdx and page.md alongside page.tsx', async () => {
    const result = await scanNextJs({
      appDir: path.join(mdxFixtureDir, 'app'),
      projectRoot: mdxFixtureDir,
    });
    const paths = result.routes.map((r) => r.path).sort();
    expect(paths).toEqual(['/', '/blog', '/docs']);
  });

  it('extracts headings and paragraphs from an MDX page, skipping frontmatter and imports', async () => {
    const result = await scanNextJs({
      appDir: path.join(mdxFixtureDir, 'app'),
      projectRoot: mdxFixtureDir,
    });
    const blog = result.routes.find((r) => r.path === '/blog');
    expect(blog).toBeDefined();
    expect(blog!.content.title).toBe('Blog Post Heading');
    expect(blog!.content.headings).toEqual(['Blog Post Heading', 'Subheading']);
    expect(blog!.content.textSnippets).toEqual([
      'This is the first paragraph of the blog post.',
      'Another paragraph after the subheading.',
    ]);
    expect(blog!.content.textSnippets.join(' ')).not.toContain('title: My Blog Post');
    expect(blog!.content.textSnippets.join(' ')).not.toContain('import Callout');
  });

  it('extracts headings and paragraphs from a plain .md page', async () => {
    const result = await scanNextJs({
      appDir: path.join(mdxFixtureDir, 'app'),
      projectRoot: mdxFixtureDir,
    });
    const docs = result.routes.find((r) => r.path === '/docs');
    expect(docs).toBeDefined();
    expect(docs!.content.title).toBe('Docs Page');
    expect(docs!.content.textSnippets).toEqual(['Plain markdown docs content here.']);
  });
});

describe('scanNextJs — parallel and intercepting segments (finding 11)', () => {
  it('strips @slot parallel-route segments from the path entirely', async () => {
    const result = await scanNextJs({
      appDir: path.join(specialSegmentsFixtureDir, 'app'),
      projectRoot: specialSegmentsFixtureDir,
    });
    const paths = result.routes.map((r) => r.path);
    expect(paths.some((p) => p.includes('@team'))).toBe(false);
    expect(paths.filter((p) => p === '/dashboard')).toHaveLength(2); // page.tsx + @team/page.tsx
  });

  it('strips (.) intercepting-route prefixes, keeping the intercepted segment', async () => {
    const result = await scanNextJs({
      appDir: path.join(specialSegmentsFixtureDir, 'app'),
      projectRoot: specialSegmentsFixtureDir,
    });
    const intercepted = result.routes.find(
      (r) => r.componentFile === 'app/feed/(.)photo/[id]/page.tsx',
    );
    expect(intercepted).toBeDefined();
    expect(intercepted!.path).toBe('/feed/photo/:id');
  });

  it('leaves the non-intercepted equivalent route unaffected', async () => {
    const result = await scanNextJs({
      appDir: path.join(specialSegmentsFixtureDir, 'app'),
      projectRoot: specialSegmentsFixtureDir,
    });
    const real = result.routes.find((r) => r.componentFile === 'app/photo/[id]/page.tsx');
    expect(real).toBeDefined();
    expect(real!.path).toBe('/photo/:id');
  });
});

describe('scanNextJs — zero pages found (finding 9)', () => {
  it('warns loudly when the app directory has no page files', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      const result = await scanNextJs({
        appDir: path.join(emptyFixtureDir, 'app'),
        projectRoot: emptyFixtureDir,
      });
      expect(result.routes).toHaveLength(0);
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('0 page'));
    } finally {
      warnSpy.mockRestore();
    }
  });

  it('warns loudly when appDir does not exist at all', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      const result = await scanNextJs({
        appDir: path.join(emptyFixtureDir, 'does-not-exist'),
        projectRoot: emptyFixtureDir,
      });
      expect(result.routes).toHaveLength(0);
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('0 page'));
    } finally {
      warnSpy.mockRestore();
    }
  });
});

describe('scanNextJs — unresolvable link diagnostic (finding 7)', () => {
  it('warns with a count of links whose destination could not be resolved', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      await scanNextJs({
        appDir: path.join(unresolvableLinkFixtureDir, 'app'),
        projectRoot: unresolvableLinkFixtureDir,
      });
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('1'));
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('unresolvable'));
    } finally {
      warnSpy.mockRestore();
    }
  });
});

describe('scanNextJs', () => {
  it('returns ScannedSite with framework nextjs-app', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    expect(result.framework).toBe('nextjs-app');
  });

  it('discovers routes from app/ directory', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const paths = result.routes.map((r) => r.path).sort();
    expect(paths).toContain('/');
    expect(paths).toContain('/about');
    expect(paths).toContain('/projects');
    expect(paths).toContain('/projects/homelab');
    // dynamic route — either :slug or [slug] form
    const dynamicRoute = result.routes.find((r) => r.isDynamic);
    expect(dynamicRoute).toBeDefined();
    expect(dynamicRoute!.path).toMatch(/\/projects\/.+/);
  });

  it('maps page.tsx to correct route paths', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const about = result.routes.find((r) => r.path === '/about');
    expect(about).toBeDefined();
    expect(about!.componentFile).toBe('app/about/page.tsx');
  });

  it('detects dynamic route segments', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const dynamic = result.routes.find((r) => r.isDynamic);
    expect(dynamic).toBeDefined();
    expect(dynamic!.isDynamic).toBe(true);
    // path should use :slug notation
    expect(dynamic!.path).toBe('/projects/:slug');
  });

  it('extracts content from page files — home page should have title Welcome', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const home = result.routes.find((r) => r.path === '/');
    expect(home).toBeDefined();
    expect(home!.content.title).toBe('Welcome');
  });

  it('reads next/link <Link href> destinations (D2 / finding 6)', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const projects = result.routes.find((r) => r.path === '/projects');
    expect(projects).toBeDefined();
    const link = projects!.navigableElements.find((e) => e.text === 'Homelab Details');
    expect(link).toBeDefined();
    expect(link!.destination).toBe('/projects/homelab');
  });

  it('static routes are not marked dynamic', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const about = result.routes.find((r) => r.path === '/about');
    const projects = result.routes.find((r) => r.path === '/projects');
    expect(about).toBeDefined();
    expect(projects).toBeDefined();
    expect(about!.isDynamic).toBe(false);
    expect(projects!.isDynamic).toBe(false);
  });

  it('sets componentFile to the page.tsx path relative to projectRoot', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const home = result.routes.find((r) => r.path === '/');
    const homelab = result.routes.find((r) => r.path === '/projects/homelab');
    expect(home).toBeDefined();
    expect(homelab).toBeDefined();
    expect(home!.componentFile).toBe('app/page.tsx');
    expect(homelab!.componentFile).toBe('app/projects/homelab/page.tsx');
  });

  it('handles nested routes correctly — /projects/homelab has correct depth', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const homelab = result.routes.find((r) => r.path === '/projects/homelab');
    expect(homelab).toBeDefined();
    // depth = 2 segments: projects + homelab
    const segments = homelab!.path.split('/').filter(Boolean);
    expect(segments).toHaveLength(2);
    expect(segments[0]).toBe('projects');
    expect(segments[1]).toBe('homelab');
  });
});

describe('scanNextJs — layout.tsx attribution (finding 5)', () => {
  it('attributes the root layout\'s nav links to every route in the graph', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    for (const route of result.routes) {
      const homeLink = route.navigableElements.find((e) => e.text === 'Home' && e.destination === '/');
      const aboutLink = route.navigableElements.find(
        (e) => e.text === 'About' && e.destination === '/about',
      );
      expect(homeLink, `route ${route.path} missing root layout Home link`).toBeDefined();
      expect(aboutLink, `route ${route.path} missing root layout About link`).toBeDefined();
    }
  });

  it('does not let the root layout override a page\'s own title', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const home = result.routes.find((r) => r.path === '/');
    expect(home!.content.title).toBe('Welcome');
  });

  it('attributes a nested layout only to routes in its subtree', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const projects = result.routes.find((r) => r.path === '/projects');
    const homelab = result.routes.find((r) => r.path === '/projects/homelab');
    const about = result.routes.find((r) => r.path === '/about');

    expect(projects!.content.headings).toContain('Projects Section');
    expect(homelab!.content.headings).toContain('Projects Section');
    expect(about!.content.headings).not.toContain('Projects Section');
  });

  it('merges layout sections after the page\'s own sections (root layout, then nested)', async () => {
    const result = await scanNextJs({ appDir, projectRoot: fixtureDir });
    const homelab = result.routes.find((r) => r.path === '/projects/homelab');
    // page's own heading first, then nested layout's heading appended after
    const headingIndex = homelab!.content.headings.indexOf('Homelab Project');
    const layoutHeadingIndex = homelab!.content.headings.indexOf('Projects Section');
    expect(headingIndex).toBeGreaterThanOrEqual(0);
    expect(layoutHeadingIndex).toBeGreaterThan(headingIndex);
  });
});
