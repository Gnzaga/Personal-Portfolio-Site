import { fileURLToPath } from 'node:url';
import path from 'node:path';
import os from 'node:os';
import { describe, it, expect } from 'vitest';
import { resolveImport } from '../../src/scanner/import-resolver.js';
import { loadTsconfigPaths } from '../../src/scanner/tsconfig-paths.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixtureDir = path.resolve(__dirname, '../fixtures/react-router-app');
const appFile = path.join(fixtureDir, 'App.tsx');
const jsoncFixtureDir = path.resolve(__dirname, '../fixtures/jsonc-tsconfig-app');

describe('resolveImport', () => {
  it('resolves ./pages/Home from App.tsx to Home.tsx', () => {
    const result = resolveImport({
      specifier: './pages/Home',
      fromFile: appFile,
    });
    expect(result).toBe(path.join(fixtureDir, 'pages/Home.tsx'));
  });

  it('resolves ./pages/Projects from App.tsx to Projects.tsx', () => {
    const result = resolveImport({
      specifier: './pages/Projects',
      fromFile: appFile,
    });
    expect(result).toBe(path.join(fixtureDir, 'pages/Projects.tsx'));
  });

  it('resolves ./pages/projects/Homelab from App.tsx to Homelab.tsx', () => {
    const result = resolveImport({
      specifier: './pages/projects/Homelab',
      fromFile: appFile,
    });
    expect(result).toBe(path.join(fixtureDir, 'pages/projects/Homelab.tsx'));
  });

  it('returns null for ./pages/NonExistent', () => {
    const result = resolveImport({
      specifier: './pages/NonExistent',
      fromFile: appFile,
    });
    expect(result).toBeNull();
  });

  it('resolves @pages/Home alias to pages/Home.tsx', () => {
    const aliases: Record<string, string> = {
      '@pages/*': path.join(fixtureDir, 'pages/*'),
    };
    const result = resolveImport({
      specifier: '@pages/Home',
      fromFile: appFile,
      aliases,
    });
    expect(result).toBe(path.join(fixtureDir, 'pages/Home.tsx'));
  });

  it('resolves @/pages/Home alias to pages/Home.tsx', () => {
    const aliases: Record<string, string> = {
      '@/*': path.join(fixtureDir, '*'),
    };
    const result = resolveImport({
      specifier: '@/pages/Home',
      fromFile: appFile,
      aliases,
    });
    expect(result).toBe(path.join(fixtureDir, 'pages/Home.tsx'));
  });
});

describe('loadTsconfigPaths', () => {
  it('loads paths from fixture tsconfig.json', () => {
    const result = loadTsconfigPaths(fixtureDir);
    expect(result).toEqual({
      '@/*': path.join(fixtureDir, '*'),
      '@pages/*': path.join(fixtureDir, 'pages/*'),
    });
  });

  it('returns empty object when no tsconfig.json exists', () => {
    const tmpDir = os.tmpdir();
    const result = loadTsconfigPaths(tmpDir);
    expect(result).toEqual({});
  });

  it('tolerates line comments, block comments, and trailing commas (JSONC, finding 3)', () => {
    const result = loadTsconfigPaths(jsoncFixtureDir);
    expect(result).toEqual({
      '@/*': path.join(jsoncFixtureDir, '*'),
      '@pages/*': path.join(jsoncFixtureDir, 'pages/*'),
    });
  });
});
