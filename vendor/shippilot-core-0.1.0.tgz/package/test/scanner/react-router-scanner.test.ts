import { describe, it, expect, vi } from 'vitest';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { scanReactRouter } from '../../src/scanner/react-router-scanner.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixtureDir = path.resolve(__dirname, '../fixtures/react-router-app');
const aliasFixtureDir = path.resolve(__dirname, '../fixtures/react-router-alias-app');
const nestedFixtureDir = path.resolve(__dirname, '../fixtures/react-router-nested-app');
const dataRouterFixtureDir = path.resolve(__dirname, '../fixtures/react-router-data-app');
const routesFromElementsFixtureDir = path.resolve(
  __dirname,
  '../fixtures/react-router-routes-from-elements-app',
);
const crossFileFixtureDir = path.resolve(__dirname, '../fixtures/react-router-cross-file-app');
const dynamicLinkFixtureDir = path.resolve(__dirname, '../fixtures/react-router-dynamic-link-app');
const brokenPageFixtureDir = path.resolve(__dirname, '../fixtures/react-router-broken-page-app');

describe('scanReactRouter — one unparsable page does not abort the scan (finding 10)', () => {
  it('continues scanning other routes when one page file fails to parse', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      const result = await scanReactRouter({
        entryPoint: path.join(brokenPageFixtureDir, 'App.tsx'),
        projectRoot: brokenPageFixtureDir,
      });

      expect(result.routes).toHaveLength(2);

      const home = result.routes.find((r) => r.path === '/');
      expect(home!.content.title).toBe('Home');

      const broken = result.routes.find((r) => r.path === '/broken');
      expect(broken).toBeDefined();
      expect(broken!.content).toEqual({
        title: null,
        headings: [],
        textSnippets: [],
        metaDescription: null,
        sections: [],
      });
      expect(broken!.navigableElements).toEqual([]);

      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('Broken.tsx'), expect.anything());
    } finally {
      warnSpy.mockRestore();
    }
  });
});

describe('scanReactRouter — unresolvable link diagnostic (finding 7)', () => {
  it('warns with a count of links whose destination could not be resolved', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      await scanReactRouter({
        entryPoint: path.join(dynamicLinkFixtureDir, 'App.tsx'),
        projectRoot: dynamicLinkFixtureDir,
      });
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('1'));
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('unresolvable'));
    } finally {
      warnSpy.mockRestore();
    }
  });
});

describe('scanReactRouter — createBrowserRouter object-form routes (finding 1)', () => {
  it('discovers routes from an inline createBrowserRouter([...]) array', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(dataRouterFixtureDir, 'App.tsx'),
      projectRoot: dataRouterFixtureDir,
    });
    const paths = result.routes.map((r) => r.path).sort();
    expect(paths).toEqual(['/', '/about']);
  });

  it('resolves lazy-loaded element components for object-form routes', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(dataRouterFixtureDir, 'App.tsx'),
      projectRoot: dataRouterFixtureDir,
    });
    const home = result.routes.find((r) => r.path === '/');
    expect(home).toBeDefined();
    expect(home!.componentFile).toMatch(/pages[/\\]Home\.tsx$/);
    expect(home!.content.title).toBe('Data Router Home');
  });
});

describe('scanReactRouter — createRoutesFromElements + createBrowserRouter (finding 1)', () => {
  it('discovers the root layout, index, and nested "about" route', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(routesFromElementsFixtureDir, 'App.tsx'),
      projectRoot: routesFromElementsFixtureDir,
    });
    const paths = result.routes.map((r) => r.path).sort();
    expect(paths).toEqual(['/', '/', '/about'].sort());
  });

  it('index route inherits the root path and resolves to Home.tsx', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(routesFromElementsFixtureDir, 'App.tsx'),
      projectRoot: routesFromElementsFixtureDir,
    });
    const index = result.routes.find((r) => r.path === '/' && r.content.title === 'Home');
    expect(index).toBeDefined();
    expect(index!.componentFile).toMatch(/pages[/\\]Home\.tsx$/);
  });

  it('composes the nested "about" route onto the root path', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(routesFromElementsFixtureDir, 'App.tsx'),
      projectRoot: routesFromElementsFixtureDir,
    });
    const about = result.routes.find((r) => r.path === '/about');
    expect(about).toBeDefined();
    expect(about!.componentFile).toMatch(/pages[/\\]About\.tsx$/);
  });
});

describe('scanReactRouter — cross-file router definitions (finding 1)', () => {
  it('follows a router array imported from a separate routes.tsx module', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(crossFileFixtureDir, 'App.tsx'),
      projectRoot: crossFileFixtureDir,
    });
    const paths = result.routes.map((r) => r.path).sort();
    expect(paths).toEqual(['/', '/about']);
  });

  it('resolves lazy imports relative to routes.tsx, not App.tsx', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(crossFileFixtureDir, 'App.tsx'),
      projectRoot: crossFileFixtureDir,
    });
    const home = result.routes.find((r) => r.path === '/');
    expect(home).toBeDefined();
    expect(home!.componentFile).toMatch(/pages[/\\]Home\.tsx$/);
    expect(home!.content.title).toBe('Cross-File Home');
  });
});

describe('scanReactRouter — nested Route trees, index routes (finding 2)', () => {
  it('composes the nested child path from its ancestor ("/dashboard/settings")', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(nestedFixtureDir, 'App.tsx'),
      projectRoot: nestedFixtureDir,
    });
    const settings = result.routes.find(
      (r) => r.path === '/dashboard/settings',
    );
    expect(settings).toBeDefined();
    expect(settings!.componentFile).toMatch(/pages[/\\]DashboardSettings\.tsx$/);
    expect(settings!.content.title).toBe('Settings');
  });

  it('assigns the index route the parent\'s path instead of dropping it', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(nestedFixtureDir, 'App.tsx'),
      projectRoot: nestedFixtureDir,
    });
    const dashboardRoutes = result.routes.filter((r) => r.path === '/dashboard');
    // Both the layout (parent element) and the index route resolve to "/dashboard".
    expect(dashboardRoutes).toHaveLength(2);
    const index = dashboardRoutes.find((r) => r.content.title === 'Dashboard Home');
    expect(index).toBeDefined();
    expect(index!.componentFile).toMatch(/pages[/\\]DashboardHome\.tsx$/);
  });

  it('still captures the parent layout route itself at "/dashboard"', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(nestedFixtureDir, 'App.tsx'),
      projectRoot: nestedFixtureDir,
    });
    const layout = result.routes.find(
      (r) => r.path === '/dashboard' && r.content.title === 'Dashboard',
    );
    expect(layout).toBeDefined();
    expect(layout!.componentFile).toMatch(/pages[/\\]DashboardLayout\.tsx$/);
  });

  it('discovers exactly 3 routes total (layout + index + nested child)', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(nestedFixtureDir, 'App.tsx'),
      projectRoot: nestedFixtureDir,
    });
    expect(result.routes).toHaveLength(3);
  });
});

describe('scanReactRouter — tsconfig path aliases (finding 3)', () => {
  it('resolves a lazy-loaded route imported via a @/* tsconfig alias', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(aliasFixtureDir, 'App.tsx'),
      projectRoot: aliasFixtureDir,
    });
    const homeRoute = result.routes.find((r) => r.path === '/');
    expect(homeRoute).toBeDefined();
    expect(homeRoute!.componentFile).toMatch(/pages[/\\]Home\.tsx$/);
    expect(homeRoute!.content.title).toBe('Alias Home');
  });
});

describe('scanReactRouter', () => {
  it('returns ScannedSite with framework "react-router"', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    expect(result.framework).toBe('react-router');
  });

  it('discovers all 3 routes from App.tsx', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    const paths = result.routes.map((r) => r.path).sort();
    expect(paths).toEqual(['/', '/projects', '/projects/homelab'].sort());
  });

  it('resolves lazy import for Home to pages/Home.tsx', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    const homeRoute = result.routes.find((r) => r.path === '/');
    expect(homeRoute).toBeDefined();
    expect(homeRoute!.componentFile).toMatch(/pages[/\\]Home\.tsx$/);
  });

  it('extracts content from Home page', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    const homeRoute = result.routes.find((r) => r.path === '/');
    expect(homeRoute!.content.title).toBe('Welcome to My Site');
  });

  it('extracts navigable elements from Projects page', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    const projectsRoute = result.routes.find((r) => r.path === '/projects');
    expect(projectsRoute).toBeDefined();
    const destinations = projectsRoute!.navigableElements.map((e) => e.destination);
    expect(destinations).toContain('/projects/homelab');
  });

  it('marks no routes as isDynamic', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    for (const route of result.routes) {
      expect(route.isDynamic).toBe(false);
    }
  });

  it('detects data-agent-target attributes on Projects page', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    const projectsRoute = result.routes.find((r) => r.path === '/projects');
    expect(projectsRoute).toBeDefined();
    const withTarget = projectsRoute!.navigableElements.filter(
      (e) => e.suggestedTargetId !== '' && e.suggestedTargetId != null,
    );
    expect(withTarget.length).toBeGreaterThan(0);
    // Specifically, project-homelab-detail should be present
    const homelabLink = projectsRoute!.navigableElements.find(
      (e) => e.suggestedTargetId === 'project-homelab-detail',
    );
    expect(homelabLink).toBeDefined();
  });

  it('extracts content from detail page (Homelab)', async () => {
    const result = await scanReactRouter({
      entryPoint: path.join(fixtureDir, 'App.tsx'),
      projectRoot: fixtureDir,
    });
    const homelabRoute = result.routes.find((r) => r.path === '/projects/homelab');
    expect(homelabRoute).toBeDefined();
    expect(homelabRoute!.content.title).toBe('Homelab Infrastructure');
    expect(homelabRoute!.content.headings).toContain('Overview');
    expect(homelabRoute!.content.headings).toContain('Key Features');
  });
});
