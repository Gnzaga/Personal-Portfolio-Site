import fs from 'node:fs';
import path from 'node:path';

export interface ResolveOptions {
  specifier: string;
  fromFile: string;
  aliases?: Record<string, string>;
  extensions?: string[];
}

const DEFAULT_EXTENSIONS = ['.tsx', '.ts', '.jsx', '.js'];

/**
 * Apply alias substitution to a specifier.
 * Aliases use glob-style wildcards, e.g. '@pages/*' → '/abs/path/pages/*'.
 * Returns the transformed specifier, or the original if no alias matches.
 */
function applyAliases(specifier: string, aliases: Record<string, string>): string {
  for (const [alias, target] of Object.entries(aliases)) {
    if (alias.endsWith('/*')) {
      // Wildcard alias: '@pages/*' matches '@pages/Foo'
      const prefix = alias.slice(0, -2); // '@pages'
      if (specifier.startsWith(prefix + '/')) {
        const rest = specifier.slice(prefix.length + 1); // 'Foo'
        const resolvedTarget = target.endsWith('/*')
          ? target.slice(0, -2)
          : target;
        return path.join(resolvedTarget, rest);
      }
    } else {
      // Exact alias
      if (specifier === alias) {
        return target;
      }
    }
  }
  return specifier;
}

/**
 * Try to find a file by checking specifier as-is (if it has an extension),
 * then appending each extension, then trying index files.
 */
function tryResolve(candidate: string, extensions: string[]): string | null {
  // Try as-is (already has an extension)
  if (path.extname(candidate) !== '' && fs.existsSync(candidate)) {
    return candidate;
  }

  // Try appending each extension
  for (const ext of extensions) {
    const withExt = candidate + ext;
    if (fs.existsSync(withExt)) {
      return withExt;
    }
  }

  // Try candidate/index with each extension
  for (const ext of extensions) {
    const indexFile = path.join(candidate, 'index' + ext);
    if (fs.existsSync(indexFile)) {
      return indexFile;
    }
  }

  return null;
}

export function resolveImport(options: ResolveOptions): string | null {
  const { specifier, fromFile, aliases = {}, extensions = DEFAULT_EXTENSIONS } = options;

  // Step 1: Apply alias transformation
  const transformed = applyAliases(specifier, aliases);

  // Step 2: Determine the candidate absolute path
  let candidate: string;
  if (path.isAbsolute(transformed)) {
    // Already an absolute path (alias resolved to absolute)
    candidate = transformed;
  } else if (transformed.startsWith('.')) {
    // Relative import
    const fromDir = path.dirname(fromFile);
    candidate = path.resolve(fromDir, transformed);
  } else {
    // Non-relative, non-alias specifier (e.g. bare module) — not resolvable here
    return null;
  }

  return tryResolve(candidate, extensions);
}
