import fs from 'node:fs';
import path from 'node:path';
import * as babelParser from '@babel/parser';
import _traverse from '@babel/traverse';
import type { NodePath } from '@babel/traverse';
import * as t from '@babel/types';
import type { ScannedSite, ScannedRoute, ExtractedContent, NavigableElement } from '../types.js';
import { resolveImport } from './import-resolver.js';
import { extractContentFromFileRecursive } from './content-extractor.js';
import { loadTsconfigPaths } from './tsconfig-paths.js';

// @babel/parser: named export `parse` in ESM, but may also come as default.default in some environments
const parse: typeof babelParser.parse =
  (babelParser as any).parse ?? (babelParser as any).default?.parse;

// ESM/CJS compat shim for @babel/traverse
const traverse = (_traverse as any).default ?? _traverse;

export interface ScanReactRouterOptions {
  entryPoint: string;
  projectRoot: string;
}

function getStringProp(
  attributes: Array<t.JSXAttribute | t.JSXSpreadAttribute>,
  name: string,
): string | null {
  for (const attr of attributes) {
    if (!t.isJSXAttribute(attr)) continue;
    if (!t.isJSXIdentifier(attr.name, { name })) continue;
    if (t.isStringLiteral(attr.value)) return attr.value.value;
    if (t.isJSXExpressionContainer(attr.value) && t.isStringLiteral(attr.value.expression)) {
      return attr.value.expression.value;
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Route extraction from App.tsx (entry point)
// ---------------------------------------------------------------------------

interface RouteDescriptor {
  path: string;
  /** Component identifier from `element={<X/>}` — resolved via the lazy-import map or a relative-path fallback. */
  componentName: string | null;
  /** Import specifier read directly off a `lazy: () => import('./X')` route-object property. */
  lazySpecifier: string | null;
  /** Absolute path of the file this route was declared in (may differ from the entry point). */
  declaredInFile: string;
}

/** True for a JSX boolean attribute written with no value, e.g. `<Route index .../>`. */
function hasBooleanProp(
  attributes: Array<t.JSXAttribute | t.JSXSpreadAttribute>,
  name: string,
): boolean {
  return attributes.some(
    (attr) => t.isJSXAttribute(attr) && t.isJSXIdentifier(attr.name, { name }) && attr.value === null,
  );
}

/** Reads `element={<ComponentName ... />}` off a <Route> opening element. */
function getElementComponentName(
  attributes: Array<t.JSXAttribute | t.JSXSpreadAttribute>,
): string | null {
  for (const attr of attributes) {
    if (!t.isJSXAttribute(attr)) continue;
    if (!t.isJSXIdentifier(attr.name, { name: 'element' })) continue;
    if (!t.isJSXExpressionContainer(attr.value)) continue;
    const expr = attr.value.expression;
    if (t.isJSXElement(expr)) {
      const elOpening = expr.openingElement;
      if (t.isJSXIdentifier(elOpening.name)) return elOpening.name.name;
    }
  }
  return null;
}

/** Compose a child route segment onto its ancestor path (e.g. "/dashboard" + "settings" -> "/dashboard/settings"). */
function joinRoutePath(parentPath: string, segment: string | null): string {
  if (!segment) return parentPath || '/';
  const cleanParent = parentPath === '/' ? '' : parentPath;
  const cleanSegment = segment.startsWith('/') ? segment.slice(1) : segment;
  return `${cleanParent}/${cleanSegment}`;
}

/**
 * Recursively walk a <Route> element and its nested <Route> children,
 * composing ancestor paths. An `index` route inherits its parent's path
 * instead of being dropped.
 */
function walkRouteElement(
  routeEl: t.JSXElement,
  parentPath: string,
  currentFile: string,
  routes: RouteDescriptor[],
): void {
  const opening = routeEl.openingElement;
  const rawPath = getStringProp(opening.attributes, 'path');
  const isIndex = hasBooleanProp(opening.attributes, 'index');
  const composedPath = isIndex ? parentPath || '/' : joinRoutePath(parentPath, rawPath);

  const componentName = getElementComponentName(opening.attributes);
  if (componentName && (rawPath || isIndex)) {
    routes.push({ path: composedPath, componentName, lazySpecifier: null, declaredInFile: currentFile });
  }

  for (const child of routeEl.children) {
    if (!t.isJSXElement(child)) continue;
    if (t.isJSXIdentifier(child.openingElement.name, { name: 'Route' })) {
      walkRouteElement(child, composedPath, currentFile, routes);
    }
  }
}

/** Walk the direct <Route> children of a <Routes> or <Fragment> JSX container. */
function walkRouteChildren(
  children: t.JSXElement['children'],
  parentPath: string,
  currentFile: string,
  routes: RouteDescriptor[],
): void {
  for (const child of children) {
    if (!t.isJSXElement(child)) continue;
    if (t.isJSXIdentifier(child.openingElement.name, { name: 'Route' })) {
      walkRouteElement(child, parentPath, currentFile, routes);
    }
  }
}

/** JSX `<Routes>...</Routes>` form (react-router v6 declarative routing). */
function extractRoutesFromJsxTree(ast: t.File, currentFile: string): RouteDescriptor[] {
  const routes: RouteDescriptor[] = [];

  traverse(ast, {
    JSXElement(nodePath: NodePath<t.JSXElement>) {
      const opening = nodePath.node.openingElement;
      if (!t.isJSXIdentifier(opening.name, { name: 'Routes' })) return;
      walkRouteChildren(nodePath.node.children, '', currentFile, routes);
    },
  });

  return routes;
}

// ---------------------------------------------------------------------------
// Lazy import map extraction
// ---------------------------------------------------------------------------

/** Reads the `import('specifier')` call out of `() => import('./X')` / `function () { return import('./X'); }`. */
function extractImportSpecifierFromFn(
  fn: t.ArrowFunctionExpression | t.FunctionExpression,
): string | null {
  let importCall: t.CallExpression | null = null;

  if (t.isCallExpression(fn.body)) {
    importCall = fn.body;
  } else if (t.isBlockStatement(fn.body)) {
    for (const stmt of fn.body.body) {
      if (t.isReturnStatement(stmt) && stmt.argument && t.isCallExpression(stmt.argument)) {
        importCall = stmt.argument;
        break;
      }
    }
  }

  if (!importCall || !t.isImport(importCall.callee)) return null;

  const specArg = importCall.arguments[0];
  if (!t.isStringLiteral(specArg)) return null;

  return specArg.value;
}

function extractLazyImports(ast: t.File): Map<string, string> {
  const lazyMap = new Map<string, string>();

  traverse(ast, {
    VariableDeclaration(nodePath: NodePath<t.VariableDeclaration>) {
      for (const decl of nodePath.node.declarations) {
        if (!t.isIdentifier(decl.id)) continue;
        const varName = decl.id.name;

        // Match: lazy(() => import('...'))  or  React.lazy(() => import('...'))
        if (!decl.init || !t.isCallExpression(decl.init)) continue;
        const callExpr = decl.init;

        const callee = callExpr.callee;
        const isLazy =
          (t.isIdentifier(callee) && callee.name === 'lazy') ||
          (t.isMemberExpression(callee) &&
            t.isIdentifier(callee.object) &&
            callee.object.name === 'React' &&
            t.isIdentifier(callee.property) &&
            callee.property.name === 'lazy');

        if (!isLazy) continue;

        const arg = callExpr.arguments[0];
        if (!t.isArrowFunctionExpression(arg) && !t.isFunctionExpression(arg)) continue;

        const specifier = extractImportSpecifierFromFn(arg);
        if (!specifier) continue;

        lazyMap.set(varName, specifier);
      }
    },
  });

  return lazyMap;
}

// ---------------------------------------------------------------------------
// Object/data-router form: createBrowserRouter([...]), createRoutesFromElements(...),
// and cross-file router definitions (finding 1)
// ---------------------------------------------------------------------------

/** Walk one route object literal from a createBrowserRouter([...]) array, recursing into `children`. */
function walkRouteObject(
  objExpr: t.ObjectExpression,
  parentPath: string,
  currentFile: string,
  routes: RouteDescriptor[],
): void {
  let rawPath: string | null = null;
  let isIndex = false;
  let componentName: string | null = null;
  let lazySpecifier: string | null = null;
  let childrenExpr: t.ArrayExpression | null = null;

  for (const prop of objExpr.properties) {
    if (!t.isObjectProperty(prop)) continue;
    const key = t.isIdentifier(prop.key)
      ? prop.key.name
      : t.isStringLiteral(prop.key)
      ? prop.key.value
      : null;
    if (!key) continue;

    if (key === 'path' && t.isStringLiteral(prop.value)) {
      rawPath = prop.value.value;
    } else if (key === 'index') {
      isIndex = t.isBooleanLiteral(prop.value) ? prop.value.value : true;
    } else if (key === 'element' && t.isJSXElement(prop.value)) {
      const elOpening = prop.value.openingElement;
      if (t.isJSXIdentifier(elOpening.name)) componentName = elOpening.name.name;
    } else if (key === 'children' && t.isArrayExpression(prop.value)) {
      childrenExpr = prop.value;
    } else if (key === 'lazy' && (t.isArrowFunctionExpression(prop.value) || t.isFunctionExpression(prop.value))) {
      lazySpecifier = extractImportSpecifierFromFn(prop.value);
    }
  }

  const composedPath = isIndex ? parentPath || '/' : joinRoutePath(parentPath, rawPath);

  if ((componentName || lazySpecifier) && (rawPath || isIndex)) {
    routes.push({ path: composedPath, componentName, lazySpecifier, declaredInFile: currentFile });
  }

  if (childrenExpr) {
    for (const element of childrenExpr.elements) {
      if (element && t.isObjectExpression(element)) {
        walkRouteObject(element, composedPath, currentFile, routes);
      }
    }
  }
}

/** Finds `createBrowserRouter(<arg>)` anywhere in the file and returns its first argument. */
function findCreateBrowserRouterArg(ast: t.File): t.Expression | null {
  let found: t.Expression | null = null;

  traverse(ast, {
    CallExpression(nodePath: NodePath<t.CallExpression>) {
      if (found) return;
      if (!t.isIdentifier(nodePath.node.callee, { name: 'createBrowserRouter' })) return;
      const arg = nodePath.node.arguments[0];
      if (arg && t.isExpression(arg)) found = arg;
    },
  });

  return found;
}

/** Finds a top-level `const <name> = <init>` (or `let`/`var`) anywhere in the file. */
function findLocalVariableInit(ast: t.File, name: string): t.Expression | null {
  let found: t.Expression | null = null;

  traverse(ast, {
    VariableDeclarator(nodePath: NodePath<t.VariableDeclarator>) {
      if (found) return;
      if (t.isIdentifier(nodePath.node.id, { name }) && nodePath.node.init) {
        found = nodePath.node.init;
      }
    },
  });

  return found;
}

/** Finds the relative-import source for a local binding name, e.g. `import { routes } from './routes'`. */
function findImportSource(
  ast: t.File,
  name: string,
): { specifier: string; isDefault: boolean } | null {
  let result: { specifier: string; isDefault: boolean } | null = null;

  traverse(ast, {
    ImportDeclaration(nodePath: NodePath<t.ImportDeclaration>) {
      if (result) return;
      const source = nodePath.node.source.value;
      if (!source.startsWith('.')) return; // skip bare/package specifiers

      for (const specifier of nodePath.node.specifiers) {
        if (t.isImportDefaultSpecifier(specifier) && specifier.local.name === name) {
          result = { specifier: source, isDefault: true };
        } else if (t.isImportSpecifier(specifier) && specifier.local.name === name) {
          result = { specifier: source, isDefault: false };
        }
      }
    },
  });

  return result;
}

/** Finds `export default <expr>`, chasing a bare identifier back to its local declaration. */
function findDefaultExportInit(ast: t.File): t.Expression | null {
  let found: t.Expression | null = null;

  traverse(ast, {
    ExportDefaultDeclaration(nodePath: NodePath<t.ExportDefaultDeclaration>) {
      const decl = nodePath.node.declaration;
      if (!t.isExpression(decl)) return;
      found = t.isIdentifier(decl) ? findLocalVariableInit(ast, decl.name) ?? decl : decl;
    },
  });

  return found;
}

/**
 * Resolve a route-definition expression to route descriptors, handling:
 *  - an inline array of route objects (`createBrowserRouter([...])`)
 *  - `createRoutesFromElements(<Route>...</Route>)` (single element or a fragment of siblings)
 *  - a bare identifier pointing at a local `const` in the same file
 *  - a bare identifier imported from another (relative) file — followed across files
 */
function resolveRouteSource(
  expr: t.Node,
  ast: t.File,
  currentFile: string,
  aliases: Record<string, string>,
  routes: RouteDescriptor[],
  visitedFiles: Set<string>,
): void {
  if (t.isArrayExpression(expr)) {
    for (const element of expr.elements) {
      if (element && t.isObjectExpression(element)) {
        walkRouteObject(element, '', currentFile, routes);
      }
    }
    return;
  }

  if (t.isCallExpression(expr) && t.isIdentifier(expr.callee, { name: 'createRoutesFromElements' })) {
    const jsxArg = expr.arguments[0];
    if (jsxArg && t.isJSXElement(jsxArg)) {
      walkRouteChildren([jsxArg], '', currentFile, routes);
    } else if (jsxArg && t.isJSXFragment(jsxArg)) {
      walkRouteChildren(jsxArg.children, '', currentFile, routes);
    }
    return;
  }

  if (t.isIdentifier(expr)) {
    const name = expr.name;

    const localInit = findLocalVariableInit(ast, name);
    if (localInit) {
      resolveRouteSource(localInit, ast, currentFile, aliases, routes, visitedFiles);
      return;
    }

    const importSource = findImportSource(ast, name);
    if (!importSource) return;

    const resolvedFile = resolveImport({ specifier: importSource.specifier, fromFile: currentFile, aliases });
    if (!resolvedFile || !fs.existsSync(resolvedFile) || visitedFiles.has(resolvedFile)) return;
    visitedFiles.add(resolvedFile);

    const childSource = fs.readFileSync(resolvedFile, 'utf8');
    const childAst = parse(childSource, { plugins: ['jsx', 'typescript'], sourceType: 'module' }) as t.File;

    const exportedInit = importSource.isDefault
      ? findDefaultExportInit(childAst)
      : findLocalVariableInit(childAst, name);
    if (!exportedInit) return;

    resolveRouteSource(exportedInit, childAst, resolvedFile, aliases, routes, visitedFiles);
  }
}

/**
 * Top-level route discovery for an entry point: tries the JSX `<Routes>` form
 * first (react-router v6 declarative routing); falls back to the object/data-router
 * form (`createBrowserRouter`/`createRoutesFromElements`, possibly cross-file).
 */
function extractRouteDescriptors(entryPoint: string, aliases: Record<string, string>): RouteDescriptor[] {
  const source = fs.readFileSync(entryPoint, 'utf8');
  const ast = parse(source, { plugins: ['jsx', 'typescript'], sourceType: 'module' }) as t.File;

  const jsxRoutes = extractRoutesFromJsxTree(ast, entryPoint);
  if (jsxRoutes.length > 0) return jsxRoutes;

  const routerArg = findCreateBrowserRouterArg(ast);
  if (!routerArg) return [];

  const routes: RouteDescriptor[] = [];
  resolveRouteSource(routerArg, ast, entryPoint, aliases, routes, new Set([path.resolve(entryPoint)]));
  return routes;
}

// ---------------------------------------------------------------------------
// Main scanner
// ---------------------------------------------------------------------------

export async function scanReactRouter(options: ScanReactRouterOptions): Promise<ScannedSite> {
  const { entryPoint, projectRoot } = options;

  const aliases = loadTsconfigPaths(projectRoot);
  const routeDescriptors = extractRouteDescriptors(entryPoint, aliases);

  // Lazy-import maps are per-file: a route's `element={<X/>}` may be declared
  // in a routes module that isn't the entry point (finding 1, cross-file routers).
  const lazyMapByFile = new Map<string, Map<string, string>>();
  function lazyMapFor(file: string): Map<string, string> {
    let map = lazyMapByFile.get(file);
    if (!map) {
      const fileAst = parse(fs.readFileSync(file, 'utf8'), {
        plugins: ['jsx', 'typescript'],
        sourceType: 'module',
      }) as t.File;
      map = extractLazyImports(fileAst);
      lazyMapByFile.set(file, map);
    }
    return map;
  }

  const routes: ScannedRoute[] = [];
  let unresolvableLinkCount = 0;

  for (const descriptor of routeDescriptors) {
    let componentFilePath: string | null = null;

    if (descriptor.lazySpecifier) {
      componentFilePath = resolveImport({
        specifier: descriptor.lazySpecifier,
        fromFile: descriptor.declaredInFile,
        aliases,
      });
    } else if (descriptor.componentName) {
      const specifier = lazyMapFor(descriptor.declaredInFile).get(descriptor.componentName);

      if (specifier) {
        componentFilePath = resolveImport({
          specifier,
          fromFile: descriptor.declaredInFile,
          aliases,
        });
      }

      if (!componentFilePath) {
        // Fallback: try the component name as a relative path
        componentFilePath = resolveImport({
          specifier: `./${descriptor.componentName}`,
          fromFile: descriptor.declaredInFile,
          aliases,
        });
      }
    }

    // Relative componentFile path from projectRoot
    const componentFile = componentFilePath
      ? path.relative(projectRoot, componentFilePath)
      : descriptor.componentName ?? descriptor.path;

    // Extract content from the resolved file
    let content: ExtractedContent = {
      title: null,
      headings: [],
      textSnippets: [],
      metaDescription: null,
      sections: [],
    };
    let navigableElements: NavigableElement[] = [];

    if (componentFilePath && fs.existsSync(componentFilePath)) {
      try {
        const extracted = extractContentFromFileRecursive(componentFilePath, { aliases });
        content = extracted.content;
        navigableElements = extracted.navigableElements;
        unresolvableLinkCount += extracted.unresolvableLinkCount;
      } catch (error) {
        // One unparsable page must not abort the whole scan (finding 10) —
        // warn and continue with empty content for this route.
        console.warn(
          `[shippilot] failed to parse ${componentFilePath}, continuing with empty content:`,
          error,
        );
      }
    }

    const isDynamic = /[:*]/.test(descriptor.path);

    routes.push({
      path: descriptor.path,
      componentFile,
      content,
      navigableElements,
      isDynamic,
    });
  }

  if (unresolvableLinkCount > 0) {
    console.warn(
      `[shippilot] scan found ${unresolvableLinkCount} link(s) with unresolvable destinations ` +
        `(dynamic expressions with no static prefix — no route edge can be inferred for these).`,
    );
  }

  return { routes, framework: 'react-router' };
}
