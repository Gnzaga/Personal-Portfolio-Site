import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { parse } from '@babel/parser';
import _traverse from '@babel/traverse';
import type { NodePath } from '@babel/traverse';
import * as t from '@babel/types';
import type { ContentSection, ExtractedContent, NavigableElement } from '../types.js';
import { toSlug } from '../graph/target-id-generator.js';
import { resolveImport } from './import-resolver.js';

// @babel/traverse ships a CommonJS default export; handle both ESM and CJS interop
const traverse = ((_traverse as any).default ?? _traverse) as typeof _traverse;

export interface ContentExtractionResult {
  content: ExtractedContent;
  navigableElements: NavigableElement[];
  /**
   * Count of link-like elements whose destination attribute was present but
   * fully dynamic — not even a static template-literal prefix could be
   * recovered (finding 7). Scanners aggregate this across routes and warn.
   */
  unresolvableLinkCount: number;
}

// ─── Heading tags we recognise ────────────────────────────────────────────────

const HEADING_TAGS = new Set(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']);
const TEXT_TAGS = new Set([
  'p',
  'span',
  'li',
  'code',
  'pre',
  'td',
  'th',
  'blockquote',
  'figcaption',
  'dd',
  'dt',
]);
const LINK_COMPONENT_NAMES = new Set(['Link', 'NavLink']);

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Return true for external URLs that we should skip. */
function isExternal(url: string): boolean {
  return url.startsWith('http://') || url.startsWith('https://');
}

const NAV_CALLEE_IDENTIFIERS = new Set(['navigate']);
const NAV_CALLEE_MEMBER_METHODS = new Set(['push']); // router.push(...) / history.push(...)

/**
 * Given the NodePath of an onClick handler's expression (e.g. the arrow
 * function passed to onClick={...}), finds the first navigate('/x') or
 * router.push('/x') / history.push('/x') call with a single
 * string-literal argument and returns the destination, or null.
 */
function findNavigationCallDestination(exprPath: NodePath): string | null {
  let destination: string | null = null;

  exprPath.traverse({
    CallExpression(callPath: NodePath<t.CallExpression>) {
      if (destination) return; // first match wins
      const { callee, arguments: args } = callPath.node;
      if (args.length !== 1 || !t.isStringLiteral(args[0])) return;

      if (t.isIdentifier(callee) && NAV_CALLEE_IDENTIFIERS.has(callee.name)) {
        destination = args[0].value;
        return;
      }

      if (
        t.isMemberExpression(callee) &&
        t.isIdentifier(callee.property) &&
        NAV_CALLEE_MEMBER_METHODS.has(callee.property.name)
      ) {
        destination = args[0].value;
      }
    },
  });

  return destination;
}

/**
 * Extract static text from a JSX element's children.
 * Handles JSXText nodes and StringLiteral children.
 * Returns empty string for fully dynamic content.
 *
 * `consumed` tracks nested heading/text-tag elements whose text has already
 * been folded into an ancestor's text here, so the top-level traversal in
 * `extractFromAst` can skip pushing a second, duplicate section/snippet for
 * that same nested element (finding 13 regression guard — e.g. <pre><code>).
 * Callers extracting a one-off label (e.g. a Link's visible text) can omit
 * it; a throwaway set is used and nothing outside this call observes it.
 */
function extractChildText(
  jsxElement: t.JSXElement,
  consumed: Set<t.JSXElement> = new Set(),
): string {
  const parts: string[] = [];

  for (const child of jsxElement.children) {
    if (t.isJSXText(child)) {
      const trimmed = child.value.trim();
      if (trimmed) parts.push(trimmed);
    } else if (t.isJSXExpressionContainer(child)) {
      if (t.isStringLiteral(child.expression)) {
        parts.push(child.expression.value.trim());
      }
      // skip other expressions (variables, etc.)
    } else if (t.isJSXElement(child)) {
      const childName = child.openingElement.name;
      const childTag = t.isJSXIdentifier(childName) ? childName.name : null;
      if (childTag && (HEADING_TAGS.has(childTag) || TEXT_TAGS.has(childTag))) {
        consumed.add(child);
      }

      // recurse into nested elements for text content
      const nested = extractChildText(child, consumed);
      if (nested) parts.push(nested);
    }
  }

  return parts.join(' ').trim();
}

/**
 * Append text to the section grouping. Starts a new preamble (heading: null)
 * section if none exists yet, otherwise appends to the last section.
 */
function appendSectionText(sections: ContentSection[], text: string): void {
  if (!text) return;
  const last = sections[sections.length - 1];
  if (last) {
    last.text.push(text);
  } else {
    sections.push({ heading: null, text: [text] });
  }
}

/**
 * Derive the flat `headings`/`textSnippets` fields from ordered sections.
 * Kept in sync with `sections` so both representations always agree.
 * Exported so callers that merge sections from multiple sources (e.g. Next.js
 * layout + page content, finding 5) can re-derive the flat fields afterwards.
 */
export function deriveFlatFields(sections: ContentSection[]): { headings: string[]; textSnippets: string[] } {
  const headings: string[] = [];
  const textSnippets: string[] = [];
  for (const section of sections) {
    if (section.heading !== null) headings.push(section.heading);
    textSnippets.push(...section.text);
  }
  return { headings, textSnippets };
}

/**
 * Get the string value of a JSX attribute.
 * Returns null when the attribute is dynamic or not a simple string.
 */
function getStringAttr(
  attrs: Array<t.JSXAttribute | t.JSXSpreadAttribute>,
  name: string,
): string | null {
  for (const attr of attrs) {
    if (!t.isJSXAttribute(attr)) continue;
    if (!t.isJSXIdentifier(attr.name, { name })) continue;

    if (t.isStringLiteral(attr.value)) {
      return attr.value.value;
    }

    if (
      t.isJSXExpressionContainer(attr.value) &&
      t.isStringLiteral(attr.value.expression)
    ) {
      return attr.value.expression.value;
    }
  }
  return null;
}

/** Result of resolving a link-like element's destination attribute. */
interface DestinationResult {
  /** Static value (or static template-literal prefix), or null if unresolvable/absent. */
  value: string | null;
  /** True when `value` is only a prefix of a dynamic template literal. */
  pattern: boolean;
  /** True when the attribute was present but no static value could be recovered at all. */
  unresolvable: boolean;
}

const NOT_PRESENT: DestinationResult = { value: null, pattern: false, unresolvable: false };

/**
 * Resolve a link destination attribute (`to`/`href`), tolerating template
 * literals with a static leading prefix (finding 7), e.g.:
 *   `/projects/${slug}` -> { value: '/projects/', pattern: true, unresolvable: false }
 * A fully dynamic expression (bare variable, ternary, etc.) is reported as
 * unresolvable so callers can count/warn about it.
 */
function getDestinationAttr(
  attrs: Array<t.JSXAttribute | t.JSXSpreadAttribute>,
  name: string,
): DestinationResult {
  for (const attr of attrs) {
    if (!t.isJSXAttribute(attr)) continue;
    if (!t.isJSXIdentifier(attr.name, { name })) continue;

    if (t.isStringLiteral(attr.value)) {
      return { value: attr.value.value, pattern: false, unresolvable: false };
    }

    if (t.isJSXExpressionContainer(attr.value)) {
      const expr = attr.value.expression;

      if (t.isStringLiteral(expr)) {
        return { value: expr.value, pattern: false, unresolvable: false };
      }

      if (t.isTemplateLiteral(expr) && expr.expressions.length > 0) {
        const prefix = expr.quasis[0]?.value.cooked ?? '';
        if (prefix) return { value: prefix, pattern: true, unresolvable: false };
        return { value: null, pattern: false, unresolvable: true };
      }

      // Any other dynamic expression (identifier, ternary, call, ...) — unresolvable.
      return { value: null, pattern: false, unresolvable: true };
    }
  }

  return NOT_PRESENT; // attribute not present at all — not an error
}

// ─── MDX / Markdown pages (finding 12) ─────────────────────────────────────────
//
// MDX can embed JSX, but a regex-based heading/paragraph extraction is enough
// to make these pages visible at all (today they're invisible to the scanner).
// No navigable-element or import-following support for MDX in this pass.

const MARKDOWN_FILE_RE = /\.mdx?$/i;

/** True for .md/.mdx files, which use a regex-based extraction path instead of the Babel/JSX parser. */
function isMarkdownFile(filePath: string): boolean {
  return MARKDOWN_FILE_RE.test(filePath);
}

/**
 * Extract headings and paragraphs from Markdown/MDX source via a simple,
 * blank-line-delimited block scan. Skips a leading YAML frontmatter block,
 * MDX `import`/`export` lines, and horizontal rules.
 */
function extractMarkdownContent(source: string): ContentExtractionResult {
  let body = source;
  const frontmatter = body.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/);
  if (frontmatter) body = body.slice(frontmatter[0].length);

  const sections: ContentSection[] = [];

  for (const rawBlock of body.split(/\r?\n\s*\r?\n/)) {
    const block = rawBlock.trim();
    if (!block) continue;
    if (/^(?:import|export)\s/.test(block)) continue; // MDX component imports/exports
    if (/^(?:---|\*\*\*|___)$/.test(block)) continue; // horizontal rule

    const headingMatch = block.match(/^#{1,6}\s+(.+)$/);
    if (headingMatch) {
      const heading = headingMatch[1]!.trim();
      if (heading) sections.push({ heading, text: [] });
      continue;
    }

    // Join soft-wrapped lines within the block into one paragraph.
    const text = block
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .join(' ');
    appendSectionText(sections, text);
  }

  const { headings, textSnippets } = deriveFlatFields(sections);

  return {
    content: {
      title: headings[0] ?? null,
      headings,
      textSnippets,
      metaDescription: null,
      sections,
    },
    navigableElements: [],
    unresolvableLinkCount: 0,
  };
}

// ─── Core implementation ──────────────────────────────────────────────────────

function parseModule(source: string): t.File {
  return parse(source, {
    sourceType: 'module',
    plugins: ['jsx', 'typescript'],
  });
}

/** Walk an already-parsed AST and extract this file's own content and links. */
function extractFromAst(ast: t.File): ContentExtractionResult {
  const sections: ContentSection[] = [];
  const navigableElements: NavigableElement[] = [];
  const dataAgentTargets: string[] = [];
  const seenDataAgentTargets = new Set<string>();
  let unresolvableLinkCount = 0;
  // From <Helmet>/<Head> <title>, or a Next.js `export const metadata` object.
  // Only ever used as a fallback for `content.title` when no h1/h2 is found.
  let metaTitle: string | null = null;
  let metaDescription: string | null = null;
  // Nested heading/text-tag elements already folded into an ancestor's text
  // by extractChildText — the traversal below skips these to avoid pushing a
  // duplicate section (finding 13 regression guard, e.g. <pre><code>...).
  const consumedByAncestor = new Set<t.JSXElement>();

  traverse(ast, {
    JSXElement(path: NodePath<t.JSXElement>) {
      const openingEl = path.node.openingElement;
      const nameNode = openingEl.name;
      const attrs = openingEl.attributes;

      // Record every literal data-agent-target attribute value, on any
      // element (not just links/anchors) — used by the graph builder to
      // verify synthesized navbar/card/detail IDs against what's really
      // present in the page's JSX.
      const rawAgentTarget = getStringAttr(attrs, 'data-agent-target');
      if (rawAgentTarget && !seenDataAgentTargets.has(rawAgentTarget)) {
        seenDataAgentTargets.add(rawAgentTarget);
        dataAgentTargets.push(rawAgentTarget);
      }

      // ── Programmatic navigation: onClick={() => navigate('/x')} /
      // onClick={() => router.push('/x')} — captured regardless of tag
      // name, since these show up on <button>, <div>, <li>, etc.
      const attrPaths = path.get('openingElement').get('attributes');
      const onClickAttrPath = attrPaths.find(
        (p): p is NodePath<t.JSXAttribute> =>
          p.isJSXAttribute() && t.isJSXIdentifier(p.node.name, { name: 'onClick' }),
      );

      if (onClickAttrPath) {
        const valueNode = onClickAttrPath.node.value;
        if (t.isJSXExpressionContainer(valueNode) && !t.isJSXEmptyExpression(valueNode.expression)) {
          const valuePath = onClickAttrPath.get('value');
          if (!Array.isArray(valuePath) && valuePath.isJSXExpressionContainer()) {
            const exprPath = valuePath.get('expression');
            if (!Array.isArray(exprPath)) {
              const destination = findNavigationCallDestination(exprPath);
              if (destination && !isExternal(destination)) {
                const text = extractChildText(path.node);
                const suggestedTargetId =
                  rawAgentTarget ?? (text ? toSlug(text) : toSlug(destination));
                const selector = `[data-agent-target="${suggestedTargetId}"]`;

                navigableElements.push({
                  type: 'button',
                  text,
                  destination,
                  suggestedTargetId,
                  selector,
                });
              }
            }
          }
        }
      }

      // Determine element name string
      let tagName: string | null = null;
      if (t.isJSXIdentifier(nameNode)) {
        tagName = nameNode.name;
      } else if (t.isJSXMemberExpression(nameNode)) {
        // e.g. React.Fragment — skip
        return;
      }

      if (!tagName) return;

      // ── Headings ────────────────────────────────────────────────────────────
      if (HEADING_TAGS.has(tagName)) {
        if (consumedByAncestor.has(path.node)) return;
        const text = extractChildText(path.node, consumedByAncestor);
        if (text) sections.push({ heading: text, text: [] });
        return;
      }

      // ── Text snippets ────────────────────────────────────────────────────────
      if (TEXT_TAGS.has(tagName)) {
        if (consumedByAncestor.has(path.node)) return;
        const text = extractChildText(path.node, consumedByAncestor);
        appendSectionText(sections, text);
        return;
      }

      // ── <title> inside <Helmet>/<Head> ───────────────────────────────────────
      if (tagName === 'title') {
        if (metaTitle === null) {
          const text = extractChildText(path.node);
          if (text) metaTitle = text;
        }
        return;
      }

      // ── <meta name="description"> inside <Helmet>/<Head> ─────────────────────
      if (tagName === 'meta') {
        if (metaDescription === null && getStringAttr(attrs, 'name') === 'description') {
          metaDescription = getStringAttr(attrs, 'content');
        }
        return;
      }

      // ── Link / NavLink (react-router `to`, next/link `href`) ─────────────────
      if (LINK_COMPONENT_NAMES.has(tagName)) {
        let dest = getDestinationAttr(attrs, 'to');
        if (dest.value === null && !dest.unresolvable) {
          dest = getDestinationAttr(attrs, 'href');
        }

        // Skip external links (next/link can point at absolute URLs too)
        if (dest.value && isExternal(dest.value)) return;
        if (dest.unresolvable) unresolvableLinkCount++;

        const destination = dest.value;
        const agentTarget = getStringAttr(attrs, 'data-agent-target');
        const text = extractChildText(path.node);

        const type: NavigableElement['type'] =
          tagName === 'NavLink' ? 'navlink' : 'link';

        const suggestedTargetId =
          agentTarget ?? (text ? toSlug(text) : toSlug(destination ?? 'link'));

        const selector = agentTarget
          ? `[data-agent-target="${agentTarget}"]`
          : destination
          ? `a[href="${destination}"]`
          : `a`;

        navigableElements.push({
          type,
          text,
          destination,
          suggestedTargetId,
          selector,
          pattern: dest.pattern,
        });

        return;
      }

      // ── Native <a> anchors ───────────────────────────────────────────────────
      if (tagName === 'a') {
        const dest = getDestinationAttr(attrs, 'href');

        // Skip external links
        if (dest.value && isExternal(dest.value)) return;
        if (dest.unresolvable) unresolvableLinkCount++;

        const href = dest.value;
        const agentTarget = getStringAttr(attrs, 'data-agent-target');
        const text = extractChildText(path.node);

        const suggestedTargetId =
          agentTarget ?? (text ? toSlug(text) : toSlug(href ?? 'link'));

        const selector = agentTarget
          ? `[data-agent-target="${agentTarget}"]`
          : href
          ? `a[href="${href}"]`
          : `a`;

        navigableElements.push({
          type: 'anchor',
          text,
          destination: href,
          suggestedTargetId,
          selector,
          pattern: dest.pattern,
        });

        return;
      }

      // Other elements — nothing to do (data-agent-target on divs is just ignored)
    },

    // ── Next.js `export const metadata = { title, description }` ──────────────
    ExportNamedDeclaration(exportPath: NodePath<t.ExportNamedDeclaration>) {
      const decl = exportPath.node.declaration;
      if (!decl || !t.isVariableDeclaration(decl)) return;

      for (const declarator of decl.declarations) {
        if (!t.isIdentifier(declarator.id, { name: 'metadata' })) continue;
        if (!declarator.init || !t.isObjectExpression(declarator.init)) continue;

        for (const prop of declarator.init.properties) {
          if (!t.isObjectProperty(prop)) continue;
          const key = t.isIdentifier(prop.key) ? prop.key.name : null;

          if (key === 'title' && metaTitle === null && t.isStringLiteral(prop.value)) {
            metaTitle = prop.value.value;
          }
          if (key === 'description' && metaDescription === null && t.isStringLiteral(prop.value)) {
            metaDescription = prop.value.value;
          }
        }
      }
    },
  });

  const { headings, textSnippets } = deriveFlatFields(sections);
  const title = headings[0] ?? metaTitle ?? null;

  return {
    content: {
      title,
      headings,
      textSnippets,
      metaDescription,
      sections,
      dataAgentTargets,
    },
    navigableElements,
    unresolvableLinkCount,
  };
}

export function extractContentFromSource(
  source: string,
  _filePath?: string,
): ContentExtractionResult {
  return extractFromAst(parseModule(source));
}

export function extractContentFromFile(filePath: string): ContentExtractionResult {
  const source = readFileSync(filePath, 'utf-8');
  if (isMarkdownFile(filePath)) return extractMarkdownContent(source);
  return extractContentFromSource(source, filePath);
}

// ─── Recursive, import-following extraction (finding 4) ───────────────────────

/**
 * Local (relative-path) component imports in a file, keyed by the imported
 * local identifier. Bare/package specifiers (e.g. 'react-router-dom') are
 * excluded — only imports that could plausibly be a local page/component
 * file are candidates for recursion.
 */
function collectLocalComponentImports(ast: t.File): Map<string, string> {
  const imports = new Map<string, string>();

  traverse(ast, {
    ImportDeclaration(nodePath: NodePath<t.ImportDeclaration>) {
      const source = nodePath.node.source.value;
      if (!source.startsWith('.')) return; // skip bare/package specifiers

      for (const specifier of nodePath.node.specifiers) {
        if (t.isImportDefaultSpecifier(specifier) || t.isImportSpecifier(specifier)) {
          imports.set(specifier.local.name, source);
        }
      }
    },
  });

  return imports;
}

/** Every capitalised JSX tag name rendered anywhere in the file (component convention). */
function collectRenderedComponentNames(ast: t.File): Set<string> {
  const names = new Set<string>();

  traverse(ast, {
    JSXElement(nodePath: NodePath<t.JSXElement>) {
      const name = nodePath.node.openingElement.name;
      if (t.isJSXIdentifier(name) && /^[A-Z]/.test(name.name)) {
        names.add(name.name);
      }
    },
  });

  return names;
}

function emptyContent(): ExtractedContent {
  return { title: null, headings: [], textSnippets: [], metaDescription: null, sections: [] };
}

export interface ExtractContentRecursiveOptions {
  /** Maximum number of local-import hops to follow. Default: 3 */
  maxDepth?: number;
  /** tsconfig path aliases to thread through import resolution */
  aliases?: Record<string, string>;
}

function extractRecursive(
  filePath: string,
  depthRemaining: number,
  aliases: Record<string, string>,
  visited: Set<string>,
): ContentExtractionResult {
  const absoluteFile = path.resolve(filePath);
  if (visited.has(absoluteFile)) {
    return { content: emptyContent(), navigableElements: [], unresolvableLinkCount: 0 };
  }
  visited.add(absoluteFile);

  const source = readFileSync(absoluteFile, 'utf-8');

  // MDX/Markdown uses a separate regex-based path — no Babel parsing, no
  // import-following (finding 12 is intentionally scoped to headings/paragraphs).
  if (isMarkdownFile(absoluteFile)) {
    return extractMarkdownContent(source);
  }

  const ast = parseModule(source);
  const own = extractFromAst(ast);

  if (depthRemaining <= 0) {
    return own;
  }

  const localImports = collectLocalComponentImports(ast);
  const renderedNames = collectRenderedComponentNames(ast);

  const mergedSections = [...own.content.sections];
  const mergedNav = [...own.navigableElements];
  const seenAgentTargets = new Set<string>(own.content.dataAgentTargets ?? []);
  const mergedAgentTargets = [...(own.content.dataAgentTargets ?? [])];
  let unresolvableLinkCount = own.unresolvableLinkCount;

  for (const name of renderedNames) {
    const specifier = localImports.get(name);
    if (!specifier) continue; // not a local relative import — skip

    const resolved = resolveImport({ specifier, fromFile: absoluteFile, aliases });
    if (!resolved || !existsSync(resolved)) continue;

    const child = extractRecursive(resolved, depthRemaining - 1, aliases, visited);
    mergedSections.push(...child.content.sections);
    mergedNav.push(...child.navigableElements);
    for (const target of child.content.dataAgentTargets ?? []) {
      if (!seenAgentTargets.has(target)) {
        seenAgentTargets.add(target);
        mergedAgentTargets.push(target);
      }
    }
    unresolvableLinkCount += child.unresolvableLinkCount;
  }

  const { headings, textSnippets } = deriveFlatFields(mergedSections);

  return {
    content: {
      title: own.content.title,
      headings,
      textSnippets,
      metaDescription: own.content.metaDescription,
      sections: mergedSections,
      dataAgentTargets: mergedAgentTargets,
    },
    navigableElements: mergedNav,
    unresolvableLinkCount,
  };
}

/**
 * Like `extractContentFromFile`, but also resolves and merges in content from
 * locally-imported components that this file actually renders in its JSX
 * (skipping node_modules/bare-specifier imports). Guards against circular
 * imports with a visited-file set and stops recursing past `maxDepth` hops.
 */
export function extractContentFromFileRecursive(
  filePath: string,
  options: ExtractContentRecursiveOptions = {},
): ContentExtractionResult {
  const maxDepth = options.maxDepth ?? 3;
  const aliases = options.aliases ?? {};
  return extractRecursive(filePath, maxDepth, aliases, new Set());
}
