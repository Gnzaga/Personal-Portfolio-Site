import fs from 'node:fs/promises';
import path from 'node:path';
import type { ScannedRoute, ScannedSite } from '../types.js';
import { deriveFlatFields, extractContentFromFileRecursive } from './content-extractor.js';
import { loadTsconfigPaths } from './tsconfig-paths.js';

export interface ScanNextJsOptions {
  appDir: string;
  projectRoot: string;
}

const PAGE_FILENAMES = new Set(['page.tsx', 'page.ts', 'page.jsx', 'page.js', 'page.mdx', 'page.md']);
const LAYOUT_FILENAMES = new Set(['layout.tsx', 'layout.ts', 'layout.jsx', 'layout.js']);

interface RouteFiles {
  pageFiles: string[];
  layoutFiles: string[];
}

/**
 * Recursively collect all page.* and layout.* files under a directory.
 * Skips directories whose names start with `_`.
 */
async function collectRouteFiles(dir: string): Promise<RouteFiles> {
  const pageFiles: string[] = [];
  const layoutFiles: string[] = [];

  let entries: import('node:fs').Dirent[];
  try {
    entries = await fs.readdir(dir, { withFileTypes: true }) as unknown as import('node:fs').Dirent[];
  } catch {
    return { pageFiles, layoutFiles };
  }

  for (const entry of entries) {
    const name = String(entry.name);
    if (name.startsWith('_')) continue;

    const fullPath = path.join(dir, name);

    if (entry.isDirectory()) {
      const nested = await collectRouteFiles(fullPath);
      pageFiles.push(...nested.pageFiles);
      layoutFiles.push(...nested.layoutFiles);
    } else if (entry.isFile() && PAGE_FILENAMES.has(name)) {
      pageFiles.push(fullPath);
    } else if (entry.isFile() && LAYOUT_FILENAMES.has(name)) {
      layoutFiles.push(fullPath);
    }
  }

  return { pageFiles, layoutFiles };
}

/**
 * Layouts whose directory is an ancestor of (or equal to) the page's directory,
 * ordered from the root layout to the most deeply nested layout (finding 5).
 */
function findApplicableLayouts(pageFile: string, layoutFiles: string[]): string[] {
  const pageDir = path.dirname(pageFile);

  return layoutFiles
    .filter((layoutFile) => {
      const layoutDir = path.dirname(layoutFile);
      return pageDir === layoutDir || pageDir.startsWith(layoutDir + path.sep);
    })
    .sort((a, b) => path.dirname(a).length - path.dirname(b).length);
}

/**
 * Convert an absolute page file path to a route path string.
 *
 * Rules:
 *  - Strip appDir prefix
 *  - Strip trailing /page.tsx (or .ts/.jsx/.js)
 *  - Remove route-group segments: `(group)` → removed
 *  - Replace dynamic segments: `[param]` → `:param`, mark isDynamic = true
 *  - Empty path after stripping → `/`
 */
/** Repeated intercepting-route markers at the start of a segment: (.) (..) (...) (..)(..) ... */
const INTERCEPTING_PREFIX = /^(?:\(\.{1,3}\))+/;

function filePathToRoute(
  absolutePageFile: string,
  appDir: string,
): { routePath: string; isDynamic: boolean } {
  // Strip appDir prefix, normalize to forward slashes
  const relative = absolutePageFile
    .slice(appDir.length)
    .replace(/\\/g, '/');

  // Strip leading slash, then strip the trailing page filename segment.
  // The root page.tsx results in "/page.tsx" → after stripping leading slash → "page.tsx"
  // which we remove entirely, giving an empty string → maps to "/".
  const withoutLeadingSlash = relative.replace(/^\//, '');
  const withoutPage = withoutLeadingSlash
    .replace(/^page\.(?:[jt]sx?|mdx?)$/, '')
    .replace(/\/page\.(?:[jt]sx?|mdx?)$/, '');

  // Split into segments and process each
  const segments = withoutPage.split('/').filter(Boolean);
  let isDynamic = false;

  const routeSegments: string[] = [];

  for (const segment of segments) {
    // Parallel-route slots — @slotName — never appear in the URL
    if (segment.startsWith('@')) {
      continue;
    }

    // Route groups — (group) — are ignored entirely
    if (segment.startsWith('(') && segment.endsWith(')')) {
      continue;
    }

    // Intercepting-route prefixes — (.)  (..)  (...)  (..)(..) — stripped,
    // keeping whatever segment name they're attached to (e.g. "(.)photo" → "photo").
    const withoutIntercept = segment.replace(INTERCEPTING_PREFIX, '');
    if (!withoutIntercept) continue;

    // Dynamic segments — [param] → :param
    const dynamicMatch = withoutIntercept.match(/^\[(.+)\]$/);
    if (dynamicMatch) {
      isDynamic = true;
      routeSegments.push(`:${dynamicMatch[1]}`);
    } else {
      routeSegments.push(withoutIntercept);
    }
  }

  const routePath = routeSegments.length === 0 ? '/' : `/${routeSegments.join('/')}`;
  return { routePath, isDynamic };
}

export async function scanNextJs(options: ScanNextJsOptions): Promise<ScannedSite> {
  const { appDir, projectRoot } = options;

  const { pageFiles, layoutFiles } = await collectRouteFiles(appDir);
  const aliases = loadTsconfigPaths(projectRoot);

  if (pageFiles.length === 0) {
    console.warn(
      `[shippilot] scan found 0 page files under "${appDir}". Check that "entryPoint" ` +
        `in your shippilot config points at your Next.js app directory (the folder ` +
        `containing page.tsx files).`,
    );
  }

  // Layouts wrap every page beneath them; memoize so a shared layout (e.g. the
  // root layout) is only parsed once no matter how many pages it applies to.
  const layoutContentCache = new Map<string, import('./content-extractor.js').ContentExtractionResult>();
  function extractLayoutContent(layoutFile: string): import('./content-extractor.js').ContentExtractionResult {
    let cached = layoutContentCache.get(layoutFile);
    if (!cached) {
      cached = extractContentFromFileRecursive(layoutFile, { aliases });
      layoutContentCache.set(layoutFile, cached);
    }
    return cached;
  }

  const routes: ScannedRoute[] = [];

  let unresolvableLinkCount = 0;

  for (const absoluteFile of pageFiles) {
    const { routePath, isDynamic } = filePathToRoute(absoluteFile, appDir);

    // componentFile is relative to projectRoot, using forward slashes
    const componentFile = absoluteFile
      .slice(projectRoot.length)
      .replace(/\\/g, '/')
      .replace(/^\//, '');

    let content: import('../types.js').ExtractedContent;
    let navigableElements: import('../types.js').NavigableElement[];

    try {
      const extracted = extractContentFromFileRecursive(absoluteFile, { aliases });
      content = extracted.content;
      navigableElements = extracted.navigableElements;
      unresolvableLinkCount += extracted.unresolvableLinkCount;

      // Attribute wrapping layouts' content/links to this route (finding 5):
      // the page's own content stays first (so `title` is unaffected), with
      // each applicable layout appended root-to-nested.
      const applicableLayouts = findApplicableLayouts(absoluteFile, layoutFiles);
      if (applicableLayouts.length > 0) {
        const mergedSections = [...content.sections];
        const mergedNav = [...navigableElements];

        for (const layoutFile of applicableLayouts) {
          const layoutExtracted = extractLayoutContent(layoutFile);
          mergedSections.push(...layoutExtracted.content.sections);
          mergedNav.push(...layoutExtracted.navigableElements);
        }

        const { headings, textSnippets } = deriveFlatFields(mergedSections);
        content = { ...content, headings, textSnippets, sections: mergedSections };
        navigableElements = mergedNav;
      }
    } catch {
      content = {
        title: null,
        headings: [],
        textSnippets: [],
        metaDescription: null,
        sections: [],
      };
      navigableElements = [];
    }

    routes.push({
      path: routePath,
      componentFile,
      content,
      navigableElements,
      isDynamic,
    });
  }

  // Sort routes for deterministic output: static before dynamic, then alphabetically
  routes.sort((a, b) => {
    if (a.isDynamic !== b.isDynamic) return a.isDynamic ? 1 : -1;
    return a.path.localeCompare(b.path);
  });

  // Each layout is only extracted once (cached above) regardless of how many
  // routes it wraps, so tally its unresolvable-link count once here too.
  for (const layoutExtracted of layoutContentCache.values()) {
    unresolvableLinkCount += layoutExtracted.unresolvableLinkCount;
  }

  if (unresolvableLinkCount > 0) {
    console.warn(
      `[shippilot] scan found ${unresolvableLinkCount} link(s) with unresolvable destinations ` +
        `(dynamic expressions with no static prefix — no route edge can be inferred for these).`,
    );
  }

  return {
    framework: 'nextjs-app',
    routes,
  };
}
