import fs from 'node:fs';
import path from 'node:path';

/**
 * Strip `//` line comments and block comments from a JSONC string,
 * leaving string literal contents untouched.
 */
function stripJsonComments(input: string): string {
  let result = '';
  let inString = false;
  let inLineComment = false;
  let inBlockComment = false;

  for (let i = 0; i < input.length; i++) {
    const ch = input[i]!;
    const next = input[i + 1];

    if (inLineComment) {
      if (ch === '\n') {
        inLineComment = false;
        result += ch;
      }
      continue;
    }

    if (inBlockComment) {
      if (ch === '*' && next === '/') {
        inBlockComment = false;
        i++;
      }
      continue;
    }

    if (inString) {
      result += ch;
      if (ch === '\\') {
        // Preserve the escaped character verbatim (e.g. \" or \\)
        if (next !== undefined) {
          result += next;
          i++;
        }
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }

    if (ch === '"') {
      inString = true;
      result += ch;
      continue;
    }

    if (ch === '/' && next === '/') {
      inLineComment = true;
      i++;
      continue;
    }

    if (ch === '/' && next === '*') {
      inBlockComment = true;
      i++;
      continue;
    }

    result += ch;
  }

  return result;
}

/** Remove trailing commas before a closing `}` or `]` (not valid in strict JSON). */
function stripTrailingCommas(input: string): string {
  return input.replace(/,(\s*[}\]])/g, '$1');
}

/** Parse a tsconfig.json body, tolerating comments and trailing commas (JSONC). */
function parseJsonc(raw: string): unknown {
  return JSON.parse(stripTrailingCommas(stripJsonComments(raw)));
}

export function loadTsconfigPaths(projectRoot: string): Record<string, string> {
  try {
    const tsconfigPath = path.join(projectRoot, 'tsconfig.json');
    const raw = fs.readFileSync(tsconfigPath, 'utf-8');
    const tsconfig = parseJsonc(raw) as {
      compilerOptions?: { baseUrl?: string; paths?: Record<string, string[]> };
    };

    const compilerOptions = tsconfig.compilerOptions ?? {};
    const baseUrl: string = compilerOptions.baseUrl ?? '.';
    const paths: Record<string, string[]> = compilerOptions.paths ?? {};

    const resolvedBase = path.resolve(projectRoot, baseUrl);
    const result: Record<string, string> = {};

    for (const [alias, targets] of Object.entries(paths)) {
      if (targets.length > 0) {
        // Take the first target and resolve it relative to the base
        const target = targets[0];
        result[alias] = path.resolve(resolvedBase, target);
      }
    }

    return result;
  } catch {
    return {};
  }
}
