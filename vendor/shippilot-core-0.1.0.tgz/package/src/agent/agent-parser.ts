import type { AgentAction } from '../types.js';

export interface ExtractAgentActionResult {
  cleanedText: string;
  agentAction: AgentAction | null;
}

/**
 * Matches a complete [[AGENT:{...}]] tag anywhere in the text — NOT
 * end-anchored, so trailing text after the tag (or another tag after it)
 * never causes the match to be silently missed.
 */
const AGENT_TAG_REGEX = /\[\[AGENT:([\s\S]*?)\]\]/g;

/** Every complete tag match found in `text`, in order of appearance. */
function findAgentTagMatches(text: string): RegExpExecArray[] {
  const matches: RegExpExecArray[] = [];
  const regex = new RegExp(AGENT_TAG_REGEX);
  let m: RegExpExecArray | null;
  while ((m = regex.exec(text)) !== null) {
    matches.push(m);
  }
  return matches;
}

/**
 * Strips every complete [[AGENT:...]] tag from `text`, then also strips a
 * trailing partial (streaming-incomplete) tag: `[[AGENT:` or a dangling `[[`.
 * Used by both the streaming preview and the final commit path so the two
 * can never disagree about what counts as a tag.
 */
export function stripAgentTags(text: string): string {
  let cleaned = text.replace(AGENT_TAG_REGEX, '');
  cleaned = cleaned.replace(/\[\[AGENT:[\s\S]*$/, '');
  cleaned = cleaned.replace(/\[\[$/, '');
  return cleaned;
}

/**
 * Extracts the LAST [[AGENT:{...}]] tag anywhere in `text` (tolerating any
 * trailing text after it, and any other tags before it), returning the
 * cleaned text (every tag stripped, via stripAgentTags) plus the parsed
 * agent action. On no match, or on JSON.parse failure, agentAction is
 * null — but cleanedText still has every complete tag stripped, so a
 * malformed tag never leaks raw into the chat.
 */
export function extractAgentAction(text: string): ExtractAgentActionResult {
  const matches = findAgentTagMatches(text);

  if (matches.length === 0) {
    return { cleanedText: text, agentAction: null };
  }

  const cleanedText = stripAgentTags(text).trim();
  const lastMatch = matches[matches.length - 1]!;

  try {
    const agentAction = JSON.parse(lastMatch[1]!) as AgentAction;
    return { cleanedText, agentAction };
  } catch {
    return { cleanedText, agentAction: null };
  }
}
