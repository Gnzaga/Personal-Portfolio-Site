// Browser-safe exports — no Node.js dependencies.
// Import from @shippilot/core/browser in frontend code.
export type * from './types.js';
export { extractAgentAction, stripAgentTags } from './agent/agent-parser.js';
export { computeNavigationSteps } from './graph/pathfinder.js';
