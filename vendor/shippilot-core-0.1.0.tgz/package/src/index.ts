export type * from './types.js';
export { computeNavigationSteps } from './graph/pathfinder.js';
export { buildSystemPrompt } from './prompt/prompt-builder.js';
export { buildSiteGraph } from './graph/graph-builder.js';
export { verifyTargets } from './graph/target-verifier.js';
export type { TargetVerificationWarning } from './graph/target-verifier.js';
export { scanReactRouter, scanNextJs } from './scanner/index.js';
export type { ScanReactRouterOptions, ScanNextJsOptions } from './scanner/index.js';
export { handleChatRequest, createChatMiddleware, createChatHandler } from './server/index.js';
export type { ChatHandlerOptions, ChatHandlerResult } from './server/index.js';
export { extractAgentAction, stripAgentTags } from './agent/agent-parser.js';
export type { ExtractAgentActionResult } from './agent/agent-parser.js';
export * from './rag/index.js';

// CLI exports (programmatic API for consumers who don't use the binary)
export { loadConfig, validateConfig, mergeWithDefaults } from './cli/config.js';
export { detectFramework } from './cli/detect-framework.js';
export { generateSmokeQuestions } from './cli/question-generator.js';
export { runScan } from './cli/commands/scan.js';
export type { ScanResult } from './cli/commands/scan.js';
export { runDoctor } from './cli/commands/doctor.js';
export type { DoctorReport } from './cli/commands/doctor.js';
export { runSmoke } from './cli/commands/test-smoke.js';
export type { SmokeResult } from './cli/commands/test-smoke.js';
export { createInteractiveSession } from './cli/commands/interactive.js';
export type { InteractiveSession } from './cli/commands/interactive.js';
export { buildInitConfig, runInit } from './cli/commands/init.js';
export type { InitAnswers, InitPrompts } from './cli/commands/init.js';
export { buildServeApp } from './cli/commands/serve.js';
