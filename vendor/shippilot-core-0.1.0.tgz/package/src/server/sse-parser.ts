export interface ParsedSSEChunk {
  type: 'delta' | 'done' | 'ignore';
  content?: string;
}

/**
 * Parse a single SSE line into a ParsedSSEChunk.
 * Handles OpenAI-style (choices[0].delta.content) and Ollama-style
 * (message.content or response).
 */
export function parseSSELine(line: string): ParsedSSEChunk {
  const trimmed = line.trim();

  // Empty or SSE comment
  if (trimmed === '' || trimmed.startsWith(':')) {
    return { type: 'ignore' };
  }

  // Must start with 'data:'
  if (!trimmed.startsWith('data:')) {
    return { type: 'ignore' };
  }

  // Extract content after 'data:' and strip leading whitespace
  const payload = trimmed.slice('data:'.length).trimStart();

  // Terminator
  if (payload === '[DONE]') {
    return { type: 'done' };
  }

  // Parse JSON
  let parsed: unknown;
  try {
    parsed = JSON.parse(payload);
  } catch {
    return { type: 'ignore' };
  }

  if (parsed === null || typeof parsed !== 'object') {
    return { type: 'ignore' };
  }

  const obj = parsed as Record<string, unknown>;

  // OpenAI format: choices[0].delta.content
  if (Array.isArray(obj['choices']) && obj['choices'].length > 0) {
    const first = obj['choices'][0] as Record<string, unknown>;
    if (first && typeof first === 'object' && 'delta' in first) {
      const delta = first['delta'] as Record<string, unknown>;
      if (delta && typeof delta === 'object' && typeof delta['content'] === 'string') {
        return { type: 'delta', content: delta['content'] };
      }
    }
    return { type: 'ignore' };
  }

  // Ollama format: message.content
  if ('message' in obj && obj['message'] !== null && typeof obj['message'] === 'object') {
    const message = obj['message'] as Record<string, unknown>;
    if (typeof message['content'] === 'string') {
      return { type: 'delta', content: message['content'] };
    }
  }

  // Ollama format: response
  if (typeof obj['response'] === 'string') {
    return { type: 'delta', content: obj['response'] };
  }

  return { type: 'ignore' };
}

/**
 * Parse a raw chunk (potentially containing multiple lines) into an array
 * of ParsedSSEChunks.
 */
export function parseSSEChunk(chunk: string): ParsedSSEChunk[] {
  return chunk
    .split('\n')
    .map((line) => line.replace(/\r$/, ''))
    .map((line) => parseSSELine(line))
    .filter((parsed) => parsed.type !== 'ignore');
}
