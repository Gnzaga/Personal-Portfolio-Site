import { handleChatRequest } from './chat-handler.js';
import type { ChatHandlerOptions } from './chat-handler.js';
import type { ChatRequestBody } from '../types.js';

export function createChatHandler(
  options: ChatHandlerOptions,
): (req: Request) => Promise<Response> {
  return async (req: Request): Promise<Response> => {
    let body: ChatRequestBody;
    try {
      body = (await req.json()) as ChatRequestBody;
    } catch {
      return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const result = await handleChatRequest(body, options);

    if (typeof result.body === 'string') {
      return new Response(JSON.stringify({ error: result.body }), {
        status: result.status,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    return new Response(result.body, {
      status: result.status,
      headers: result.headers,
    });
  };
}
