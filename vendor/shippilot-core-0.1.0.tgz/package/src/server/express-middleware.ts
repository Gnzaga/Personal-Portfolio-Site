import { handleChatRequest } from './chat-handler.js';
import type { ChatHandlerOptions } from './chat-handler.js';
import type { ChatRequestBody } from '../types.js';

/** Minimal duck-typed Express request interface. */
export interface ExpressRequest {
  body?: unknown;
}

/** Minimal duck-typed Express response interface. */
export interface ExpressResponse {
  status(code: number): ExpressResponse;
  json(body: unknown): void;
  writeHead(status: number, headers: Record<string, string>): void;
  write(chunk: string | Uint8Array): boolean;
  end(): void;
  flushHeaders?(): void;
}

export type ExpressNext = (err?: unknown) => void;

export function createChatMiddleware(
  options: ChatHandlerOptions,
): (req: ExpressRequest, res: ExpressResponse, next?: ExpressNext) => Promise<void> {
  return async (req: ExpressRequest, res: ExpressResponse, next?: ExpressNext): Promise<void> => {
    try {
      const body = (req.body ?? {}) as ChatRequestBody;
      const result = await handleChatRequest(body, options);

      if (typeof result.body === 'string') {
        // Error response
        res.status(result.status).json({ error: result.body });
        return;
      }

      // Streaming response
      res.writeHead(result.status, result.headers);
      res.flushHeaders?.();

      const reader = result.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        res.write(decoder.decode(value));
      }
      res.end();
    } catch (err) {
      if (next) {
        next(err);
      } else {
        throw err;
      }
    }
  };
}
