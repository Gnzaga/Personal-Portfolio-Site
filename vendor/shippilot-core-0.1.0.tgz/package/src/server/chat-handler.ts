import type { ChatRequestBody, ChatMessage, ShipPilotServerOptions, ContentChunk } from '../types.js';
import { buildSystemPrompt } from '../prompt/prompt-builder.js';
import { parseSSEChunk } from './sse-parser.js';
import { retrieveRelevantChunks } from '../rag/retriever.js';

export interface ChatHandlerOptions extends ShipPilotServerOptions {
  /** Injectable fetch for testing. Defaults to globalThis.fetch. */
  fetch?: typeof globalThis.fetch;
}

export interface ChatHandlerResult {
  status: number;
  headers: Record<string, string>;
  body: ReadableStream<Uint8Array> | string;
}

function isValidHistoryEntry(entry: unknown): entry is ChatMessage {
  if (entry === null || typeof entry !== 'object') return false;
  const e = entry as Record<string, unknown>;
  return (
    (e['role'] === 'user' || e['role'] === 'assistant') &&
    typeof e['content'] === 'string'
  );
}

export async function handleChatRequest(
  body: ChatRequestBody,
  options: ChatHandlerOptions,
): Promise<ChatHandlerResult> {
  // 1. Validation
  if (!body.message || typeof body.message !== 'string' || body.message.trim() === '') {
    return { status: 400, headers: {}, body: 'Invalid or missing message' };
  }

  // 2. History validation and truncation
  const rawHistory = Array.isArray(body.history) ? body.history : [];
  const validHistory = rawHistory.filter(isValidHistoryEntry);
  const maxHistory = options.maxHistoryMessages ?? 10;
  const history = validHistory.slice(-maxHistory);

  // 3. RAG retrieval (when both vectorStore and embeddingProvider are configured)
  let retrievedChunks: ContentChunk[] | undefined;
  if (options.vectorStore && options.embeddingProvider) {
    try {
      retrievedChunks = await retrieveRelevantChunks(body.message, {
        embedder: options.embeddingProvider,
        store: options.vectorStore,
        graph: options.siteGraph,
        topK: options.ragTopK,
      });
    } catch {
      return { status: 502, headers: {}, body: 'RAG retrieval failed' };
    }
  }

  // 4. Build system prompt
  const systemPrompt = buildSystemPrompt({
    graph: options.siteGraph,
    currentPage: body.currentPage ?? '/',
    siteContext: options.siteContext ?? '',
    customInstructions: options.customInstructions,
    retrievedChunks,
  });

  // 5. Construct messages array
  const messages = [
    { role: 'system', content: systemPrompt },
    ...history,
    { role: 'user', content: body.message },
  ];

  // 5. Build Authorization header
  const apiKey = options.model.apiKey;
  const authHeader = apiKey.startsWith('Bearer ') ? apiKey : `Bearer ${apiKey}`;

  // 6. Fetch upstream
  const fetchFn = options.fetch ?? globalThis.fetch;
  let response: Response;
  try {
    response = await fetchFn(options.model.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader,
      },
      body: JSON.stringify({
        model: options.model.modelName,
        messages,
        stream: true,
      }),
    });
  } catch {
    return { status: 502, headers: {}, body: 'Upstream request failed' };
  }

  // 7. Check response status
  if (!response.ok) {
    return { status: 502, headers: {}, body: 'Upstream returned non-200 status' };
  }

  // 8. Pipe the stream
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const upstream = response.body!.getReader();

  const outputStream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        let buffer = '';
        while (true) {
          const { value, done } = await upstream.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          // Split on newlines, keep trailing incomplete line in buffer
          const lines = buffer.split('\n');
          buffer = lines.pop() ?? '';
          const parsed = parseSSEChunk(lines.join('\n'));
          for (const chunk of parsed) {
            if (chunk.type === 'delta' && chunk.content) {
              controller.enqueue(
                encoder.encode(`data: ${JSON.stringify({ delta: chunk.content })}\n\n`),
              );
            } else if (chunk.type === 'done') {
              controller.enqueue(encoder.encode('data: [DONE]\n\n'));
              controller.close();
              return;
            }
          }
        }
        // Flush trailing buffer
        if (buffer) {
          const parsed = parseSSEChunk(buffer);
          for (const chunk of parsed) {
            if (chunk.type === 'delta' && chunk.content) {
              controller.enqueue(
                encoder.encode(`data: ${JSON.stringify({ delta: chunk.content })}\n\n`),
              );
            }
          }
        }
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        controller.close();
      } catch (err) {
        controller.error(err);
      }
    },
  });

  return {
    status: 200,
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
    body: outputStream,
  };
}
