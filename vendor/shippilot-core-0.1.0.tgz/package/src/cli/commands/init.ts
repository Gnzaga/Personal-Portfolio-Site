import { existsSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { ShipPilotBuildConfig } from '../../types.js';
import { mergeWithDefaults, validateConfig } from '../config.js';
import { detectFramework } from '../detect-framework.js';

export interface InitAnswers {
  framework: 'react-router' | 'nextjs-app' | 'nextjs-pages';
  entryPoint: string;
  modelEndpoint: string;
  modelName: string;
  apiKeyEnv: string;
  siteContext: string;
  outputDir: string;
}

export interface InitPrompts {
  /** Ask for string input with a default value */
  ask(label: string, defaultValue?: string): Promise<string>;
  /** Ask for boolean confirmation */
  confirm(label: string): Promise<boolean>;
}

export function buildInitConfig(answers: InitAnswers): ShipPilotBuildConfig {
  return mergeWithDefaults({
    framework: answers.framework,
    entryPoint: answers.entryPoint,
    outputDir: answers.outputDir,
    model: {
      endpoint: answers.modelEndpoint,
      modelName: answers.modelName,
      apiKeyEnv: answers.apiKeyEnv,
    },
    site: { context: answers.siteContext, scope: 'public' },
  });
}

export async function writeInitConfig(
  projectRoot: string,
  config: ShipPilotBuildConfig,
  prompts: Pick<InitPrompts, 'confirm'>,
): Promise<{ path: string }> {
  const configPath = join(projectRoot, 'shippilot.config.json');
  if (existsSync(configPath)) {
    const ok = await prompts.confirm(`${configPath} already exists. Overwrite?`);
    if (!ok) return { path: configPath };
  }
  writeFileSync(configPath, JSON.stringify(config, null, 2));
  return { path: configPath };
}

export async function runInit(options: {
  projectRoot: string;
  prompts?: InitPrompts;
  framework?: 'react-router' | 'nextjs-app' | 'nextjs-pages';
  entryPoint?: string;
}): Promise<{ path: string }> {
  const defaultPrompts: InitPrompts = {
    ask: async (_label, def) => def ?? '',
    confirm: async () => true,
  };
  const prompts = options.prompts ?? defaultPrompts;

  // Use provided framework/entryPoint or detect from projectRoot
  const detected = options.framework
    ? { framework: options.framework, entryPoint: options.entryPoint ?? './src/App.tsx' }
    : detectFramework(options.projectRoot) ?? { framework: 'react-router' as const, entryPoint: './src/App.tsx' };

  const answers: InitAnswers = {
    framework: detected.framework as InitAnswers['framework'],
    entryPoint: detected.entryPoint,
    modelEndpoint: await prompts.ask('Model endpoint', 'https://api.openai.com/v1/chat/completions'),
    modelName: await prompts.ask('Model name', 'gpt-4o-mini'),
    apiKeyEnv: await prompts.ask('API key env var name', 'SHIPPILOT_API_KEY'),
    siteContext: await prompts.ask('Site context (1-2 sentences about your site)', ''),
    outputDir: await prompts.ask('Output directory', './shippilot'),
  };

  const config = buildInitConfig(answers);
  return writeInitConfig(options.projectRoot, config, prompts);
}
