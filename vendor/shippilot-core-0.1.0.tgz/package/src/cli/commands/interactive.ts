import type {
  ShipPilotBuildConfig,
  SiteGraph,
  ChatMessage,
  AgentAction,
  EmbeddingProvider,
  VectorStore,
} from '../../types.js';
import { handleChatRequest } from '../../server/chat-handler.js';
import { extractAgentAction } from '../../agent/agent-parser.js';

export interface InteractiveSession {
  sendMessage(message: string): Promise<{ response: string; agentAction: AgentAction | null }>;
  history(): ChatMessage[];
}

export function createInteractiveSession(options: {
  config: ShipPilotBuildConfig;
  siteGraph: SiteGraph;
  vectorStore?: VectorStore;
  embedder?: EmbeddingProvider;
  apiKey: string;
  fetch?: typeof globalThis.fetch;
  currentPage?: string;
}): InteractiveSession {
  const messages: ChatMessage[] = [];

  return {
    async sendMessage(message: string): Promise<{ response: string; agentAction: AgentAction | null }> {
      const { config, siteGraph, vectorStore, embedder, apiKey, currentPage } = options;
      const fetchFn = options.fetch ?? globalThis.fetch;

      const result = await handleChatRequest(
        {
          message,
          currentPage: currentPage ?? '/',
          history: [...messages],
        },
        {
          model: {
            endpoint: config.model.endpoint,
            apiKey,
            modelName: config.model.modelName,
          },
          siteGraph,
          vectorStore,
          embeddingProvider: embedder,
          siteContext: config.site?.context,
          customInstructions: config.site?.customInstructions,
          maxHistoryMessages: config.chat?.maxHistoryMessages,
          fetch: fetchFn,
        },
      );

      // Error cases: non-200 status or string body (error message)
      if (result.status !== 200 || typeof result.body === 'string') {
        throw new Error(
          typeof result.body === 'string'
            ? result.body
            : `Chat request failed with status ${result.status}`,
        );
      }

      // Drain the SSE stream
      const reader = (result.body as ReadableStream<Uint8Array>).getReader();
      const decoder = new TextDecoder();
      let full = '';
      let buffer = '';
      let streamDone = false;

      while (!streamDone) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed === 'data: [DONE]') {
            streamDone = true;
            break;
          }
          if (trimmed.startsWith('data: ')) {
            try {
              const parsed = JSON.parse(trimmed.slice(6)) as { delta?: string };
              if (parsed.delta) {
                full += parsed.delta;
              }
            } catch {
              // ignore malformed lines
            }
          }
        }
      }

      const { cleanedText, agentAction } = extractAgentAction(full);

      messages.push({ role: 'user', content: message });
      messages.push({ role: 'assistant', content: cleanedText });

      return { response: cleanedText, agentAction };
    },

    history(): ChatMessage[] {
      return [...messages];
    },
  };
}
