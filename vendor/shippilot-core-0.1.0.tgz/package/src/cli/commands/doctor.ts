import { stat, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import type { ShipPilotBuildConfig, SiteGraph } from '../../types.js';
import { validateConfig } from '../config.js';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface DoctorCheck {
  name: string;
  status: 'pass' | 'warn' | 'fail';
  message: string;
}

export interface DoctorReport {
  checks: DoctorCheck[];
  overall: 'pass' | 'warn' | 'fail';
}

// ─────────────────────────────────────────────────────────────────────────────
// runDoctor
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Runs a diagnostic sweep over the ShipPilot configuration, site graph, and
 * model endpoint. Returns a report with one check entry per diagnostic step.
 *
 * All checks run even when earlier ones fail, so the report is always complete.
 */
export async function runDoctor(options: {
  config: ShipPilotBuildConfig;
  projectRoot: string;
  fetch?: typeof globalThis.fetch;
}): Promise<DoctorReport> {
  const { config, projectRoot, fetch: fetchFn = globalThis.fetch } = options;
  const checks: DoctorCheck[] = [];

  // ── 1. Config valid ────────────────────────────────────────────────────────
  const validationResult = validateConfig(config);
  if (validationResult.valid) {
    checks.push({ name: 'config valid', status: 'pass', message: 'Configuration is valid' });
  } else {
    checks.push({
      name: 'config valid',
      status: 'fail',
      message: `Configuration errors: ${validationResult.errors.join('; ')}`,
    });
  }

  // ── 2. Entry point exists ──────────────────────────────────────────────────
  try {
    await stat(config.entryPoint);
    checks.push({ name: 'entry point exists', status: 'pass', message: `Found ${config.entryPoint}` });
  } catch {
    checks.push({
      name: 'entry point exists',
      status: 'fail',
      message: `Entry point not found: ${config.entryPoint}`,
    });
  }

  // ── 3. API key set ─────────────────────────────────────────────────────────
  const apiKey = process.env[config.model.apiKeyEnv];
  if (apiKey) {
    checks.push({ name: 'api key set', status: 'pass', message: `${config.model.apiKeyEnv} is set` });
  } else {
    checks.push({
      name: 'api key set',
      status: 'fail',
      message: `Environment variable ${config.model.apiKeyEnv} is not set`,
    });
  }

  // ── 4 & 5. Site graph exists + structure ──────────────────────────────────
  const graphPath = join(config.outputDir, 'site-graph.json');
  let graph: SiteGraph | null = null;

  try {
    const raw = await readFile(graphPath, 'utf-8');
    const parsed = JSON.parse(raw) as SiteGraph;
    if (!parsed.nodes || typeof parsed.nodes !== 'object') {
      throw new Error('Missing or invalid .nodes field');
    }
    graph = parsed;
    checks.push({ name: 'site graph exists', status: 'pass', message: `Found ${graphPath}` });
  } catch (err) {
    checks.push({
      name: 'site graph exists',
      status: 'fail',
      message: `site-graph.json not found or invalid: ${(err as Error).message}`,
    });
    // Structure check cannot run — record as fail
    checks.push({
      name: 'site graph structure',
      status: 'fail',
      message: 'Cannot check graph structure: graph not loaded',
    });
  }

  if (graph !== null) {
    const nodeCount = Object.keys(graph.nodes).length;
    const edgeCount = graph.edges.length;

    if (nodeCount === 0) {
      checks.push({
        name: 'site graph structure',
        status: 'warn',
        message: 'Graph has no nodes — run the scanner first',
      });
    } else if (edgeCount === 0) {
      checks.push({
        name: 'site graph structure',
        status: 'warn',
        message: 'Graph has no edges — nodes may be orphaned (no navigation links detected)',
      });
    } else {
      checks.push({
        name: 'site graph structure',
        status: 'pass',
        message: `Graph has ${nodeCount} nodes and ${edgeCount} edges`,
      });
    }
  }

  // ── Staleness: compare recorded sourceHashes against current file contents ──
  if (graph !== null) {
    if (!graph.sourceHashes || Object.keys(graph.sourceHashes).length === 0) {
      checks.push({
        name: 'site graph freshness',
        status: 'pass',
        message: 'No source hashes recorded — skipping staleness check',
      });
    } else {
      let changedCount = 0;
      for (const [componentFile, recordedHash] of Object.entries(graph.sourceHashes)) {
        try {
          const source = await readFile(join(projectRoot, componentFile), 'utf-8');
          const currentHash = createHash('sha256').update(source).digest('hex');
          if (currentHash !== recordedHash) changedCount++;
        } catch {
          // File missing entirely — count as changed (removed/renamed).
          changedCount++;
        }
      }

      if (changedCount > 0) {
        checks.push({
          name: 'site graph freshness',
          status: 'warn',
          message: `site-graph.json is stale — ${changedCount} source file${changedCount === 1 ? '' : 's'} changed since last scan; re-run shippilot scan`,
        });
      } else {
        checks.push({
          name: 'site graph freshness',
          status: 'pass',
          message: 'site-graph.json matches current source files',
        });
      }
    }
  } else {
    checks.push({
      name: 'site graph freshness',
      status: 'fail',
      message: 'Cannot check graph freshness: graph not loaded',
    });
  }

  // ── 6. Index exists (only when RAG is explicitly enabled) ─────────────────
  if (config.rag?.enabled === true) {
    const indexPath = join(config.outputDir, 'site-index.json');
    try {
      await stat(indexPath);
      checks.push({ name: 'index exists', status: 'pass', message: `Found ${indexPath}` });
    } catch {
      checks.push({
        name: 'index exists',
        status: 'fail',
        message: `site-index.json not found at ${indexPath} — run the indexer first`,
      });
    }
  } else {
    checks.push({
      name: 'index exists',
      status: 'pass',
      message: 'RAG not enabled — index check skipped',
    });
  }

  // ── 7. Model endpoint reachable ────────────────────────────────────────────
  try {
    const response = await fetchFn(config.model.endpoint, {
      method: 'POST',
      body: JSON.stringify({ messages: [{ role: 'user', content: 'ping' }], stream: false, max_tokens: 1 }),
      headers: { 'Content-Type': 'application/json' },
    });
    if (response.ok) {
      checks.push({
        name: 'model endpoint reachable',
        status: 'pass',
        message: `Endpoint ${config.model.endpoint} responded with ${response.status}`,
      });
    } else {
      checks.push({
        name: 'model endpoint reachable',
        status: 'fail',
        message: `Endpoint ${config.model.endpoint} returned status ${response.status}`,
      });
    }
  } catch (err) {
    checks.push({
      name: 'model endpoint reachable',
      status: 'fail',
      message: `Could not reach endpoint ${config.model.endpoint}: ${(err as Error).message}`,
    });
  }

  // ── Overall ────────────────────────────────────────────────────────────────
  let overall: DoctorReport['overall'] = 'pass';
  for (const c of checks) {
    if (c.status === 'fail') {
      overall = 'fail';
      break;
    }
    if (c.status === 'warn' && overall === 'pass') {
      overall = 'warn';
    }
  }

  return { checks, overall };
}
