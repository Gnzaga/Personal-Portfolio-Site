import type {
  ShipPilotBuildConfig,
  SiteGraph,
  EmbeddingProvider,
  VectorStore,
} from '../../types.js';
import { handleChatRequest } from '../../server/chat-handler.js';
import { extractAgentAction } from '../../agent/agent-parser.js';
import { generateSmokeQuestions } from '../question-generator.js';

export interface SmokeDetail {
  route: string;
  question: string;
  status: 'pass' | 'fail';
  reason?: string;
  response?: string;
}

export interface SmokeResult {
  passed: number;
  failed: number;
  details: SmokeDetail[];
}

export async function runSmoke(options: {
  config: ShipPilotBuildConfig;
  siteGraph: SiteGraph;
  vectorStore?: VectorStore;
  embedder?: EmbeddingProvider;
  apiKey: string;
  fetch?: typeof globalThis.fetch;
  perPage?: number;
}): Promise<SmokeResult> {
  const { config, siteGraph, vectorStore, embedder, apiKey, perPage } = options;
  const fetchFn = options.fetch ?? globalThis.fetch;

  const questions = generateSmokeQuestions(siteGraph, { perPage });
  const details: SmokeDetail[] = [];

  for (const { route, question } of questions) {
    const result = await handleChatRequest(
      { message: question, currentPage: route, history: [] },
      {
        model: {
          endpoint: config.model.endpoint,
          apiKey,
          modelName: config.model.modelName,
        },
        siteGraph,
        vectorStore,
        embeddingProvider: embedder,
        siteContext: config.site?.context,
        customInstructions: config.site?.customInstructions,
        maxHistoryMessages: config.chat?.maxHistoryMessages,
        fetch: fetchFn,
      },
    );

    // Handle upstream errors
    if (result.status !== 200 || typeof result.body === 'string') {
      details.push({
        route,
        question,
        status: 'fail',
        reason: typeof result.body === 'string' ? result.body : `upstream error: ${result.status}`,
      });
      continue;
    }

    // Drain the SSE stream
    const reader = (result.body as ReadableStream<Uint8Array>).getReader();
    const decoder = new TextDecoder();
    let full = '';
    let buffer = '';
    let streamDone = false;

    while (!streamDone) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed === 'data: [DONE]') {
          streamDone = true;
          break;
        }
        if (trimmed.startsWith('data: ')) {
          try {
            const parsed = JSON.parse(trimmed.slice(6)) as { delta?: string };
            if (parsed.delta) {
              full += parsed.delta;
            }
          } catch {
            // ignore malformed lines
          }
        }
      }
    }

    const { cleanedText, agentAction } = extractAgentAction(full);

    // Evaluate pass/fail
    if (cleanedText.trim().length === 0) {
      details.push({
        route,
        question,
        status: 'fail',
        reason: 'empty response',
        response: cleanedText,
      });
    } else if (agentAction !== null && agentAction.nav !== undefined && !(agentAction.nav in siteGraph.nodes)) {
      details.push({
        route,
        question,
        status: 'fail',
        reason: `hallucinated route: ${agentAction.nav}`,
        response: cleanedText,
      });
    } else {
      details.push({
        route,
        question,
        status: 'pass',
        response: cleanedText,
      });
    }
  }

  const passed = details.filter((d) => d.status === 'pass').length;
  const failed = details.filter((d) => d.status === 'fail').length;

  return { passed, failed, details };
}
