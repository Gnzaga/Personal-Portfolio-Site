import { readFile, access } from 'node:fs/promises';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import type { ShipPilotBuildConfig, SiteGraph, VectorStore, EmbeddingProvider } from '../../types.js';
import { createChatMiddleware } from '../../server/express-middleware.js';

export interface ServeAppOptions {
  config: ShipPilotBuildConfig;
  siteGraph: SiteGraph;
  vectorStore?: VectorStore;
  embedder?: EmbeddingProvider;
  apiKey: string;
  fetch?: typeof globalThis.fetch;
}

export async function buildServeApp(options: ServeAppOptions): Promise<import('express').Express> {
  let express: typeof import('express');
  try {
    express = (await import('express')).default;
  } catch {
    throw new Error('shippilot serve requires express: pnpm add express');
  }

  const app = express();
  app.use(express.json());

  // CORS for localhost origins
  app.use((req, res, next) => {
    const origin = req.headers['origin'] ?? '';
    if (
      origin.startsWith('http://localhost') ||
      origin.startsWith('http://127.0.0.1')
    ) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    }
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  // Health check endpoint
  app.get('/healthz', (_req, res) => {
    res.json({ ok: true });
  });

  // Chat endpoint
  const middleware = createChatMiddleware({
    model: {
      endpoint: options.config.model.endpoint,
      apiKey: options.apiKey,
      modelName: options.config.model.modelName,
    },
    siteGraph: options.siteGraph,
    vectorStore: options.vectorStore,
    embeddingProvider: options.embedder,
    siteContext: options.config.site?.context,
    customInstructions: options.config.site?.customInstructions,
    fetch: options.fetch,
  });

  app.post('/chat', middleware);

  return app;
}

export interface RunServeOptions {
  config: ShipPilotBuildConfig;
  projectRoot: string;
  port?: number;
  embedder?: EmbeddingProvider;
}

function isAddressInfo(address: string | AddressInfo | null): address is AddressInfo {
  return address !== null && typeof address !== 'string';
}

export async function getListeningAddress(server: import('node:http').Server): Promise<AddressInfo> {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const address = server.address();
    if (isAddressInfo(address)) {
      return address;
    }

    await new Promise<void>((resolve) => setTimeout(resolve, 0));
  }

  const address = server.address();
  if (isAddressInfo(address)) {
    return address;
  }

  throw new Error('Server did not expose a listening address');
}

export async function runServe(
  options: RunServeOptions,
): Promise<{ url: string; close: () => Promise<void> }> {
  const { config, projectRoot, port = 3001, embedder } = options;

  const outputPath = join(projectRoot, config.outputDir);
  const graphPath = join(outputPath, 'site-graph.json');
  const indexPath = join(outputPath, 'site-index.json');

  // Load site graph
  const siteGraph: SiteGraph = JSON.parse(await readFile(graphPath, 'utf-8'));

  // Check if RAG index exists
  let vectorStore: VectorStore | undefined;
  let activeEmbedder: EmbeddingProvider | undefined;

  const indexExists = await access(indexPath).then(() => true).catch(() => false);

  if (indexExists) {
    const { LocalVectorStore } = await import('../../rag/vector-store.js');
    const store = new LocalVectorStore(embedder?.dimensions ?? 384);
    await store.load(indexPath);
    vectorStore = store;

    if (embedder) {
      activeEmbedder = embedder;
    } else {
      const { LocalEmbedder } = await import('../../rag/embedder.js');
      activeEmbedder = new LocalEmbedder();
    }
  }

  const apiKey = process.env[config.model.apiKeyEnv] ?? '';

  const app = await buildServeApp({
    config,
    siteGraph,
    vectorStore,
    embedder: activeEmbedder,
    apiKey,
  });

  const server = await new Promise<import('node:http').Server>((resolve, reject) => {
    const s = app.listen(port);
    s.once('listening', () => resolve(s));
    s.once('error', reject);
  });

  const { port: boundPort } = await getListeningAddress(server);
  const url = `http://localhost:${boundPort}`;

  const close = (): Promise<void> =>
    new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });

  return { url, close };
}
