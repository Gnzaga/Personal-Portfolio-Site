import { writeFile, mkdir, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import type { ShipPilotBuildConfig, ScannedSite, ScannedRoute, EmbeddingProvider, VectorStore } from '../../types.js';
import { buildSiteGraph } from '../../graph/graph-builder.js';
import { verifyTargets } from '../../graph/target-verifier.js';
import type { TargetVerificationWarning } from '../../graph/target-verifier.js';
import { indexGraph } from '../../rag/indexer.js';
import { LocalEmbedder } from '../../rag/embedder.js';
import { LocalVectorStore } from '../../rag/vector-store.js';

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

export interface ScanResult {
  pageCount: number;
  edgeCount: number;
  chunkCount: number | null;
  orphanRoutes: string[];
  ragEnabled: boolean;
  outputPaths: { graph: string; index: string | null };
  targetWarnings: TargetVerificationWarning[];
}

type ScanFn = (config: ShipPilotBuildConfig, projectRoot: string) => Promise<ScannedSite>;

export interface RunScanOptions {
  config: ShipPilotBuildConfig;
  projectRoot: string;
  /** Injectable scanner — defaults to real scanner dispatch based on framework */
  scan?: ScanFn;
  /** Injectable embedding provider — defaults to LocalEmbedder when RAG is enabled */
  embedder?: EmbeddingProvider;
  /** Injectable vector store — defaults to LocalVectorStore when RAG is enabled */
  store?: VectorStore;
}

// ---------------------------------------------------------------------------
// Default scanner dispatch (used by CLI; not used in tests)
// ---------------------------------------------------------------------------

async function defaultScan(
  config: ShipPilotBuildConfig,
  projectRoot: string,
): Promise<ScannedSite> {
  if (config.framework === 'react-router') {
    const { scanReactRouter } = await import('../../scanner/index.js');
    return scanReactRouter({ entryPoint: config.entryPoint, projectRoot });
  } else {
    const { scanNextJs } = await import('../../scanner/index.js');
    const appDir = join(projectRoot, config.entryPoint);
    return scanNextJs({ appDir, projectRoot });
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Determine whether RAG should be enabled for this run.
 */
function shouldEnableRag(config: ShipPilotBuildConfig, pageCount: number): boolean {
  const ragCfg = config.rag;
  if (!ragCfg) return false;

  if (ragCfg.enabled === true) return true;
  if (ragCfg.enabled === false) return false;

  // 'auto' — compare pageCount against threshold
  const threshold = ragCfg.threshold ?? 20;
  return pageCount > threshold;
}

/**
 * Compute which route paths have no incoming edges (i.e. no other node points
 * to them via graph.edges).
 */
function computeOrphanRoutes(nodes: Record<string, unknown>, edges: Array<{ to: string }>): string[] {
  const reachable = new Set(edges.map((e) => e.to));
  return Object.keys(nodes).filter((path) => !reachable.has(path));
}

/**
 * sha256 hex digest of each route's component file, keyed by the
 * (projectRoot-relative) componentFile path. Files that can't be read
 * (e.g. synthetic test fixtures with no file on disk) are simply skipped
 * rather than failing the whole scan.
 */
async function computeSourceHashes(
  routes: ScannedRoute[],
  projectRoot: string,
): Promise<Record<string, string>> {
  const hashes: Record<string, string> = {};
  for (const route of routes) {
    try {
      const source = await readFile(join(projectRoot, route.componentFile), 'utf-8');
      hashes[route.componentFile] = createHash('sha256').update(source).digest('hex');
    } catch {
      // Component file unreadable — skip it.
    }
  }
  return hashes;
}

// ---------------------------------------------------------------------------
// Main export
// ---------------------------------------------------------------------------

export async function runScan(options: RunScanOptions): Promise<ScanResult> {
  const { config, projectRoot } = options;
  const scanFn = options.scan ?? defaultScan;

  // 1. Scan
  const scannedSite = await scanFn(config, projectRoot);

  // 2. Build graph
  const graph = buildSiteGraph(scannedSite);
  graph.sourceHashes = await computeSourceHashes(scannedSite.routes, projectRoot);

  // 2b. Verify synthesized navbar/card/detail IDs against what was
  // actually scanned, and surface any mismatches immediately.
  const targetWarnings = verifyTargets(graph);
  for (const warning of targetWarnings) {
    console.warn(`[ShipPilot] ${warning.message}`);
  }

  // 3. Compute metrics
  const pageCount = graph.pageCount;
  const edgeCount = graph.edges.length;
  const orphanRoutes = computeOrphanRoutes(graph.nodes, graph.edges);

  // 3b. Refuse to write a useless/empty graph — this almost always means
  // "entryPoint" is misconfigured (finding 9).
  if (pageCount === 0) {
    throw new Error(
      `shippilot scan found 0 pages. Check that "entryPoint" in your shippilot ` +
        `config points at the correct app entry point / app directory (currently: ` +
        `"${config.entryPoint}").`,
    );
  }

  // 4. Decide on RAG
  const ragEnabled = shouldEnableRag(config, pageCount);

  // 5. Ensure output directory exists
  const outputDir = config.outputDir;
  await mkdir(outputDir, { recursive: true });

  // 6. Write site-graph.json
  const graphPath = join(outputDir, 'site-graph.json');
  await writeFile(graphPath, JSON.stringify(graph, null, 2), 'utf-8');

  // 7. Optionally run RAG indexing
  let chunkCount: number | null = null;
  let indexPath: string | null = null;

  if (ragEnabled) {
    const embedder = options.embedder ?? new LocalEmbedder();
    const store = options.store ?? new LocalVectorStore(embedder.dimensions);

    const result = await indexGraph(graph, scannedSite, { embedder, store });
    chunkCount = result.chunkCount;

    indexPath = join(outputDir, 'site-index.json');
    await store.save(indexPath);
  }

  return {
    pageCount,
    edgeCount,
    chunkCount,
    orphanRoutes,
    ragEnabled,
    outputPaths: {
      graph: graphPath,
      index: indexPath,
    },
    targetWarnings,
  };
}
