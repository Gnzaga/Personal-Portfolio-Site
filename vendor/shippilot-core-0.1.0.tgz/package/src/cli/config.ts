import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { ShipPilotBuildConfig } from '../types.js';

// ─────────────────────────────────────────────────────────────────────────────
// Defaults for optional config sections
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_RAG: Required<NonNullable<ShipPilotBuildConfig['rag']>> = {
  enabled: 'auto',
  threshold: 20,
  topK: 5,
  chunkSize: 512,
  chunkOverlap: 50,
};

const DEFAULT_SITE: NonNullable<ShipPilotBuildConfig['site']> = {
  context: '',
  scope: 'public',
};

const DEFAULT_CHAT: Required<NonNullable<ShipPilotBuildConfig['chat']>> = {
  maxHistoryMessages: 10,
  welcomeMessage: 'Hi! Ask me anything.',
  agentModeLabel: 'Piloting...',
};

const DEFAULT_THEME: Required<NonNullable<ShipPilotBuildConfig['theme']>> = {
  mode: 'dark',
  accentColor: '#22c55e',
  position: 'bottom-right',
};

// ─────────────────────────────────────────────────────────────────────────────
// mergeWithDefaults
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Deep-merges a partial build config against sensible defaults for each
 * optional section. Required fields (framework, entryPoint, outputDir, model)
 * pass through as-is.
 */
export function mergeWithDefaults(partial: Partial<ShipPilotBuildConfig>): ShipPilotBuildConfig {
  return {
    framework: partial.framework as ShipPilotBuildConfig['framework'],
    entryPoint: partial.entryPoint as string,
    outputDir: partial.outputDir as string,
    model: partial.model as ShipPilotBuildConfig['model'],
    ...(partial.embedding !== undefined ? { embedding: partial.embedding } : {}),
    rag: { ...DEFAULT_RAG, ...(partial.rag ?? {}) },
    site: { ...DEFAULT_SITE, ...(partial.site ?? {}) },
    chat: { ...DEFAULT_CHAT, ...(partial.chat ?? {}) },
    theme: { ...DEFAULT_THEME, ...(partial.theme ?? {}) },
    ...(partial.contentSources !== undefined ? { contentSources: partial.contentSources } : {}),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// validateConfig
// ─────────────────────────────────────────────────────────────────────────────

type ValidationSuccess = { valid: true; config: ShipPilotBuildConfig };
type ValidationFailure = { valid: false; errors: string[] };

/**
 * Validates an unknown value against the required fields of ShipPilotBuildConfig.
 * Returns a discriminated-union result so callers can narrow the type safely.
 */
export function validateConfig(config: unknown): ValidationSuccess | ValidationFailure {
  const errors: string[] = [];
  const c = config as Record<string, unknown>;

  if (!c || typeof c !== 'object') {
    return { valid: false, errors: ['Config must be a non-null object'] };
  }

  if (!c['framework']) {
    errors.push('Missing required field: framework');
  }

  if (!c['entryPoint']) {
    errors.push('Missing required field: entryPoint');
  }

  if (!c['outputDir']) {
    errors.push('Missing required field: outputDir');
  }

  const model = c['model'] as Record<string, unknown> | undefined;
  if (!model || typeof model !== 'object') {
    errors.push('Missing required field: model');
  } else {
    if (!model['endpoint']) {
      errors.push('Missing required field: model.endpoint');
    }
    if (!model['modelName']) {
      errors.push('Missing required field: model.modelName');
    }
    if (!model['apiKeyEnv']) {
      errors.push('Missing required field: model.apiKeyEnv');
    }
  }

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  return { valid: true, config: config as ShipPilotBuildConfig };
}

// ─────────────────────────────────────────────────────────────────────────────
// loadConfig
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Reads shippilot.config.json from the given project root, validates it, and
 * returns the fully-defaulted ShipPilotBuildConfig.
 *
 * Throws descriptive errors for missing file, malformed JSON, or invalid shape.
 */
export function loadConfig(projectRoot: string): ShipPilotBuildConfig {
  const configPath = join(projectRoot, 'shippilot.config.json');

  let raw: string;
  try {
    raw = readFileSync(configPath, 'utf-8');
  } catch {
    throw new Error(`Config not found at ${configPath}`);
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error(`Failed to parse JSON at ${configPath}`);
  }

  const result = validateConfig(parsed);
  if (!result.valid) {
    throw new Error(`Invalid config at ${configPath}:\n${result.errors.join('\n')}`);
  }

  return mergeWithDefaults(parsed as Partial<ShipPilotBuildConfig>);
}
