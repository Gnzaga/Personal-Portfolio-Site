import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

export type DetectedFramework = {
  framework: 'react-router' | 'nextjs-app' | 'nextjs-pages';
  entryPoint: string;
} | null;

export function detectFramework(projectRoot: string): DetectedFramework {
  // 1. Check for Next.js config file
  const nextConfigCandidates = ['next.config.js', 'next.config.ts', 'next.config.mjs'];
  const isNextjs = nextConfigCandidates.some((f) => existsSync(join(projectRoot, f)));

  if (isNextjs) {
    // Check for app router (app/ or src/app/)
    if (existsSync(join(projectRoot, 'app'))) {
      return { framework: 'nextjs-app', entryPoint: 'app' };
    }
    if (existsSync(join(projectRoot, 'src', 'app'))) {
      return { framework: 'nextjs-app', entryPoint: 'src/app' };
    }
    // Check for pages router (pages/ or src/pages/)
    if (existsSync(join(projectRoot, 'pages'))) {
      return { framework: 'nextjs-pages', entryPoint: 'pages' };
    }
    if (existsSync(join(projectRoot, 'src', 'pages'))) {
      return { framework: 'nextjs-pages', entryPoint: 'src/pages' };
    }
    // Modern Next.js default
    return { framework: 'nextjs-app', entryPoint: 'app' };
  }

  // 2. Check for React Router via package.json
  const pkgPath = join(projectRoot, 'package.json');
  if (existsSync(pkgPath)) {
    let pkg: Record<string, unknown> = {};
    try {
      pkg = JSON.parse(readFileSync(pkgPath, 'utf-8'));
    } catch {
      // malformed package.json — skip
    }

    const allDeps = {
      ...(pkg.dependencies as Record<string, string> | undefined),
      ...(pkg.devDependencies as Record<string, string> | undefined),
      ...(pkg.peerDependencies as Record<string, string> | undefined),
    };

    const hasReactRouter = 'react-router' in allDeps || 'react-router-dom' in allDeps;

    if (hasReactRouter) {
      const candidates = ['src/App.tsx', 'src/App.jsx', 'src/main.tsx', 'src/index.tsx'];
      const found = candidates.find((c) => existsSync(join(projectRoot, c)));
      return { framework: 'react-router', entryPoint: found ?? 'src/App.tsx' };
    }
  }

  return null;
}
