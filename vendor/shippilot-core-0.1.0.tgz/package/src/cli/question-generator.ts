import type { SiteGraph } from '../types.js';

export interface SmokeQuestion {
  route: string;
  question: string;
}

/**
 * Generates smoke-test questions from a SiteGraph.
 * For each node with a non-empty contentSummary, emits up to `perPage`
 * questions (default: 1 per route).
 */
export function generateSmokeQuestions(
  graph: SiteGraph,
  opts?: { perPage?: number },
): SmokeQuestion[] {
  const perPage = opts?.perPage ?? 1;
  const results: SmokeQuestion[] = [];

  for (const [route, node] of Object.entries(graph.nodes)) {
    if (!node.contentSummary) continue;

    for (let i = 0; i < perPage; i++) {
      results.push({
        route,
        question: `Tell me about: ${node.contentSummary}`,
      });
    }
  }

  return results;
}
