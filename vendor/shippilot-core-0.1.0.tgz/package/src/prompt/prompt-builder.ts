import type { PromptBuilderOptions } from '../types.js';

export function buildSystemPrompt(options: PromptBuilderOptions): string {
  const { graph, currentPage, siteContext, retrievedChunks, customInstructions } = options;

  const currentNode = graph.nodes[currentPage];
  const contentSummary = currentNode?.contentSummary ?? `An unknown page at route "${currentPage}".`;

  // Determine which routes to list as available destinations
  const allRoutes = Object.keys(graph.nodes);

  const parts: string[] = [];

  // 1. Site context
  if (siteContext) {
    parts.push(siteContext);
  }

  // 2. PAGE CONTEXT
  parts.push(
    `--- PAGE CONTEXT ---\nThe user is currently viewing: ${currentPage}\nPage description: ${contentSummary}`
  );

  // 3. AVAILABLE DESTINATIONS
  const destinationList = allRoutes.map(r => `- ${r}`).join('\n');
  parts.push(
    `--- AVAILABLE DESTINATIONS ---\n${destinationList}`
  );

  // 4. AGENT MODE
  parts.push(
    `--- AGENT MODE ---
You can offer to visually guide the user to relevant pages on the site. The UI handles all navigation animations — you just pick the destination.

Emit a tag at the END of your response: [[AGENT:{"nav":"/destination"}]]
You may also add "target" to highlight a specific element on a page: [[AGENT:{"nav":"/page","target":"element-id"}]]

Rules:
1. CHECK if the destination is in the "Available Destinations" list above.
2. IF AND ONLY IF the destination is in the list, you may offer to take the user there.
3. If the relevant content is on a page NOT in the list, do NOT offer navigation. Just answer the question.
4. When offering, always ask "Would you like me to take you there?" or similar.
5. Emit the tag at the very end of your response.
6. If the user is already on the destination page, omit "nav" and just use "target" if applicable.

Do NOT include an agent tag for generic greetings ("hi", "who are you").`
  );

  // 5. Custom instructions
  if (customInstructions) {
    parts.push(`--- CUSTOM INSTRUCTIONS ---\n${customInstructions}`);
  }

  // 6. Retrieved RAG chunks
  if (retrievedChunks && retrievedChunks.length > 0) {
    const chunkText = retrievedChunks
      .map(c => (c.heading ? `[${c.heading}]\n${c.text}` : c.text))
      .join('\n\n');
    parts.push(`--- RETRIEVED CONTEXT ---\n${chunkText}`);
  }

  return parts.join('\n\n');
}
