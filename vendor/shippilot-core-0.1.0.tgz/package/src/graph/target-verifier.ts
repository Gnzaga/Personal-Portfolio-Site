import type { SiteGraph } from '../types.js';

export interface TargetVerificationWarning {
  route: string;
  field: 'navbar' | 'card' | 'detail';
  expectedId: string;
  message: string;
}

/**
 * Cross-checks each node's synthesized navbar/card/detail target IDs
 * against the `targets` actually scanned across the site. Synthesized IDs
 * that were never seen in any scanned page are reported as warnings so
 * operators can find navigation dead ends before shipping (see finding 1:
 * a graph referencing "homelab-card" which exists in no JSX).
 *
 * Navbar links are typically rendered by a shared layout/nav component
 * that isn't itself a scanned route, so a navbar ID counts as "found" if
 * it appears ANYWHERE in the scanned site. Card/detail links, by
 * contrast, are always rendered on the specific parent listing page, so
 * they're checked against that parent node's targets specifically.
 */
export function verifyTargets(graph: SiteGraph): TargetVerificationWarning[] {
  const warnings: TargetVerificationWarning[] = [];

  const allScannedTargets = new Set<string>();
  for (const node of Object.values(graph.nodes)) {
    for (const t of node.targets) allScannedTargets.add(t);
  }

  for (const node of Object.values(graph.nodes)) {
    if (node.navbar && !allScannedTargets.has(node.navbar)) {
      warnings.push({
        route: node.path,
        field: 'navbar',
        expectedId: node.navbar,
        message: `expected data-agent-target="${node.navbar}" not found in JSX for ${node.path}`,
      });
    }

    if (node.card || node.detail) {
      const parentNode = node.parent ? graph.nodes[node.parent] : undefined;
      const parentScanned = new Set(parentNode?.targets ?? []);
      const parentRoute = node.parent ?? node.path;

      if (node.card && !parentScanned.has(node.card)) {
        warnings.push({
          route: parentRoute,
          field: 'card',
          expectedId: node.card,
          message: `expected data-agent-target="${node.card}" not found in JSX for ${parentRoute}`,
        });
      }

      if (node.detail && !parentScanned.has(node.detail)) {
        warnings.push({
          route: parentRoute,
          field: 'detail',
          expectedId: node.detail,
          message: `expected data-agent-target="${node.detail}" not found in JSX for ${parentRoute}`,
        });
      }
    }
  }

  return warnings;
}
