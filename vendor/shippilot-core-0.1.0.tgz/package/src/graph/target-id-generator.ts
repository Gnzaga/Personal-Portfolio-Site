/**
 * Map of plural section names to their singular forms.
 */
const SINGULAR: Record<string, string> = {
  projects: 'project',
  blogs: 'blog',
  posts: 'post',
  pages: 'page',
  articles: 'article',
  categories: 'category',
};

/**
 * Convert text to a URL-friendly slug.
 * "Homelab Project" → "homelab-project"
 */
export function toSlug(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '-');
}

/**
 * Generate navbar target ID from a route path.
 * "/" → "nav-home", "/projects" → "nav-projects"
 */
export function navTargetId(path: string): string {
  if (path === '/') {
    return 'nav-home';
  }
  // Strip leading slash and take the first segment
  const segment = path.replace(/^\//, '').split('/')[0];
  return `nav-${segment}`;
}

/**
 * Singularize a section name using the lookup table.
 * Falls back to the original word if not found.
 */
function singularize(section: string): string {
  return SINGULAR[section] ?? section;
}

/**
 * Generate card target ID. Singularizes the section.
 * ("projects", "homelab") → "project-homelab"
 */
export function cardTargetId(section: string, slug: string): string {
  return `${singularize(section)}-${slug}`;
}

/**
 * Generate detail link target ID.
 * ("projects", "homelab") → "project-homelab-detail"
 */
export function detailTargetId(section: string, slug: string): string {
  return `${cardTargetId(section, slug)}-detail`;
}
