import type {
  ScannedSite,
  ScannedRoute,
  SiteGraph,
  GraphNode,
  GraphEdge,
  ContentChunk,
} from '../types.js';
import {
  navTargetId,
  cardTargetId,
  detailTargetId,
} from './target-id-generator.js';

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/** Derive the parent path for a route path (e.g. "/projects/homelab" → "/projects"). */
function parentPath(path: string): string {
  const idx = path.lastIndexOf('/');
  if (idx <= 0) return '/';
  return path.slice(0, idx);
}

/** Last segment of a path (e.g. "/projects/homelab" → "homelab"). */
function lastSegment(path: string): string {
  return path.split('/').filter(Boolean).pop() ?? '';
}

/** Count non-root path segments (e.g. "/" → 0, "/projects" → 1, "/projects/homelab" → 2). */
function segmentCount(path: string): number {
  return path.split('/').filter(Boolean).length;
}

/**
 * Build a short content summary from the route's extracted content.
 * Falls back to a path-derived label if no content is available.
 */
function buildContentSummary(route: ScannedRoute): string {
  const { title, textSnippets, metaDescription } = route.content;

  if (metaDescription) return metaDescription;

  const base = title ?? lastSegment(route.path) ?? route.path;
  const snippet = textSnippets[0];
  if (snippet) {
    const truncated = snippet.length > 80 ? snippet.slice(0, 77) + '...' : snippet;
    return `${base} — ${truncated}`;
  }
  return base;
}

/**
 * Split a route's content into chunks keyed by heading.
 * Each heading + following text snippets forms one chunk.
 * A "preamble" chunk is emitted for any snippets before the first heading.
 */
function buildContentChunks(route: ScannedRoute): ContentChunk[] {
  const { headings, textSnippets } = route.content;
  const chunks: ContentChunk[] = [];

  // If there is nothing to chunk, return empty
  if (headings.length === 0 && textSnippets.length === 0) return [];

  // Simple strategy: one chunk per heading that has a corresponding text snippet,
  // plus a preamble chunk for all snippets if there are no headings.
  if (headings.length === 0) {
    // No headings — emit all snippets as one chunk
    const text = textSnippets.join(' ');
    if (text.trim()) {
      chunks.push({
        id: `${route.path}#chunk-0`,
        text,
        route: route.path,
        heading: null,
      });
    }
    return chunks;
  }

  // Pair each heading with a snippet (positionally); emit remaining snippets as preamble
  const unusedSnippets = [...textSnippets];

  headings.forEach((heading, i) => {
    // Consume one snippet per heading (if available)
    const snippet = unusedSnippets.shift();
    const text = snippet ? `${heading}: ${snippet}` : heading;
    chunks.push({
      id: `${route.path}#chunk-${i}`,
      text,
      route: route.path,
      heading,
    });
  });

  // Any remaining snippets go into a trailing chunk
  if (unusedSnippets.length > 0) {
    chunks.push({
      id: `${route.path}#chunk-${headings.length}`,
      text: unusedSnippets.join(' '),
      route: route.path,
      heading: null,
    });
  }

  return chunks;
}

/**
 * The deduped union of every data-agent-target attribute actually scanned
 * on this route's page, and every suggestedTargetId of a navigableElement
 * on that page. This is the "ground truth" that target-verifier.ts checks
 * synthesized navbar/card/detail IDs against.
 */
function buildScannedTargets(route: ScannedRoute): string[] {
  const set = new Set<string>();
  for (const t of route.content.dataAgentTargets ?? []) set.add(t);
  for (const el of route.navigableElements) set.add(el.suggestedTargetId);
  return Array.from(set);
}

// ---------------------------------------------------------------------------
// Main export
// ---------------------------------------------------------------------------

export function buildSiteGraph(site: ScannedSite): SiteGraph {
  // Step 1: Build a set of all known route paths for parent lookup
  const routeSet = new Set(site.routes.map((r) => r.path));

  // Step 2: Classify and build nodes
  const nodes: Record<string, GraphNode> = {};

  for (const route of site.routes) {
    const { path, isDynamic, content } = route;

    // Determine node type
    let type: GraphNode['type'];
    if (isDynamic) {
      type = 'dynamic';
    } else {
      const segs = segmentCount(path);
      if (segs <= 1) {
        // "/" or "/top-level"
        type = 'top-level';
      } else {
        const parent = parentPath(path);
        type = routeSet.has(parent) ? 'detail' : 'top-level';
      }
    }

    // Step 3: Compute nav fields based on type
    let navbar: string | null = null;
    let parent: string | null = null;
    let card: string | null = null;
    let detail: string | null = null;

    if (type === 'top-level') {
      navbar = navTargetId(path);
    } else if (type === 'detail') {
      const parentSegment = parentPath(path); // e.g. "/projects"
      const section = lastSegment(parentSegment); // e.g. "projects"
      const slug = lastSegment(path);             // e.g. "homelab"
      parent = parentSegment;
      card = cardTargetId(section, slug);
      detail = detailTargetId(section, slug);
    }
    // dynamic: all null

    const contentSummary = type !== 'dynamic' ? buildContentSummary(route) : '';
    const contentChunks = type !== 'dynamic' ? buildContentChunks(route) : [];
    const targets = type !== 'dynamic' ? buildScannedTargets(route) : [];

    nodes[path] = {
      path,
      type,
      navbar,
      parent,
      card,
      detail,
      targets,
      contentSummary,
      contentChunks,
    };
  }

  // Step 4: Build edges
  const edgeMap = new Map<string, GraphEdge>(); // dedup key → edge

  // Source 1: navigable elements that point to known routes
  for (const route of site.routes) {
    for (const el of route.navigableElements) {
      if (!el.destination) continue;
      if (!routeSet.has(el.destination)) continue;

      const destNode = nodes[el.destination];
      if (!destNode) continue;

      // Choose action based on destination type
      const action: GraphEdge['action'] =
        destNode.type === 'detail' ? 'clickDetail' : 'navClick';

      const key = `${route.path}→${el.destination}`;
      if (!edgeMap.has(key)) {
        edgeMap.set(key, {
          from: route.path,
          to: el.destination,
          element: el.suggestedTargetId,
          action,
        });
      }
    }
  }

  // Source 2: Structural edges — every detail node must have a clickDetail edge from its parent
  for (const node of Object.values(nodes)) {
    if (node.type !== 'detail') continue;

    const key = `${node.parent}→${node.path}`;
    if (!edgeMap.has(key)) {
      // No explicit navigable element found — synthesize structural edge
      edgeMap.set(key, {
        from: node.parent!,
        to: node.path,
        element: node.detail!,
        action: 'clickDetail',
      });
    }
  }

  const edges: GraphEdge[] = Array.from(edgeMap.values());

  // Step 5: Assemble the SiteGraph
  const pageCount = site.routes.filter((r) => !r.isDynamic).length;

  return {
    scope: 'public',
    nodes,
    edges,
    generatedAt: new Date().toISOString(),
    framework: site.framework,
    pageCount,
  };
}
