import type { SiteGraph, NavigationStep, GraphNode } from '../types.js';

/**
 * Computes the ordered list of visual navigation steps to get from
 * `fromRoute` to `toRoute`, optionally highlighting `elementTarget`
 * on the final page.
 *
 * Nested detail pages (a detail page whose parent is itself a detail page,
 * to arbitrary depth) are handled by walking the `.parent` chain from
 * `toRoute` up to its top-level ancestor, then emitting one
 * scroll → highlight → clickDetail hop per level on the way back down.
 *
 * `graph.edges` is intentionally NOT used for this walk: the visual
 * choreography (which card to scroll to, which detail link to click) is
 * carried entirely by GraphNode.card/detail, which has no equivalent in
 * GraphEdge — a full BFS over edges would still need to fall back to
 * these same node fields for the per-hop animation, so walking the
 * existing parent chain is the smaller, lower-risk fix for the same bug
 * (finding 7: "pathfinder isn't BFS, graph.edges never used").
 */
export function computeNavigationSteps(
  graph: SiteGraph,
  fromRoute: string,
  toRoute: string,
  elementTarget?: string | null,
): NavigationStep[] {
  const steps: NavigationStep[] = [];
  const dest = graph.nodes[toRoute];

  // Unknown route — fall back to direct navigate (or empty if no route given)
  if (!dest) {
    if (toRoute) {
      steps.push({ action: 'directNav', route: toRoute });
    }
    if (elementTarget) {
      steps.push({ action: 'scroll', target: elementTarget });
      steps.push({ action: 'highlight', target: elementTarget, duration: 3000 });
    }
    return steps;
  }

  // Dynamic routes (e.g. "/blog/:slug") are patterns, not real pages —
  // refuse to plan a route rather than emit a step whose `route` is a
  // literal pattern string that adapter.navigate() could never resolve.
  if (dest.type === 'dynamic') {
    return [];
  }

  const isDetail = dest.parent !== null;
  const isAlreadyThere = fromRoute === toRoute;

  if (isAlreadyThere) {
    if (elementTarget) {
      steps.push({ action: 'scroll', target: elementTarget });
      steps.push({ action: 'highlight', target: elementTarget, duration: 3000 });
    }
    return steps;
  }

  if (!isDetail) {
    // ── Destination is a top-level page ──
    steps.push({ action: 'navClick', navTarget: dest.navbar!, route: toRoute });

    if (elementTarget) {
      steps.push({ action: 'scroll', target: elementTarget });
      steps.push({ action: 'highlight', target: elementTarget, duration: 3000 });
    }
    return steps;
  }

  // ── Destination is a detail page (possibly nested several levels deep) ──
  // Walk the parent chain from `dest` up to its top-level ancestor.
  const chain: GraphNode[] = [];
  let cursor: GraphNode | undefined = dest;
  while (cursor) {
    chain.unshift(cursor);
    cursor = cursor.parent ? graph.nodes[cursor.parent] : undefined;
  }
  const topLevel = chain[0]!;

  // If `fromRoute` is already one of dest's ancestors (or dest itself),
  // start the walk from there instead of replaying earlier hops.
  const startIndex = chain.findIndex((n) => n.path === fromRoute);

  if (startIndex === -1) {
    steps.push({ action: 'navClick', navTarget: topLevel.navbar!, route: topLevel.path });
  }

  const firstHopIndex = startIndex === -1 ? 1 : startIndex + 1;

  for (let i = firstHopIndex; i < chain.length; i++) {
    const node = chain[i]!;
    steps.push({ action: 'scroll', target: node.card! });
    steps.push({ action: 'highlight', target: node.card!, duration: 1500 });
    steps.push({ action: 'clickDetail', target: node.detail!, route: node.path });
  }

  return steps;
}
