#!/usr/bin/env node
import { Command } from 'commander';
import { loadConfig } from './cli/config.js';
import { runScan } from './cli/commands/scan.js';
import { runDoctor } from './cli/commands/doctor.js';
import { runSmoke } from './cli/commands/test-smoke.js';
import { runInit } from './cli/commands/init.js';
import { createInteractiveSession } from './cli/commands/interactive.js';

const program = new Command();
program.name('shippilot').description('AI-powered navigation chatbot for React/Next.js sites').version('0.1.0');

program
  .command('init')
  .description('Interactive setup wizard — creates shippilot.config.json')
  .action(async () => {
    try {
      const { path } = await runInit({ projectRoot: process.cwd() });
      console.log(`\n✓ Config written to ${path}\nRun: shippilot scan`);
    } catch (e) { console.error('init failed:', e); process.exit(1); }
  });

program
  .command('scan')
  .description('Scan routes, build site graph, optionally index for RAG')
  .action(async () => {
    try {
      const config = loadConfig(process.cwd());
      const result = await runScan({ config, projectRoot: process.cwd() });
      console.log(`\n✓ Scan complete: ${result.pageCount} pages, ${result.edgeCount} edges`);
      if (result.ragEnabled) console.log(`  RAG: ${result.chunkCount} chunks indexed`);
      if (result.orphanRoutes.length) console.log(`  Orphan routes: ${result.orphanRoutes.join(', ')}`);
    } catch (e) { console.error('scan failed:', e); process.exit(1); }
  });

program
  .command('serve')
  .description('Start local dev server for the /chat endpoint')
  .option('-p, --port <port>', 'Port to listen on', '3001')
  .action(async (opts) => {
    try {
      const config = loadConfig(process.cwd());
      const apiKey = process.env[config.model.apiKeyEnv] ?? '';
      if (!apiKey) { console.error(`API key env var ${config.model.apiKeyEnv} is not set`); process.exit(1); }
      const { runServe } = await import('./cli/commands/serve.js');
      const port = Number(opts.port);
      const { url } = await runServe({ config, projectRoot: process.cwd(), port });
      console.log(`\n✓ ShipPilot server running at ${url}`);
    } catch (e) { console.error('serve failed:', e); process.exit(1); }
  });

program
  .command('doctor')
  .description('Diagnose config, graph, and endpoint health')
  .action(async () => {
    try {
      const config = loadConfig(process.cwd());
      const report = await runDoctor({ config, projectRoot: process.cwd() });
      const icon = { pass: '✓', warn: '⚠', fail: '✗' } as const;
      for (const c of report.checks) {
        console.log(`  ${icon[c.status]} ${c.name}: ${c.message}`);
      }
      console.log(`\nOverall: ${report.overall}`);
      if (report.overall === 'fail') process.exit(1);
    } catch (e) { console.error('doctor failed:', e); process.exit(1); }
  });

program
  .command('test')
  .description('Test the chatbot (--smoke for automated, --interactive for REPL)')
  .option('--smoke', 'Run auto-generated smoke tests against the live endpoint')
  .option('--interactive', 'Start interactive REPL chat session')
  .action(async (opts) => {
    try {
      const config = loadConfig(process.cwd());
      const apiKey = process.env[config.model.apiKeyEnv] ?? '';
      if (!apiKey) { console.error(`API key env var ${config.model.apiKeyEnv} is not set`); process.exit(1); }
      const { readFile } = await import('node:fs/promises');
      const { join } = await import('node:path');
      const graphPath = join(process.cwd(), config.outputDir, 'site-graph.json');
      const siteGraph = JSON.parse(await readFile(graphPath, 'utf-8'));

      if (opts.smoke) {
        const result = await runSmoke({ config, siteGraph, apiKey });
        console.log(`\nSmoke: ${result.passed} passed, ${result.failed} failed`);
        for (const d of result.details.filter(d => d.status === 'fail')) {
          console.log(`  ✗ ${d.route}: ${d.reason}`);
        }
        if (result.failed > 0) process.exit(1);
      } else if (opts.interactive) {
        const { default: readline } = await import('node:readline');
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        const session = createInteractiveSession({ config, siteGraph, apiKey });
        console.log('\nShipPilot interactive mode. Type "exit" to quit.\n');
        const ask = () => {
          rl.question('You: ', async (input) => {
            if (input.trim() === 'exit') { rl.close(); return; }
            try {
              const { response, agentAction } = await session.sendMessage(input);
              console.log(`\nBot: ${response}`);
              if (agentAction?.nav) console.log(`[Agent would navigate to: ${agentAction.nav}]`);
              console.log('');
            } catch (e) { console.error('Error:', e); }
            ask();
          });
        };
        ask();
      } else {
        console.log('Use --smoke or --interactive');
      }
    } catch (e) { console.error('test failed:', e); process.exit(1); }
  });

program.parseAsync(process.argv);
