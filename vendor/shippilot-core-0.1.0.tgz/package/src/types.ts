// ─────────────────────────────────────────────────────────────────────────────
// ShipPilot — Core Type Definitions
// ─────────────────────────────────────────────────────────────────────────────

// ---------------------------------------------------------------------------
// Scanner types
// ---------------------------------------------------------------------------

/** Output of the scanner — framework-agnostic representation of a site's routes. */
export interface ScannedSite {
  routes: ScannedRoute[];
  framework: 'react-router' | 'nextjs-app' | 'nextjs-pages';
}

/** A single route discovered by the scanner. */
export interface ScannedRoute {
  /** e.g. "/projects/homelab" */
  path: string;
  /** e.g. "./src/pages/projects/Homelab.tsx" */
  componentFile: string;
  content: ExtractedContent;
  navigableElements: NavigableElement[];
  /** True when the path contains dynamic segments (e.g. /blog/:slug, /[id]) */
  isDynamic: boolean;
}

/** Content extracted from a page via AST analysis. */
export interface ExtractedContent {
  /** First h1/h2 found, or null */
  title: string | null;
  /** All heading text on the page */
  headings: string[];
  /** Paragraph and span text snippets */
  textSnippets: string[];
  /** From <Helmet> or <Head> if present, otherwise null */
  metaDescription: string | null;
  /**
   * Ordered heading -> text groups, as encountered in JSX document order.
   * A section's `heading` is `null` for text that appears before the first
   * heading on the page. `headings` and `textSnippets` above are derived
   * from this array and kept for backward compatibility.
   */
  sections: ContentSection[];
  /**
   * Every literal `data-agent-target` attribute value found anywhere on the
   * page (any element, not just links), in document order, deduped.
   * Optional — scanners/fixtures written before this field existed simply
   * omit it, and the graph builder treats a missing value as `[]`.
   */
  dataAgentTargets?: string[];
}

/** A heading and the text snippets that follow it, in document order. */
export interface ContentSection {
  heading: string | null;
  text: string[];
}

/** An element on a page that the navigation engine can interact with. */
export interface NavigableElement {
  type: 'link' | 'navlink' | 'button' | 'anchor';
  /** Visible label text */
  text: string;
  /** Target route if statically determinable, otherwise null */
  destination: string | null;
  /** Auto-generated data-agent-target value */
  suggestedTargetId: string;
  /** CSS selector fallback */
  selector: string;
  /**
   * True when `destination` is a static prefix of a template-literal
   * expression (e.g. `/projects/${slug}` -> "/projects/"), not the full,
   * concrete destination. Absent/false for ordinary static destinations.
   */
  pattern?: boolean;
}

// ---------------------------------------------------------------------------
// Site graph types
// ---------------------------------------------------------------------------

/** The complete navigation graph for a site. Written to site-graph.json at build time. */
export interface SiteGraph {
  /** "public" for v1; future: "admin", "paid", etc. */
  scope: string;
  /** Keyed by route path */
  nodes: Record<string, GraphNode>;
  edges: GraphEdge[];
  /** ISO 8601 timestamp of when the graph was generated */
  generatedAt: string;
  framework: string;
  pageCount: number;
  /**
   * sha256 hex digest of each scanned route's component file, keyed by
   * ScannedRoute.componentFile (relative to projectRoot), computed at scan
   * time. Used by `shippilot doctor` to detect a stale graph. Optional —
   * graphs written before this field existed simply omit it.
   */
  sourceHashes?: Record<string, string>;
}

/** A single page (node) in the site graph. */
export interface GraphNode {
  path: string;
  type: 'top-level' | 'detail' | 'dynamic';
  /**
   * data-agent-target of the navbar link for this page.
   * Set on top-level pages; null for detail pages.
   */
  navbar: string | null;
  /**
   * Parent route path for detail pages (e.g. "/projects" for "/projects/homelab").
   * Null for top-level pages.
   */
  parent: string | null;
  /**
   * data-agent-target of the card element on the parent page.
   * Null for top-level pages.
   */
  card: string | null;
  /**
   * data-agent-target of the clickable detail link on the parent page.
   * Null for top-level pages.
   */
  detail: string | null;
  /**
   * Deduped union of every data-agent-target attribute value and
   * NavigableElement.suggestedTargetId actually scanned on this page.
   * Used by target-verifier.ts to check that navbar/card/detail above are
   * real, not just synthesized-and-hoped-for.
   */
  targets: string[];
  /** One-liner page description used in the system prompt */
  contentSummary: string;
  /** Content chunks for RAG indexing */
  contentChunks: ContentChunk[];
}

/** A directed edge in the navigation graph representing a UI transition. */
export interface GraphEdge {
  /** Source route path */
  from: string;
  /** Destination route path */
  to: string;
  /** data-agent-target of the element that triggers this transition */
  element: string;
  action: 'navClick' | 'clickDetail' | 'directNav';
}

// ---------------------------------------------------------------------------
// Navigation steps — discriminated union
// ---------------------------------------------------------------------------

/**
 * A single visual navigation step executed by the navigation engine.
 * The `action` field is the discriminant.
 *
 *   navClick    — glow + click a navbar link, then navigate to `route`
 *   scroll      — smooth-scroll to an element
 *   highlight   — add agent-highlight glow for `duration` ms
 *   clickDetail — glow + click a detail/card link (triggers a route change)
 *   directNav   — navigate programmatically without a DOM interaction
 */
export type NavigationStep =
  | { action: 'navClick'; navTarget: string; route: string }
  | { action: 'scroll'; target: string }
  | { action: 'highlight'; target: string; duration: number }
  | { action: 'clickDetail'; target: string; route: string }
  | { action: 'directNav'; route: string };

// ---------------------------------------------------------------------------
// RAG types
// ---------------------------------------------------------------------------

/** A chunk of page content used for RAG indexing and retrieval. */
export interface ContentChunk {
  id: string;
  text: string;
  /** Route path this chunk belongs to */
  route: string;
  /** Section heading that precedes this chunk, or null */
  heading: string | null;
}

/** Metadata stored alongside a vector in the vector store. */
export interface ChunkMetadata {
  route: string;
  heading: string | null;
  text: string;
}

/** A result returned from a vector store similarity search. */
export interface SearchResult {
  id: string;
  /** Similarity/relevance score — higher is more relevant */
  score: number;
  metadata: ChunkMetadata;
}

/** Interface for embedding providers. Implement this to bring your own embedding backend. */
export interface EmbeddingProvider {
  /** Embed a batch of texts and return one float array per input string */
  embed(texts: string[]): Promise<number[][]>;
  /** Dimensionality of the produced vectors */
  dimensions: number;
}

/** Interface for vector stores. Implement this to bring your own storage backend. */
export interface VectorStore {
  add(id: string, vector: number[], metadata: ChunkMetadata): Promise<void>;
  query(vector: number[], topK: number): Promise<SearchResult[]>;
  save(path: string): Promise<void>;
  load(path: string): Promise<void>;
}

// ---------------------------------------------------------------------------
// Prompt builder
// ---------------------------------------------------------------------------

/** Options passed to the prompt builder when assembling a system prompt. */
export interface PromptBuilderOptions {
  graph: SiteGraph;
  /** The route the user is currently viewing */
  currentPage: string;
  /** User-provided description of the site (from config) */
  siteContext: string;
  /** RAG chunks retrieved for the current user message, if RAG is enabled */
  retrievedChunks?: ContentChunk[];
  /** Additional instructions appended to the system prompt */
  customInstructions?: string;
}

// ---------------------------------------------------------------------------
// Server middleware
// ---------------------------------------------------------------------------

/** Options for the Express/Next.js chat middleware factory. */
export interface ShipPilotServerOptions {
  model: {
    /** OpenAI-compatible chat completions URL */
    endpoint: string;
    apiKey: string;
    /** e.g. "gpt-4o-mini", "claude-sonnet-4-20250514" */
    modelName: string;
  };
  /** Loaded from site-graph.json */
  siteGraph: SiteGraph;
  /** Loaded from site-index.json if RAG is enabled */
  vectorStore?: VectorStore;
  embeddingProvider?: EmbeddingProvider;
  siteContext?: string;
  customInstructions?: string;
  /** Number of history messages to retain in the context window. Default: 10 */
  maxHistoryMessages?: number;
  /** Number of chunks to retrieve per query when RAG is enabled. Default: 5 */
  ragTopK?: number;
}

// ---------------------------------------------------------------------------
// React provider / widget config
// ---------------------------------------------------------------------------

/** Configuration for the ShipPilotProvider React context. */
export interface ShipPilotConfig {
  /** URL of the /chat endpoint. Default: "/chat" */
  chatEndpoint: string;
  /** Imported from site-graph.json */
  siteGraph: SiteGraph;
  theme?: 'dark' | 'light' | 'auto';
  position?: 'bottom-right' | 'bottom-left';
  welcomeMessage?: string;
  /** Label shown in the widget during guided navigation. Default: "Piloting..." */
  agentModeLabel?: string;
  /** CSS color string for highlights and agent accents */
  accentColor?: string;
}

// ---------------------------------------------------------------------------
// Chat / agent action types (used by the React widget)
// ---------------------------------------------------------------------------

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

/** The body of a POST /chat request from the widget to the server. */
export interface ChatRequestBody {
  message: string;
  currentPage?: string;
  history?: ChatMessage[];
}

/** Parsed [[AGENT:{...}]] action emitted by the LLM. */
export interface AgentAction {
  /** Destination route, if the LLM wants to navigate */
  nav?: string;
  /** data-agent-target element to highlight on the destination page */
  target?: string;
}

// ---------------------------------------------------------------------------
// Content source config (for dynamic routes)
// ---------------------------------------------------------------------------

export type ContentSourceType = 'directory' | 'json-endpoint' | 'graphql';

export interface ContentSource {
  type: ContentSourceType;
  /** Filesystem path (for 'directory') or URL (for 'json-endpoint' / 'graphql') */
  path: string;
}

// ---------------------------------------------------------------------------
// Top-level CLI / build config (shippilot.config.json shape)
// ---------------------------------------------------------------------------

export interface ShipPilotBuildConfig {
  framework: 'react-router' | 'nextjs-app' | 'nextjs-pages';
  /** Path to the app entry point (e.g. "./src/App.tsx") */
  entryPoint: string;
  /** Directory where site-graph.json and site-index.json will be written */
  outputDir: string;
  model: {
    /** OpenAI-compatible chat completions URL */
    endpoint: string;
    modelName: string;
    /** Name of the env var that holds the API key (never the key itself) */
    apiKeyEnv: string;
  };
  embedding?: {
    provider: 'local' | 'api';
  };
  rag?: {
    enabled: boolean | 'auto';
    /** Page count above which RAG is automatically activated. Default: 20 */
    threshold: number;
    /** Number of chunks to retrieve per query. Default: 5 */
    topK: number;
    /** Token target per chunk. Default: 512 */
    chunkSize: number;
    /** Token overlap between adjacent chunks. Default: 50 */
    chunkOverlap: number;
  };
  site?: {
    context: string;
    customInstructions?: string;
    scope: string;
  };
  chat?: {
    maxHistoryMessages: number;
    welcomeMessage: string;
    agentModeLabel: string;
  };
  /** Maps dynamic route patterns to content sources */
  contentSources?: Record<string, ContentSource>;
  theme?: {
    mode: 'dark' | 'light' | 'auto';
    accentColor: string;
    position: 'bottom-right' | 'bottom-left';
  };
}
