import type { SiteGraph, ScannedSite, EmbeddingProvider, VectorStore } from '../types.js';
import type { ChunkOptions } from './chunker.js';
import { chunkRouteContent } from './chunker.js';

export interface IndexerOptions {
  embedder: EmbeddingProvider;
  store: VectorStore;
  chunkOptions?: ChunkOptions;
  /** Embedding batch size. Default: 32 */
  batchSize?: number;
}

export async function indexGraph(
  graph: SiteGraph,
  scannedSite: ScannedSite,
  options: IndexerOptions,
): Promise<{ chunkCount: number }> {
  const { embedder, store, chunkOptions, batchSize = 32 } = options;

  // 1. Filter routes to only those present in graph.nodes
  const keptRoutes = scannedSite.routes.filter(r => r.path in graph.nodes);

  // 2. Collect all chunks from kept routes
  const allChunks = keptRoutes.flatMap(route => chunkRouteContent(route, chunkOptions));

  // 3. Embed and store in batches
  for (let i = 0; i < allChunks.length; i += batchSize) {
    const batch = allChunks.slice(i, i + batchSize);
    const texts = batch.map(c => c.text);
    const vectors = await embedder.embed(texts);
    for (let j = 0; j < batch.length; j++) {
      const chunk = batch[j]!;
      const vector = vectors[j]!;
      await store.add(chunk.id, vector, {
        route: chunk.route,
        heading: chunk.heading,
        text: chunk.text,
      });
    }
  }

  return { chunkCount: allChunks.length };
}
