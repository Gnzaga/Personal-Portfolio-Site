import type { ContentChunk, ScannedRoute } from '../types.js';

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export interface ChunkOptions {
  /** Target tokens per chunk (approx chars/4). Default: 512 */
  chunkSize?: number;
  /** Token overlap between adjacent chunks. Default: 50 */
  chunkOverlap?: number;
}

/**
 * Split a route's extracted content into overlapping, token-bounded chunks
 * suitable for RAG indexing.
 *
 * Token count approximation: Math.ceil(text.length / 4)
 */
export function chunkRouteContent(route: ScannedRoute, options: ChunkOptions = {}): ContentChunk[] {
  const chunkSize = options.chunkSize ?? 512;
  const chunkOverlap = options.chunkOverlap ?? 50;

  const spans = buildSpans(route);
  if (spans.length === 0) return [];

  return walkSpans(spans, route.path, chunkSize, chunkOverlap);
}

// ---------------------------------------------------------------------------
// Internal types
// ---------------------------------------------------------------------------

interface Span {
  text: string;
  heading: string | null;
}

// ---------------------------------------------------------------------------
// Build a flat sequence of (text, heading) spans from route content
// ---------------------------------------------------------------------------

/**
 * Build spans directly from `route.content.sections`, where each section
 * already pairs a heading with the paragraphs that belong to it structurally
 * (see ExtractedContent.sections). This replaces the old positional
 * heading/textSnippet zipping, which silently mispaired content whenever a
 * page had a different number of headings than paragraphs.
 */
function buildSpans(route: ScannedRoute): Span[] {
  const { title, sections } = route.content;
  const spans: Span[] = [];

  const effectiveTitle = title?.trim() ?? '';
  if (effectiveTitle) {
    spans.push({ text: effectiveTitle, heading: null });
  }

  // Defensive: sections is expected to always be present (see ExtractedContent),
  // but tolerate its absence so routes scanned before this field existed don't
  // crash chunking — they simply contribute only their title span.
  for (const section of sections ?? []) {
    const heading = section.heading?.trim() || null;
    if (heading) {
      spans.push({ text: heading, heading });
    }
    for (const paragraph of section.text) {
      const trimmed = paragraph.trim();
      if (trimmed) spans.push({ text: trimmed, heading });
    }
  }

  return spans;
}

// ---------------------------------------------------------------------------
// Walk spans and emit chunks
// ---------------------------------------------------------------------------

function countTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

/**
 * Trim overlap seed to the last `overlapTokens` tokens worth of characters,
 * breaking at a whitespace boundary to avoid splitting words.
 */
function trimToOverlap(text: string, overlapTokens: number): string {
  const maxChars = overlapTokens * 4;
  if (text.length <= maxChars) return text;

  const candidate = text.slice(-maxChars);
  // Trim to the nearest whitespace boundary at the start
  const firstSpace = candidate.indexOf(' ');
  if (firstSpace === -1) return candidate;
  return candidate.slice(firstSpace + 1);
}

function walkSpans(
  spans: Span[],
  routePath: string,
  chunkSize: number,
  chunkOverlap: number,
): ContentChunk[] {
  const chunks: ContentChunk[] = [];

  let overlapSeed = '';
  let chunkStartHeading: string | null = null;
  let headingSet = false;
  let accumulated = '';

  function emit() {
    const text = accumulated.trim();
    if (!text) return;

    chunks.push({
      id: `${routePath}#chunk-${chunks.length}`,
      text,
      route: routePath,
      heading: chunkStartHeading,
    });

    overlapSeed = trimToOverlap(accumulated, chunkOverlap);
    accumulated = overlapSeed;
    headingSet = false;
  }

  for (const span of spans) {
    const spanTokens = countTokens(span.text);

    if (accumulated.trim() && countTokens(accumulated) + spanTokens > chunkSize) {
      emit();
      if (!headingSet) {
        chunkStartHeading = span.heading;
        headingSet = true;
      }
    }

    if (!headingSet) {
      chunkStartHeading = span.heading;
      headingSet = true;
    }

    if (accumulated.trim()) {
      accumulated += ' ' + span.text;
    } else {
      accumulated = span.text;
    }

    while (countTokens(accumulated) > chunkSize) {
      const maxChars = chunkSize * 4;
      let sliceEnd = maxChars;
      const spaceIdx = accumulated.lastIndexOf(' ', sliceEnd);
      if (spaceIdx > 0) sliceEnd = spaceIdx;

      const sliceText = accumulated.slice(0, sliceEnd).trim();
      if (sliceText) {
        chunks.push({
          id: `${routePath}#chunk-${chunks.length}`,
          text: sliceText,
          route: routePath,
          heading: chunkStartHeading,
        });
        overlapSeed = trimToOverlap(sliceText, chunkOverlap);
      }

      accumulated = overlapSeed + ' ' + accumulated.slice(sliceEnd).trimStart();
      accumulated = accumulated.trim();
      headingSet = true;
    }
  }

  if (accumulated.trim()) {
    emit();
  }

  return chunks;
}
