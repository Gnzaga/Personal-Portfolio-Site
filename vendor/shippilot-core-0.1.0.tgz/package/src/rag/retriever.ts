import type { ContentChunk, EmbeddingProvider, VectorStore, SiteGraph } from '../types.js';

export interface RetrieverOptions {
  embedder: EmbeddingProvider;
  store: VectorStore;
  graph: SiteGraph;
  topK?: number;
}

export async function retrieveRelevantChunks(
  query: string,
  options: RetrieverOptions,
): Promise<ContentChunk[]> {
  const [queryVec] = await options.embedder.embed([query]);
  const topK = options.topK ?? 5;
  const results = await options.store.query(queryVec!, topK * 2);

  return results
    .filter(result => options.graph.nodes[result.metadata.route] !== undefined)
    .slice(0, topK)
    .map(result => ({
      id: result.id,
      text: result.metadata.text,
      route: result.metadata.route,
      heading: result.metadata.heading,
    }));
}
