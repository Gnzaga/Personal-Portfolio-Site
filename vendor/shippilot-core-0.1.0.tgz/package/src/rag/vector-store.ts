import { readFile, writeFile } from 'node:fs/promises';
import type { VectorStore, ChunkMetadata, SearchResult } from '../types.js';

interface StoredEntry {
  id: string;
  vector: number[];
  metadata: ChunkMetadata;
}

interface SerializedStore {
  dimensions: number;
  entries: StoredEntry[];
}

export class LocalVectorStore implements VectorStore {
  readonly dimensions: number;
  private entries: StoredEntry[] = [];

  constructor(dimensions: number) {
    this.dimensions = dimensions;
  }

  async add(id: string, vector: number[], metadata: ChunkMetadata): Promise<void> {
    if (vector.length !== this.dimensions) {
      throw new Error(
        `Vector dimension mismatch: expected ${this.dimensions}, got ${vector.length}`
      );
    }
    this.entries.push({ id, vector: this.normalize(vector), metadata });
  }

  async query(vector: number[], topK: number): Promise<SearchResult[]> {
    const queryVec = this.normalize(vector);
    const scored = this.entries.map((entry) => ({
      id: entry.id,
      score: this.dotProduct(queryVec, entry.vector),
      metadata: entry.metadata,
    }));
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, topK);
  }

  async save(path: string): Promise<void> {
    const data: SerializedStore = {
      dimensions: this.dimensions,
      entries: this.entries,
    };
    await writeFile(path, JSON.stringify(data), 'utf-8');
  }

  async load(path: string): Promise<void> {
    const raw = await readFile(path, 'utf-8');
    const data = JSON.parse(raw) as SerializedStore;
    if (data.dimensions !== this.dimensions) {
      throw new Error(
        `Vector dimension mismatch: store has ${data.dimensions}, expected ${this.dimensions}`
      );
    }
    this.entries = data.entries;
  }

  private normalize(v: number[]): number[] {
    const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    if (norm === 0) return v.map(() => 0);
    return v.map((x) => x / norm);
  }

  private dotProduct(a: number[], b: number[]): number {
    return a.reduce((s, x, i) => s + x * b[i]!, 0);
  }
}
