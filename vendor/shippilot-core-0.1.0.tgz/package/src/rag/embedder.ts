import type { EmbeddingProvider } from '../types.js';

// Minimal type shim for the xenova/transformers feature-extraction pipeline.
// The pipeline is callable and returns a Tensor with a tolist() method.
type FeatureExtractionPipeline = (
  texts: string | string[],
  options?: { pooling?: 'none' | 'mean' | 'cls'; normalize?: boolean }
) => Promise<{ tolist(): number[][] }>;

export class LocalEmbedder implements EmbeddingProvider {
  readonly dimensions = 384;
  private readonly modelName: string;
  private pipeline: FeatureExtractionPipeline | null = null;

  constructor(modelName = 'Xenova/all-MiniLM-L6-v2') {
    this.modelName = modelName;
  }

  async embed(texts: string[]): Promise<number[][]> {
    if (!this.pipeline) {
      // Lazy import — only loads and downloads the model on first call.
      const { pipeline } = await import('@xenova/transformers');
      this.pipeline = (await pipeline(
        'feature-extraction',
        this.modelName,
      )) as unknown as FeatureExtractionPipeline;
    }
    const output = await this.pipeline(texts, { pooling: 'mean', normalize: true });
    return output.tolist();
  }
}
